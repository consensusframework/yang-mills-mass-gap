import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q3 (QA1): PREFIXES, SATURATION, LOCALIZATION. Own re-proofs of C_0 = 0, C_(i+1) = C_i + c_i, C_m = ∑ c_i (not via the
-- candidate's lemmas), then step control, capacities 1/8, 7, 0, repeated regions and the preserved background.
theorem Q3_C0 {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (η : Polymer N) : prefixCost r δ 0 η = 0 := by
  unfold prefixCost; simp
theorem Q3_succ {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (i : Fin m) (η : Polymer N) :
    prefixCost r δ (i.val + 1) η = prefixCost r δ i.val η + regionCost r δ i η := by
  unfold prefixCost
  -- own route: split the sum over the predicate j.val < i+1 ⟺ j.val < i ∨ j = i
  have key : ∀ j : Fin m, (if j.val < i.val + 1 then regionCost r δ j η else 0)
      = (if j.val < i.val then regionCost r δ j η else 0) + (if j = i then regionCost r δ j η else 0) := by
    intro j
    rcases lt_trichotomy j.val i.val with hlt | heq | hgt
    · have : j ≠ i := fun h => by subst h; exact lt_irrefl _ hlt
      simp [hlt, Nat.lt_succ_of_lt hlt, this]
    · have : j = i := Fin.ext heq
      subst this; simp
    · have h1 : ¬ j.val < i.val + 1 := by omega
      have h2 : ¬ j.val < i.val := by omega
      have : j ≠ i := fun h => by subst h; exact lt_irrefl _ hgt
      simp [h1, h2, this]
  simp_rw [key]
  rw [Finset.sum_add_distrib, Finset.sum_ite_eq' Finset.univ i, if_pos (Finset.mem_univ _)]
theorem Q3_last {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (η : Polymer N) :
    prefixCost r δ m η = ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0 := by
  unfold prefixCost regionCost
  exact Finset.sum_congr rfl (fun i _ => by simp [i.isLt])
-- (b) step control at a coordinate: the effective factor moves by at most δ i on r i, exactly 0 off r i (own, one step)
example (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i)
    (a a' : Polymer N → ℝ) (i : Fin m) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R)
    (hno : ¬ typedTouchesSupport (N := N) η (r i)) :
    additiveProfile R r δ a a' (i.val + 1) η = additiveProfile R r δ a a' i.val η := by
  unfold additiveProfile; rw [if_pos hR, if_pos hR, Q3_succ, regionCost_of_not_touch r δ i hno, add_zero]
-- (c) capacities 1/8 (insufficient), 7 (excess, saturation without overshoot), 0 — both directions, from 1/4 to 3/4 and back
example : move (1/4 : ℝ) (3/4) (1/8) = 3/8 := by unfold move; norm_num
example : move (1/4 : ℝ) (3/4) 7 = 3/4 := by unfold move; norm_num
example : move (1/4 : ℝ) (3/4) 0 = 1/4 := by unfold move; norm_num
example : move (3/4 : ℝ) (1/4) (1/8) = 5/8 := by unfold move; norm_num
example : move (3/4 : ℝ) (1/4) 7 = 1/4 := by unfold move; norm_num
example : move (3/4 : ℝ) (1/4) 0 = 3/4 := by unfold move; norm_num
-- (d) OFF r i the step is exactly null even with contact with OTHER regions: η touches r 1 (and R) but not r 0 — the
--     factor is unchanged between p_0 and p_1 (step 0), while it moves at step 1
section
variable (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (η : Polymer N)
  (hR : typedTouchesSupport (N := N) η R) (hn0 : ¬ typedTouchesSupport (N := N) η (r 0)) (h1 : typedTouchesSupport (N := N) η (r 1))
example (a' : Polymer N → ℝ) (ha' : a' η = 3/4) :
    additiveProfile R r ![(1/8 : ℝ), 1/8] (fun _ => (1/4 : ℝ)) a' 1 η = 1/4
    ∧ additiveProfile R r ![(1/8 : ℝ), 1/8] (fun _ => (1/4 : ℝ)) a' 2 η = 3/8 := by
  have c1 : prefixCost r ![(1/8 : ℝ), 1/8] 1 η = 0 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, hn0]
  have c2 : prefixCost r ![(1/8 : ℝ), 1/8] 2 η = 1/8 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, hn0, h1]
  constructor
  · unfold additiveProfile; rw [if_pos hR, c1, move_zero]
  · unfold additiveProfile; rw [if_pos hR, c2, ha']; unfold move; norm_num
-- the candidate's step lemmas, retyped on this configuration
example (a a' : Polymer N → ℝ) :
    touchFactor R (additiveProfile R r ![(1/8 : ℝ), 1/8] a a' (0 : Fin 2).val) η
      = touchFactor R (additiveProfile R r ![(1/8 : ℝ), 1/8] a a' ((0 : Fin 2).val + 1)) η :=
  step_same R r ![(1/8 : ℝ), 1/8] a a' 0 η hn0
example (a a' : Polymer N → ℝ) :
    |touchFactor R (additiveProfile R r ![(1/8 : ℝ), 1/8] a a' (1 : Fin 2).val) η
      - touchFactor R (additiveProfile R r ![(1/8 : ℝ), 1/8] a a' ((1 : Fin 2).val + 1)) η| ≤ ![(1/8 : ℝ), 1/8] 1 :=
  step_bound R r ![(1/8 : ℝ), 1/8] (fun i => by fin_cases i <;> norm_num) a a' 1 η h1
end
-- (e) REPEATED / OVERLAPPING regions: r 0 = r 1 = r₀; a polymer touching r₀ accumulates both budgets (C_2 = δ₀ + δ₁),
--     and the move 1/4 → 3/4 with budgets 1/4, 1/4 on the same region still reaches 3/4 in two steps
example (R r₀ : Set (Link N)) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R) (ht : typedTouchesSupport (N := N) η r₀)
    (δ₀ δ₁ : ℝ) : prefixCost (fun _ : Fin 2 => r₀) ![δ₀, δ₁] 2 η = δ₀ + δ₁ := by
  unfold prefixCost regionCost; simp [Fin.sum_univ_two, ht]
example (R r₀ : Set (Link N)) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R) (ht : typedTouchesSupport (N := N) η r₀) :
    additiveProfile R (fun _ : Fin 2 => r₀) ![(1/4 : ℝ), 1/4] (fun _ => (1/4 : ℝ)) (fun _ => (3/4 : ℝ)) 2 η = 3/4 := by
  have c2 : prefixCost (fun _ : Fin 2 => r₀) ![(1/4 : ℝ), 1/4] 2 η = 1/2 := by
    unfold prefixCost regionCost; simp [Fin.sum_univ_two, ht]; norm_num
  unfold additiveProfile; rw [if_pos hR, c2]; unfold move; norm_num
-- (f) BACKGROUND 1/2 PRESERVED: a polymer with a η = a′ η = 1/2 keeps 1/2 at every stage whatever its capacity (move_self);
--     this is distinct from "no factor changes": the preservation is per coordinate, other coordinates may move
example (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i)
    (a a' : Polymer N → ℝ) (η : Polymer N) (ha : a η = 1/2) (ha' : a' η = 1/2) (k : ℕ) :
    additiveProfile R r δ a a' k η = 1/2 := by
  unfold additiveProfile; split_ifs
  · rw [ha, ha']; exact move_self _ _ (prefixCost_nonneg r δ hδ0 k η)
  · exact ha
-- (f′) "no factor changes" is the global statement ∀ η, touchFactor R a η = touchFactor R a′ η, which is what a zero
--      total capacity under hadd forces (own): hadd with ∑ = 0 at every η ⇒ equal effective factors everywhere
example (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (a a' : Polymer N → ℝ)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η| ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0)
    (hzero : ∀ η, (∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0) = 0) :
    ∀ η, touchFactor R a η = touchFactor R a' η := by
  intro η; have h := hadd η; rw [hzero η] at h
  exact sub_eq_zero.mp (abs_nonpos_iff.mp h)
end LatticeGauge
