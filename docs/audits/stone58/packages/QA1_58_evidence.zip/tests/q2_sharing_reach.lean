import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q2 (QA1): SHARING AND REACH OF THE COVER. Geometry is ASSUMED by hypotheses (η₀ touches R, r 0, r 1); no lattice is built.
section
variable (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (η₀ : Polymer N)
-- (a) stages 1/4 → 1/2 → 3/4 with two budgets 1/4 (prefix capacities 0, 1/4, 1/2 at η₀; move saturates at 3/4)
example (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    prefixCost r ![(1/4 : ℝ), 1/4] 0 η₀ = 0 ∧ prefixCost r ![(1/4 : ℝ), 1/4] 1 η₀ = 1/4 ∧ prefixCost r ![(1/4 : ℝ), 1/4] 2 η₀ = 1/2 := by
  refine ⟨prefixCost_zero _ _ _, ?_, ?_⟩
  · unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]
  · unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]; norm_num
example (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (h1 : typedTouchesSupport (N := N) η₀ (r 1))
    (a' : Polymer N → ℝ) (ha' : a' η₀ = 3/4) :
    additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (1/4 : ℝ)) a' 0 η₀ = 1/4
    ∧ additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (1/4 : ℝ)) a' 1 η₀ = 1/2
    ∧ additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (1/4 : ℝ)) a' 2 η₀ = 3/4 := by
  have c1 : prefixCost r ![(1/4 : ℝ), 1/4] 1 η₀ = 1/4 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]
  have c2 : prefixCost r ![(1/4 : ℝ), 1/4] 2 η₀ = 1/2 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]; norm_num
  refine ⟨?_, ?_, ?_⟩
  · unfold additiveProfile; rw [if_pos hR, prefixCost_zero, move_zero]
  · unfold additiveProfile; rw [if_pos hR, c1, ha']; unfold move; norm_num
  · unfold additiveProfile; rw [if_pos hR, c2, ha']; unfold move; norm_num
-- (a′) the reverse path 3/4 → 1/2 → 1/4
example (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (h1 : typedTouchesSupport (N := N) η₀ (r 1))
    (a' : Polymer N → ℝ) (ha' : a' η₀ = 1/4) :
    additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (3/4 : ℝ)) a' 0 η₀ = 3/4
    ∧ additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (3/4 : ℝ)) a' 1 η₀ = 1/2
    ∧ additiveProfile R r ![(1/4 : ℝ), 1/4] (fun _ => (3/4 : ℝ)) a' 2 η₀ = 1/4 := by
  have c1 : prefixCost r ![(1/4 : ℝ), 1/4] 1 η₀ = 1/4 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]
  have c2 : prefixCost r ![(1/4 : ℝ), 1/4] 2 η₀ = 1/2 := by unfold prefixCost regionCost; simp [Fin.sum_univ_two, h0, h1]; norm_num
  refine ⟨?_, ?_, ?_⟩
  · unfold additiveProfile; rw [if_pos hR, prefixCost_zero, move_zero]
  · unfold additiveProfile; rw [if_pos hR, c1, ha']; unfold move; norm_num
  · unfold additiveProfile; rw [if_pos hR, c2, ha']; unfold move; norm_num
-- (b) GLOBAL WITNESS: a ≡ 1/4, a′ = 3/4 at η₀ and 1/4 elsewhere, budgets ![1/4, 1/4].
--     (b1) hadd holds for EVERY polymer (not only at the witness coordinate)
theorem Q2_hadd_global (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    ∀ η : Polymer N, |touchFactor R (fun _ => (1/4 : ℝ)) η - touchFactor R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) η|
      ≤ ∑ i : Fin 2, if typedTouchesSupport (N := N) η (r i) then ![(1/4 : ℝ), 1/4] i else 0 := by
  intro η
  have hnn : 0 ≤ ∑ i : Fin 2, if typedTouchesSupport (N := N) η (r i) then ![(1/4 : ℝ), 1/4] i else 0 :=
    Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
  by_cases hη : η = η₀
  · rw [hη]
    unfold touchFactor; rw [if_pos hR, if_pos hR]; simp only [eq_self_iff_true, if_true]
    rw [Fin.sum_univ_two, if_pos h0, if_pos h1]; norm_num [abs_le]
  · unfold touchFactor; split_ifs <;> simp only [hη, if_false, sub_self, abs_zero] <;> exact hnn
-- (b2) the old (Stone 57) cover FAILS at the witness: no single index pays the difference 1/2
theorem Q2_no_single_payer (hR : typedTouchesSupport (N := N) η₀ R) :
    ¬ ∃ i : Fin 2, typedTouchesSupport (N := N) η₀ (r i)
      ∧ |touchFactor R (fun _ => (1/4 : ℝ)) η₀ - touchFactor R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) η₀| ≤ ![(1/4 : ℝ), 1/4] i := by
  rintro ⟨i, _, hb⟩
  unfold touchFactor at hb; rw [if_pos hR, if_pos hR] at hb; simp only [eq_self_iff_true, if_true] at hb
  fin_cases i <;> norm_num [abs_le] at hb
-- (b3) the additive capstone APPLIES to these profiles (bounds in [0,1] proved; the analytic context is assumed)
example (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (h1 : typedTouchesSupport (N := N) η₀ (r 1))
    {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : Fin 2 → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    |profileExpectation μm β χ f s R (fun _ => (1/4 : ℝ))
        - profileExpectation μm β χ f s R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4)|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin 2, ![(1/4 : ℝ), 1/4] i * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf
    (fun i => by fin_cases i <;> norm_num) hsep (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num) (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num)
    (Q2_hadd_global R r η₀ hR h0 h1)
end
-- (c) scalar remark: the same B appears in the Stone 57 bound when its cover holds; the additive cover changes WHICH
--     profile pairs are admissible, not the value of B (no universal numerical gain is inferred) — own statement of E2
example (δ : Fin 2 → ℝ) (n : Fin 2 → ℕ) : (∑ i : Fin 2, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) = ∑ i : Fin 2, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) := rfl
end LatticeGauge
