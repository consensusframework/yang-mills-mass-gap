import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
-- Q1 (QA1): BILATERAL TRUNCATED MOVE. Own re-proofs of the central properties of
--   move x y t = if x ≤ y then min y (x+t) else max y (x−t)
-- directly from the definition (the candidate's lemmas are NOT used in (a)–(d)), then numeric instances.
-- (a) start: move x y 0 = x
theorem Q1_zero (x y : ℝ) : move x y 0 = x := by
  unfold move; split_ifs with h
  · simp [min_eq_right h]
  · simp [max_eq_right (le_of_lt (not_le.mp h))]
-- (b) permanence in the interval for t ≥ 0
theorem Q1_mem (x y t : ℝ) (ht : 0 ≤ t) : min x y ≤ move x y t ∧ move x y t ≤ max x y := by
  unfold move; split_ifs with h
  · exact ⟨le_min (by simp [min_le_left]) (by linarith [min_le_left x y]), le_trans (min_le_left _ _) (le_max_right _ _)⟩
  · have := not_le.mp h
    exact ⟨le_trans (min_le_right _ _) (le_max_left _ _), max_le (le_max_right _ _) (by linarith [le_max_left x y])⟩
-- (c) saturation: |x − y| ≤ t ⇒ move x y t = y
theorem Q1_sat {x y t : ℝ} (h : |x - y| ≤ t) : move x y t = y := by
  have h1 := (abs_le.mp h).1; have h2 := (abs_le.mp h).2
  unfold move; split_ifs with hxy
  · exact min_eq_left (by linarith)
  · exact max_eq_left (by linarith)
-- (d) increment bound for u ≥ 0 and ANY real t (the strengthening implemented by the candidate): own case analysis
theorem Q1_incr (x y t u : ℝ) (hu : 0 ≤ u) : |move x y (t + u) - move x y t| ≤ u := by
  unfold move
  rw [abs_le]
  by_cases h : x ≤ y
  · rw [if_pos h, if_pos h]
    -- min y · is monotone and 1-Lipschitz: 0 ≤ B − A ≤ u
    have hAB : min y (x + t) ≤ min y (x + (t + u)) := min_le_min le_rfl (by linarith)
    have hBA : min y (x + (t + u)) ≤ min y (x + t) + u := by
      rw [← min_add_add_right]; exact min_le_min (by linarith) (by linarith)
    constructor <;> linarith
  · rw [if_neg h, if_neg h]
    have hBA : max y (x - (t + u)) ≤ max y (x - t) := max_le_max le_rfl (by linarith)
    have hAB : max y (x - t) ≤ max y (x - (t + u)) + u := by
      rw [← max_add_add_right]; exact max_le_max (by linarith) (by linarith)
    constructor <;> linarith
-- (d′) the strengthening is real: with t = −1 (negative capacity) the increment bound still holds (instance checked)
example : |move 1 3 (-1 + 2) - move 1 3 (-1)| ≤ 2 := by
  unfold move; norm_num
-- (e) numeric instances — upward direction
example : move 1 3 0 = 1 := by unfold move; norm_num                 -- zero capacity
example : move 1 3 1 = 2 := by unfold move; norm_num                 -- insufficient: partial move, no overshoot
example : move 1 3 2 = 3 := by unfold move; norm_num                 -- exact
example : move 1 3 5 = 3 := by unfold move; norm_num                 -- excess: saturates at the target
-- downward direction
example : move 3 1 0 = 3 := by unfold move; norm_num
example : move 3 1 1 = 2 := by unfold move; norm_num
example : move 3 1 2 = 1 := by unfold move; norm_num
example : move 3 1 5 = 1 := by unfold move; norm_num
-- negative values and equality
example : move (-2) (-5) 1 = -3 := by unfold move; norm_num
example : move (-5) (-2) 10 = -2 := by unfold move; norm_num
example : move 2 2 7 = 2 := by unfold move; norm_num
-- (f) the candidate's lemmas, retyped (interface), including the increment bound with arbitrary t
example (x y t : ℝ) : move x y 0 = x := move_zero x y
example (x y : ℝ) (t : ℝ) {u : ℝ} (hu : 0 ≤ u) : |move x y (t + u) - move x y t| ≤ u := abs_move_add_sub_move_le x y t hu
example {x y t : ℝ} (ht : 0 ≤ t) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (hy0 : 0 ≤ y) (hy1 : y ≤ 1) :
    0 ≤ move x y t ∧ move x y t ≤ 1 := move_mem_Icc ht hx0 hx1 hy0 hy1
-- (g) monotonicity of the SCALAR path towards its target (own): for x ≤ y and 0 ≤ t ≤ t′, move x y t ≤ move x y t′.
--     This is a property of the scalar path only; nothing is claimed about monotonicity of F_R.
theorem Q1_path_mono {x y t t' : ℝ} (hxy : x ≤ y) (ht : 0 ≤ t) (htt : t ≤ t') : move x y t ≤ move x y t' := by
  unfold move; rw [if_pos hxy, if_pos hxy]
  exact min_le_min le_rfl (by linarith)
end LatticeGauge
