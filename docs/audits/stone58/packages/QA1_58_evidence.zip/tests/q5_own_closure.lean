import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q5 (QA1): OWN CLOSURE up to the two forms of the bound, WITHOUT the two new capstones and WITHOUT
-- `abs_profileExpectation_sub_le_of_chain`. Rederived here: the telescoping (own induction), the assembly of the chain
-- (endpoint identity by effective factors, Stone 56 two-term estimate at each step), the reorganization/factorization of B,
-- 0 ≤ Cf, and the reduction to the compact form. Reused (intentional, published local lemmas): additiveProfile,
-- additiveProfile_zero, additiveProfile_mem, step_same, step_bound, touchFactor_additiveProfile_last.
theorem Q5_telescope (g : ℕ → ℝ) : ∀ k, |g 0 - g k| ≤ ∑ j ∈ Finset.range k, |g j - g (j + 1)| := by
  intro k; induction k with
  | zero => simp
  | succ k ih => rw [Finset.sum_range_succ]; have := abs_sub_le (g 0) (g k) (g (k + 1)); linarith
theorem Q5_two_terms {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ}
    (hδ0 : ∀ i, 0 ≤ δ i) (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113))
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) := by
  set p := additiveProfile R r δ a a' with hp
  set F : ℕ → ℝ := fun k => profileExpectation μm β χ f s R (p k) with hF
  set E : ℝ := Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
      + Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113)) with hE
  -- start and endpoint
  have hF0 : F 0 = profileExpectation μm β χ f s R a := by simp only [hF, hp, additiveProfile_zero]
  have hFm : F m = profileExpectation μm β χ f s R a' :=
    profileExpectation_eq_of_touchFactor_eq μm β χ f s R (touchFactor_additiveProfile_last R r δ a a' hadd)
  -- Stone 56 at each step
  have hstep : ∀ i : Fin m, |F i.val - F (i.val + 1)| ≤ δ i * Cf * Real.exp (-((n i : ℕ) : ℝ) / 2) * E :=
    fun i => abs_profileExpectation_sub_profileExpectation_le_two_terms_localized μm hβ mχ hχabs hsmall R mf hCf (hsep i) (hδ0 i)
      (fun η => (additiveProfile_mem R r δ hδ0 h0 h1 h0' h1' i.val η).1) (fun η => (additiveProfile_mem R r δ hδ0 h0 h1 h0' h1' i.val η).2)
      (fun η => (additiveProfile_mem R r δ hδ0 h0 h1 h0' h1' (i.val + 1) η).1)
      (fun η => (additiveProfile_mem R r δ hδ0 h0 h1 h0' h1' (i.val + 1) η).2)
      (step_same R r δ a a' i) (step_bound R r δ hδ0 a a' i)
  -- exponent rewrites
  have e6 : Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
      = Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) := by congr 1; ring
  have e4 : Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
      = Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) := by congr 1; ring
  calc |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'| = |F 0 - F m| := by rw [hF0, hFm]
    _ ≤ ∑ j ∈ Finset.range m, |F j - F (j + 1)| := Q5_telescope F m
    _ = ∑ i : Fin m, |F i.val - F (i.val + 1)| := Finset.sum_range _
    _ ≤ ∑ i : Fin m, δ i * Cf * Real.exp (-((n i : ℕ) : ℝ) / 2) * E := Finset.sum_le_sum (fun i _ => hstep i)
    _ = Cf * E * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) := by
        rw [Finset.mul_sum]; exact Finset.sum_congr rfl (fun i _ => by ring)
    _ = _ := by rw [hE, e6, e4]
theorem Q5_compact {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ}
    (hδ0 : ∀ i, 0 ≤ δ i) (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) := by
  -- 0 ≤ Cf derived from the majorant (own: |f (const 1)| ≤ Cf)
  have hCf0 : 0 ≤ Cf := le_trans (abs_nonneg _) (hCf (fun _ => 1))
  have hB : 0 ≤ ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (hδ0 i) (Real.exp_pos _).le)
  set D : ℝ := ((supportLinkFinset (N := N) s).card : ℝ) with hD
  have hD0 : 0 ≤ D := Nat.cast_nonneg _
  have hmono : Real.exp (4 * D / 113) ≤ Real.exp (6 * D / 113) := Real.exp_le_exp.mpr (by nlinarith)
  calc _ ≤ _ := Q5_two_terms μm hβ mχ hχabs hsmall R mf hCf hδ0 hsep h0 h1 h0' h1' hadd
    _ ≤ Cf * (Real.exp (6 * D / 113) + Real.exp (6 * D / 113)) * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) := by
        apply mul_le_mul_of_nonneg_right _ hB; apply mul_le_mul_of_nonneg_left _ hCf0; exact add_le_add_left hmono _
    _ = _ := by ring
#print axioms Q5_telescope
#print axioms Q5_two_terms
#print axioms Q5_compact
end LatticeGauge
