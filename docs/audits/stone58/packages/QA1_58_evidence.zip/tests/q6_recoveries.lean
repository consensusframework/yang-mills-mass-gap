import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q6 (QA1): RECOVERIES.
-- (a) own proof: the Stone 57 cover + non-negative budgets ⇒ hadd (zero difference included)
theorem Q6_additive_of_cover {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i)
    (a a' : Polymer N → ℝ)
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ δ i) :
    ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0 := by
  intro η
  have hnn : ∀ i ∈ (Finset.univ : Finset (Fin m)), (0:ℝ) ≤ if typedTouchesSupport (N := N) η (r i) then δ i else 0 :=
    fun i _ => by split_ifs; exact hδ0 i; exact le_rfl
  by_cases h : touchFactor R a η = touchFactor R a' η
  · rw [h, sub_self, abs_zero]; exact Finset.sum_nonneg hnn
  · obtain ⟨i, hi, hb⟩ := hcover η h
    refine le_trans hb (le_trans (le_of_eq (if_pos hi).symm) (Finset.single_le_sum hnn (Finset.mem_univ i)))
-- (b) the two Stone 57 recoveries, retyped (interface) and re-derived through the additive capstones with (a)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ}
    (hδ0 : ∀ i, 0 ≤ δ i) (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ δ i) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf hδ0 hsep h0 h1 h0' h1'
    (Q6_additive_of_cover R r δ hδ0 a a' hcover)
-- (c) TYPE comparison (definitional equality of the elaborated types, both directions): the recovered Stone 57 statements
--     vs the published Stone 57 theorems; the recovered Stone 56 statement vs the published Stone 56 capstone.
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ δ i),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_multiregion_of_additive N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ δ i),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_multiregion N _ _ G _ _ _ _ μm _ _
-- (c′) the recovered 56 statement and the published 56 capstone: same type (both directions)
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_of_additive N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized N _ _ G _ _ _ _ μm _ _
-- (d) m = 1 own derivation of the Stone 56 bound from the additive capstone: hadd from hsame/hδ, Fin 1 sum reduced on the RHS
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) := by
  have hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin 1, if typedTouchesSupport (N := N) η ((fun _ : Fin 1 => r) i) then (fun _ : Fin 1 => δ) i else 0 := by
    intro η; simp only [Fin.sum_univ_one]
    by_cases ht : typedTouchesSupport (N := N) η r
    · simpa [ht] using hδ η ht
    · simp [ht, hsame η ht]
  have h := abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf (m := 1)
    (r := fun _ => r) (n := fun _ => n) (δ := fun _ => δ) (fun _ => hδ0) (fun _ => hsep) h0 h1 h0' h1' hadd
  simp only [Fin.sum_univ_one] at h
  calc _ ≤ _ := h
    _ = _ := by ring
-- (e) EFFECTIVE application with zero budgets: the analytic estimate returns ≤ 0 (then equality); cf. Q4f
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then (fun _ : Fin m => (0:ℝ)) i else 0) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'| ≤ 0 := by
  have h := abs_profileExpectation_sub_profileExpectation_le_additive_cover_two_terms μm hβ mχ hχabs hsmall R mf hCf
    (δ := fun _ => 0) (fun _ => le_rfl) hsep h0 h1 h0' h1' hadd
  simpa using h
-- (f) classification of equalities (own): the recovered and published Stone 57 capstones are two PROOF TERMS of one
--     proposition; `rfl` between them holds by proof irrelevance (definitional), which says nothing about the bodies.
example : @abs_profileExpectation_sub_profileExpectation_le_multiregion_of_additive N _ _ G _ _ _ _ μm _ _
    = @abs_profileExpectation_sub_profileExpectation_le_multiregion N _ _ G _ _ _ _ μm _ _ := rfl
--     whereas the exponent rewrite 3·D·(2/113) = 6·D/113 is an ALGEBRAIC identity of reals (ring), not definitional
example (D : ℝ) : Real.exp (3 * D * (2/113)) = Real.exp (6 * D / 113) := by congr 1; ring
end LatticeGauge
