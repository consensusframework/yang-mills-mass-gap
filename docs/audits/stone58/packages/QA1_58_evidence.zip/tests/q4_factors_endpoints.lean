import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q4 (QA1): EFFECTIVE FACTORS AND ENDPOINTS.
-- (a) p_0 = a as profiles (own), bounds of all intermediates (retyped), hsame/hδ of each step (retyped)
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (a a' : Polymer N → ℝ) :
    additiveProfile R r δ a a' 0 = a := by
  funext η; unfold additiveProfile; split_ifs
  · unfold prefixCost; simp [move_zero]
  · rfl
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (k : ℕ) (η : Polymer N) :
    0 ≤ additiveProfile R r δ a a' k η ∧ additiveProfile R r δ a a' k η ≤ 1 :=
  additiveProfile_mem R r δ hδ0 h0 h1 h0' h1' k η
-- (b) ENDPOINT under hadd: own re-derivation (saturation of the move at the full capacity; off R both factors are 1)
theorem Q4_endpoint {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (a a' : Polymer N → ℝ)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0) (η : Polymer N) :
    touchFactor R (additiveProfile R r δ a a' m) η = touchFactor R a' η := by
  have hC : prefixCost r δ m η = ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0 := by
    unfold prefixCost regionCost; exact Finset.sum_congr rfl (fun i _ => by simp [i.isLt])
  have h := hadd η
  unfold touchFactor at h ⊢
  unfold additiveProfile
  by_cases hR : typedTouchesSupport (N := N) η R
  · simp only [hR, if_true] at h ⊢
    rw [hC]; exact move_eq_of_abs_le h
  · simp [hR]
-- (b′) and F_R(p_m) = F_R(a′) by the Stone 56 identity (arbitrary real profiles; no analytic hypothesis)
example {m : ℕ} (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ)
    (a a' : Polymer N → ℝ)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0) :
    profileExpectation μm β χ f s R (additiveProfile R r δ a a' m) = profileExpectation μm β χ f s R a' :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s R (Q4_endpoint R r δ a a' hadd)
-- (c) RAW profiles may differ off R at the end: η avoiding R with a η = 3/10, a′ η = 9/10: p_m η = 3/10 ≠ 9/10, factors 1 = 1
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (a a' : Polymer N → ℝ) (η : Polymer N)
    (hR : ¬ typedTouchesSupport (N := N) η R) (ha : a η = 3/10) (ha' : a' η = 9/10) :
    additiveProfile R r δ a a' m η ≠ a' η ∧ touchFactor R (additiveProfile R r δ a a' m) η = touchFactor R a' η := by
  constructor
  · unfold additiveProfile; rw [if_neg hR, ha, ha']; norm_num
  · unfold touchFactor; simp [hR]
-- (d) R = ∅: every effective factor is 1, hadd holds with any non-negative budgets, and F_R(a) = F_R(a′) for ARBITRARY reals
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) (a a' : Polymer N → ℝ) :
    profileExpectation μm β χ f s (∅ : Set (Link N)) a = profileExpectation μm β χ f s (∅ : Set (Link N)) a' :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s ∅ (fun η => by
    have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
    unfold touchFactor; simp [h])
example {m : ℕ} (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i) (a a' : Polymer N → ℝ) :
    ∀ η : Polymer N, |touchFactor (∅ : Set (Link N)) a η - touchFactor ∅ a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0 := by
  intro η
  have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
  unfold touchFactor; simp only [h, if_false, sub_self, abs_zero]
  exact Finset.sum_nonneg (fun i _ => by split_ifs; exact hδ0 i; exact le_rfl)
-- (e) m = 0 with real profiles OUTSIDE [0,1] (a = card + 3, a′ = −5 off R and equal on R): exact equality, no analytic hypothesis
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) :
    profileExpectation μm β χ f s R (fun η => (η.val.card : ℝ) + 3)
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then (η.val.card : ℝ) + 3 else -5) :=
  profileExpectation_eq_of_additive_cover_empty_family μm β χ f s R (r := fun i : Fin 0 => i.elim0) (δ := fun i : Fin 0 => i.elim0)
    (fun η => by unfold touchFactor; split_ifs with h <;> simp [h])
-- (f) zero budgets, real profiles: exact equality via the published interface, and via effective application of the capstone
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (a a' : Polymer N → ℝ)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' :=
  profileExpectation_eq_of_additive_cover_zero_budget μm β χ f s R (r := r) (fun η => by rw [heff η]; simp)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have h := abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf
    (δ := fun _ => 0) (fun _ => le_rfl) hsep h0 h1 h0' h1' (fun η => by rw [heff η]; simp)
  simp only [zero_mul, Finset.sum_const_zero, mul_zero] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (g) effectively equal profiles with different raw values off R: p_k is constant in k on the effective factors (own)
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (δ : Fin m → ℝ) (hδ0 : ∀ i, 0 ≤ δ i) (a a' : Polymer N → ℝ)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) (k : ℕ) (η : Polymer N) :
    touchFactor R (additiveProfile R r δ a a' k) η = touchFactor R a η := by
  have h := heff η
  unfold touchFactor at h ⊢; unfold additiveProfile
  by_cases hR : typedTouchesSupport (N := N) η R
  · simp only [hR, if_true] at h ⊢; rw [← h]; exact move_self _ _ (prefixCost_nonneg r δ hδ0 k η)
  · simp [hR]
end LatticeGauge
