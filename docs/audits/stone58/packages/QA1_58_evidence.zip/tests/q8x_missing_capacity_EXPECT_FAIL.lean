import Mathlib
import LatticeGauge.ActivityProfileDampingAdditiveCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileAdditiveCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q8x (QA1, EXPECTED TO FAIL): difference 1/2 at η₀ (a = 1/4, a′ = 3/4 there), total capacity 1/4 (budgets ![1/4, 0]).
-- (i) the additive obligation at η₀ is FALSE (proved, positive statement):
theorem Q8x_obligation_false (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (η₀ : Polymer N)
    (hR : typedTouchesSupport (N := N) η₀ R) :
    ¬ (|touchFactor R (fun _ => (1/4 : ℝ)) η₀ - touchFactor R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) η₀|
        ≤ ∑ i : Fin 2, if typedTouchesSupport (N := N) η₀ (r i) then ![(1/4 : ℝ), 0] i else 0) := by
  unfold touchFactor; rw [if_pos hR, if_pos hR]; simp only [eq_self_iff_true, if_true]
  rw [Fin.sum_univ_two]
  intro h
  have e : |(1/4 : ℝ) - 3/4| = 1/2 := by rw [show (1/4:ℝ) - 3/4 = -(1/2) by norm_num, abs_neg, abs_of_pos (by norm_num)]
  have c0 : (if typedTouchesSupport (N := N) η₀ (r 0) then ![(1/4 : ℝ), 0] 0 else 0) ≤ 1/4 := by split_ifs <;> norm_num
  have c1 : (if typedTouchesSupport (N := N) η₀ (r 1) then ![(1/4 : ℝ), 0] 1 else 0) ≤ 0 := by split_ifs <;> norm_num
  rw [e] at h; linarith
-- (ii) the application of the capstone with these budgets FAILS exactly at the hadd obligation (impossible hypothesis,
--      not a tactic weakness): the goal left is `1/2 ≤ 1/4 + 0` reduced to False.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) (r : Fin 2 → Set (Link N)) {f : Config N G → ℝ}
    (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : Fin 2 → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i))
    (η₀ : Polymer N) (hR : typedTouchesSupport (N := N) η₀ R)
    (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    |profileExpectation μm β χ f s R (fun _ => (1/4 : ℝ))
        - profileExpectation μm β χ f s R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4)|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin 2, ![(1/4 : ℝ), 0] i * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf
    (fun i => by fin_cases i <;> norm_num) hsep (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num) (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num)
    (fun η => by
      have hnn : (0:ℝ) ≤ ∑ i : Fin 2, if typedTouchesSupport (N := N) η (r i) then ![(1/4 : ℝ), 0] i else 0 :=
        Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
      by_cases h : η = η₀
      · rw [h]
        unfold touchFactor; rw [if_pos hR, if_pos hR]; simp only [eq_self_iff_true, if_true]
        rw [Fin.sum_univ_two, if_pos h0, if_pos h1]
        norm_num [abs_le]    -- hadd at η₀: 1/2 ≤ 1/4 + 0 — IMPOSSIBLE, the goal `False` remains
      · unfold touchFactor; split_ifs <;> simp only [h, if_false, sub_self, abs_zero] <;> exact hnn)
end LatticeGauge
