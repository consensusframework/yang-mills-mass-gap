-- QA1 test 2: the combination (λ, κ) = (7/8, 3) must NOT satisfy coreLocalBudget's side condition.
import Mathlib
-- expected to FAIL (this is the line the builder claims is unavailable):
example : (7/8 : ℝ) + 3 * (8/113) ≤ 1 := by norm_num
