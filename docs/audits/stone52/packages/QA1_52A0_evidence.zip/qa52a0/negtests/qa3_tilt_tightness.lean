-- QA1 test 3: the absorption x ≤ e^{δx} for all naturals needs δ ≥ 1/e ≈ 0.368.
-- 3/8 = 0.375 works (module); 1/4 does not (x = 4: 4 ≤ e^1 is false).
import Mathlib
example : ¬ (∀ x : ℕ, (x : ℝ) ≤ Real.exp ((1/4 : ℝ) * x)) := by
  intro h
  have h4 := h 4
  have := Real.exp_one_lt_d9
  norm_num at h4
  linarith
-- and the margin of 8/(3e) ≤ 1 is only ~2%: 0.98 < 8/(3e)
example : (98/100 : ℝ) < 8 / (3 * Real.exp 1) := by
  have := Real.exp_one_lt_d9
  rw [lt_div_iff₀ (by positivity)]
  nlinarith
