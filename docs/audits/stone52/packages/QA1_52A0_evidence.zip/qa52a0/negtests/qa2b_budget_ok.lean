import Mathlib
-- expected to SUCCEED: (7/8,1) and (1/2,3) fit; (7/8,3) provably does not.
example : (7/8 : ℝ) + 1 * (8/113) ≤ 1 := by norm_num
example : (1/2 : ℝ) + 3 * (8/113) ≤ 1 := by norm_num
example : ¬ ((7/8 : ℝ) + 3 * (8/113) ≤ 1) := by norm_num
