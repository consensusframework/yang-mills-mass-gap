-- QA1 test 4: the eighth budget is EXACT at the hypotheses' extremes: 64·(1/5000)/(113/625) = 8/113 (zero slack),
-- while 8/113 ≤ 1/8 has slack.
import Mathlib
example : (64 : ℝ) * (1/5000) / (113/625) = 8/113 := by norm_num
example : (8 : ℝ) / 113 < 1/8 := by norm_num
-- 1 - 512/625 = 113/625, consistent with kpR ≤ 512/625
example : (1 : ℝ) - 512/625 = 113/625 := by norm_num
