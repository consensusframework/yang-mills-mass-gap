-- QA1 test 1: is `θ ≤ 1` needed for 1 - θ^j ≤ j(1-θ)?  Bernoulli says NO for θ ≥ 0.
-- (positive control: prove the lemma with the weaker hypothesis via Mathlib's one_add_mul_le_pow)
import Mathlib
example (θ : ℝ) (h0 : 0 ≤ θ) (j : ℕ) : 1 - θ ^ j ≤ (j : ℝ) * (1 - θ) := by
  have h : (-2 : ℝ) ≤ θ - 1 := by linarith
  have := one_add_mul_le_pow h j          -- 1 + j*(θ-1) ≤ (1 + (θ-1))^j
  simp only [add_sub_cancel] at this
  linarith
-- negative control: without ANY lower bound on θ the statement is false (θ = -3, j = 3: 28 ≤ 12)
example : ¬ (∀ θ : ℝ, ∀ j : ℕ, 1 - θ ^ j ≤ (j : ℝ) * (1 - θ)) := by
  intro h
  have := h (-3) 3
  norm_num at this
