import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- T2: two remote occurrences in a tuple vs a boolean indicator.
theorem t2_two_occurrences (r : Set (Link N)) (η : Polymer N)
    (h : typedTouchesSupport (N := N) η r) :
    tupleTouchCount r (![η, η] : Fin 2 → Polymer N) = 2 := by
  rw [tupleTouchCount_eq_sum, Fin.sum_univ_two]; simp [h]
theorem t2_product (z : Polymer N → ℝ) (r : Set (Link N)) (θ : ℝ) (η : Polymer N)
    (h : typedTouchesSupport (N := N) η r) :
    (∏ i : Fin 2, dampedActivity z r θ ((![η, η] : Fin 2 → Polymer N) i)) = θ ^ 2 * (z η) ^ 2 := by
  rw [prod_dampedActivity_tuple, t2_two_occurrences r η h]; simp [pow_two]
-- a boolean indicator would give θ^1: it differs at θ = 1/2
example : ((1/2 : ℝ) ^ 2) ≠ (1/2 : ℝ) ^ 1 := by norm_num
end LatticeGauge
