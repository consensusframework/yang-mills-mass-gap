import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- T3: empty family and 0^0 = 1 — the θ = 0 weight of the empty family is 1, not 0.
example (z : Polymer N → ℝ) (r : Set (Link N)) :
    (∏ η ∈ (∅ : Finset (Polymer N)), dampedActivity z r 0 η) = 1 := by simp
example (r : Set (Link N)) : (0:ℝ) ^ touchCount (N := N) r ∅ = 1 := by
  rw [touchCount_empty]; simp
example (z : Polymer N → ℝ) (r : Set (Link N)) :
    (∏ η ∈ (∅ : Finset (Polymer N)), dampedActivity z r 0 η)
      = (if touchCount (N := N) r ∅ = 0 then ∏ η ∈ (∅ : Finset (Polymer N)), z η else 0) := by
  rw [prod_dampedActivity_zero]
end LatticeGauge
