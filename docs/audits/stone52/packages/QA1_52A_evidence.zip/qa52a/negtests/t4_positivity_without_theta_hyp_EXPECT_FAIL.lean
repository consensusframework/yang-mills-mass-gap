import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- T4: positivity without the θ-interval hypothesis: this MUST FAIL to elaborate (θ = 2 needs 2 ≤ 1).
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) (r : Set (Link N)) :
    0 < activityDampedPolymerGas μm β χ r 2 :=
  activityDampedPolymerGas_pos μm hβ mχ hχabs hsmall r (by norm_num) (by norm_num)
end LatticeGauge
