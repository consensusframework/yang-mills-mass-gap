import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- T1: θ outside [0,1] breaks domination. Conditional on a polymer touching r (no construction needed).
theorem t1_domination_fails (r : Set (Link N)) (η : Polymer N)
    (h : typedTouchesSupport (N := N) η r) :
    ¬ (|dampedActivity (fun _ => (1:ℝ)) r 2 η| ≤ |(fun _ => (1:ℝ)) η|) := by
  rw [dampedActivity_of_touches _ _ h]; norm_num
-- and the module's lemma cannot even be instantiated at θ = 2 (needs 2 ≤ 1):
example : ¬ ((2:ℝ) ≤ 1) := by norm_num
end LatticeGauge
