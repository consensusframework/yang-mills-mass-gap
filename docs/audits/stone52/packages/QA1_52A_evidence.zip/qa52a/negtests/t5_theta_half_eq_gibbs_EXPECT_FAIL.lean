import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- T5: identifying the θ = 1/2 functional with gibbsExpectation via the endpoint theorem: MUST FAIL.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    {s : Set (Link N)} {f : Config N G → ℝ} (hf : DependsOnlyOn f s) (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (r : Set (Link N)) :
    activityDampedExpectation μm β χ f s r (1/2) = gibbsExpectation (N := N) μm β χ f := by
  rw [activityDampedExpectation_one μm hβ mχ hχabs hf mf hCf r]
end LatticeGauge
