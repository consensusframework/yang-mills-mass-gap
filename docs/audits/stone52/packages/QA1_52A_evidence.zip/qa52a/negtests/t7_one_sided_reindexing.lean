import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- T7: damping only the remote part would give θ^{tc R}; the correct family weight is θ^{tc T}·θ^{tc R}.
-- For a bridge core (tc T ≥ 1) and θ = 1/2 these differ, whatever tc R.
theorem t7_one_sided_damping_wrong (m : ℕ) {j : ℕ} (hj : 0 < j) :
    (1/2 : ℝ) ^ (j + m) ≠ (1/2 : ℝ) ^ m := by
  intro h
  have : (1/2 : ℝ) ^ (j + m) < (1/2 : ℝ) ^ m :=
    pow_lt_pow_right_of_lt_one₀ (by norm_num) (by norm_num) (by omega)
  linarith
-- and in the module the weight is indeed the full-family count (numerator = denominator at f=1, s=∅):
#check @LatticeGauge.activityDampedMarkedGas_one_empty
#check @LatticeGauge.touchCount_pos_of_mem_activityBridgeCores
end LatticeGauge
