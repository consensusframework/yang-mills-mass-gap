import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- T6: additivity of the count needs disjointness: T = R = {η}, η touching r → count(T ∪ R) = 1 ≠ 2.
theorem t6_additivity_needs_disjoint (r : Set (Link N)) (η : Polymer N)
    (h : typedTouchesSupport (N := N) η r) :
    touchCount r ({η} ∪ {η} : Finset (Polymer N))
      ≠ touchCount r ({η} : Finset (Polymer N)) + touchCount r ({η} : Finset (Polymer N)) := by
  have h1 : touchCount r ({η} : Finset (Polymer N)) = 1 := by
    unfold touchCount; rw [Finset.filter_singleton, if_pos h]; simp
  rw [Finset.union_idempotent, h1]; norm_num
end LatticeGauge
