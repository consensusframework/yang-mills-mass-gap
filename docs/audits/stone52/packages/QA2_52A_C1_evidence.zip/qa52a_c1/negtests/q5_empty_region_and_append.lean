import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q5: empty region — identities derive from the real definitions (no embedded hypothesis).
example (z : Polymer N → ℝ) (θ : ℝ) (η : Polymer N) : dampedActivity (N := N) z (∅ : Set (Link N)) θ η = z η := by
  rw [dampedActivity_empty_region]
example (r : Set (Link N)) {m n : ℕ} (δ : Fin m → Polymer N) (δ' : Fin n → Polymer N) :
    tupleTouchCount r (Fin.append δ δ') = tupleTouchCount r δ + tupleTouchCount r δ' :=
  tupleTouchCount_append r δ δ'
-- append is consistent with cons on a concrete shape: append ![η] ![ζ] has count = count ![η] + count ![ζ]
example (r : Set (Link N)) (η ζ : Polymer N) :
    tupleTouchCount r (Fin.append (![η] : Fin 1 → Polymer N) (![ζ] : Fin 1 → Polymer N))
      = tupleTouchCount r (![η] : Fin 1 → Polymer N) + tupleTouchCount r (![ζ] : Fin 1 → Polymer N) :=
  tupleTouchCount_append r _ _
-- EXPECTED FAIL control: the empty-region identity is NOT true for an arbitrary region (rw must fail to close the goal)
end LatticeGauge
