import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- QA2 axioms of the ten new declarations (independent of the module's own #print list)
#print axioms dampedActivity_empty_region
#print axioms tupleTouchCount_append
#print axioms touchCount_empty_region
#print axioms tupleTouchCount_empty_region
#print axioms kpSignedUnrootedCoeff_dampedActivity
#print axioms kpConnectorUnrootedCoeff_dampedActivity
#print axioms kpSignedUnrootedCoeff_dampedActivity_one
#print axioms kpSignedUnrootedCoeff_dampedActivity_zero
#print axioms activityDampedPolymerGas_empty_region
#print axioms activityDampedMarkedGas_empty_region
end LatticeGauge
