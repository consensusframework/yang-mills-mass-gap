import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q1: k = 0 — the damped coefficient equals the undamped one (unique empty tuple, weight θ^0 = 1, 0! = 1).
theorem q1_k0 (z : Polymer N → ℝ) (r : Set (Link N)) (θ : ℝ) :
    kpSignedUnrootedCoeff (N := N) 0 (dampedActivity z r θ) = kpSignedUnrootedCoeff (N := N) 0 z := by
  rw [kpSignedUnrootedCoeff_dampedActivity]; unfold kpSignedUnrootedCoeff
  congr 1; refine Finset.sum_congr rfl (fun δ _ => ?_)
  rw [tupleTouchCount_zero]; simp
end LatticeGauge
