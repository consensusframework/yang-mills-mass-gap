import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q2: one remote occurrence in a 1-tuple gives weight θ^1; two repeated remote positions give θ^2.
theorem q2_one (r : Set (Link N)) (η : Polymer N) (h : typedTouchesSupport (N := N) η r) :
    tupleTouchCount r (![η] : Fin 1 → Polymer N) = 1 := by
  rw [tupleTouchCount_eq_sum, Fin.sum_univ_one]; simp [h]
theorem q2_two (r : Set (Link N)) (η : Polymer N) (h : typedTouchesSupport (N := N) η r) :
    tupleTouchCount r (![η, η] : Fin 2 → Polymer N) = 2 := by
  rw [tupleTouchCount_eq_sum, Fin.sum_univ_two]; simp [h]
-- and a mixed tuple (remote, allowed) gives 1, not 2 and not 0
theorem q2_mixed (r : Set (Link N)) (η ζ : Polymer N) (h : typedTouchesSupport (N := N) η r)
    (ha : regionAllowed (N := N) r ζ) :
    tupleTouchCount r (![η, ζ] : Fin 2 → Polymer N) = 1 := by
  rw [tupleTouchCount_eq_sum, Fin.sum_univ_two]; simp [h, regionAllowed_iff.mp ha]
end LatticeGauge
