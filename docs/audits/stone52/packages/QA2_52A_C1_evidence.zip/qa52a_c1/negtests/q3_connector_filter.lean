import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q3: connector filter true/false — the damped connector summand is θ^count·(summand) when the filter holds and 0 otherwise.
theorem q3_filter (k : ℕ) (z : Polymer N → ℝ) (P Q : Polymer N → Prop) (r : Set (Link N)) (θ : ℝ)
    (δ : Fin k → Polymer N) :
    (if TupleHitsBothForbidden P Q δ then
        θ ^ tupleTouchCount r δ * (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin k, z (δ i))
      else 0)
    = (if TupleHitsBothForbidden P Q δ then
        ((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin k, dampedActivity z r θ (δ i)
      else 0) := by
  split_ifs
  · rw [prod_dampedActivity_tuple]; ring
  · rfl
-- the filter itself is untouched by damping: the identity keeps the literal predicate on the ORIGINAL tuple
example (k : ℕ) (z : Polymer N → ℝ) (P Q : Polymer N → Prop) (r : Set (Link N)) (θ : ℝ) :
    kpConnectorUnrootedCoeff (N := N) k (dampedActivity z r θ) P Q
      = (∑ δ : Fin k → Polymer N, if TupleHitsBothForbidden P Q δ then
          θ ^ tupleTouchCount r δ * (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin k, z (δ i)) else 0)
        / ((Nat.factorial k : ℕ) : ℝ) :=
  kpConnectorUnrootedCoeff_dampedActivity k z P Q r θ
end LatticeGauge
