import Mathlib
import LatticeGauge.ActivityDampedObservableGas
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q4: k = 2 — the denominator is literally 2, not silently 1.
theorem q4_factorial_two (z : Polymer N → ℝ) (r : Set (Link N)) (θ : ℝ) :
    kpSignedUnrootedCoeff (N := N) 2 (dampedActivity z r θ)
      = (∑ δ : Fin 2 → Polymer N,
          θ ^ tupleTouchCount r δ * (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin 2, z (δ i))) / 2 := by
  rw [kpSignedUnrootedCoeff_dampedActivity]; norm_num [Nat.factorial]
example : ((Nat.factorial 3 : ℕ) : ℝ) = 6 := by norm_num [Nat.factorial]
end LatticeGauge
