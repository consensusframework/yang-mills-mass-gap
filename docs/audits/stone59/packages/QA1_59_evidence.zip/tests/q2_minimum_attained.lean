import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q2 (QA1): THE MINIMUM IS ATTAINED, without hidden hypotheses.
-- Reused topological auxiliaries (already audited by reading): Mathlib `isCompact_Icc`, `IsCompact.inter_right`,
-- `isClosed_iInter`, `isClosed_le`, `continuous_finset_sum`, `continuous_apply`, `IsCompact.exists_isMinOn`, `isMinOn_iff`.
-- Re-derived here: closedness of the cover set (intersection over ALL polymers, no Fintype (Polymer N)), compactness of
-- the box ∩ cover, non-emptiness under reach, continuity of the cost, the existence on the box, and the promotion to a
-- minimum over ALL admissible budgets by truncation. `exists_optimal` is NOT called.
theorem Q2_isClosed {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (a a' : Polymer N → ℝ) :
    _root_.IsClosed {δ : Fin m → ℝ | AdditiveCover R r a a' δ} := by
  have : {δ : Fin m → ℝ | AdditiveCover R r a a' δ}
      = ⋂ η : Polymer N, {δ : Fin m → ℝ | |touchFactor R a η - touchFactor R a' η|
          ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0} := by
    ext δ; simp only [Set.mem_setOf_eq, Set.mem_iInter, AdditiveCover]
  rw [this]
  refine isClosed_iInter (fun η => isClosed_le continuous_const (continuous_finset_sum _ (fun i _ => ?_)))
  by_cases ht : typedTouchesSupport (N := N) η (r i)
  · simpa [ht] using continuous_apply i
  · simp [ht]; exact continuous_const
theorem Q2_isCompact {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (a a' : Polymer N → ℝ) :
    IsCompact (Set.Icc (0 : Fin m → ℝ) 1 ∩ {δ | AdditiveCover R r a a' δ}) :=
  isCompact_Icc.inter_right (Q2_isClosed R r a a')
theorem Q2_continuous {m : ℕ} (n : Fin m → ℕ) : Continuous (budget n) := by
  unfold budget; exact continuous_finset_sum _ (fun i _ => (continuous_apply i).mul continuous_const)
-- own existence: minimum on the box, then promoted to all admissible budgets by truncation (own Q1-style clip lemmas inline)
theorem Q2_exists {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a') :
    ∃ δs : Fin m → ℝ, Admissible R r a a' δs ∧ (∀ i, δs i ≤ 1) ∧ ∀ δ, Admissible R r a a' δ → budget n δs ≤ budget n δ := by
  -- non-empty: the unit budget (reach + d ≤ 1); reused: admissible_one_of_reaches (its content is Q1_reach_iff, own)
  have hne : (Set.Icc (0 : Fin m → ℝ) 1 ∩ {δ | AdditiveCover R r a a' δ}).Nonempty :=
    ⟨fun _ => 1, ⟨Set.mem_Icc.mpr ⟨fun i => by simp, fun i => le_rfl⟩, (admissible_one_of_reaches R r h0 h1 h0' h1' hreach).2⟩⟩
  obtain ⟨δs, hδs, hmin⟩ := (Q2_isCompact R r a a').exists_isMinOn hne (Q2_continuous n).continuousOn
  have hbox := Set.mem_Icc.mp hδs.1
  refine ⟨δs, ⟨fun i => by simpa using hbox.1 i, hδs.2⟩, fun i => hbox.2 i, fun δ hδ => ?_⟩
  -- promotion: clip δ lies in the box ∩ cover (admissible_clip reused: its content is Q1_clip_cover, own) and costs ≤ δ
  have hclip : clip δ ∈ Set.Icc (0 : Fin m → ℝ) 1 ∩ {δ | AdditiveCover R r a a' δ} :=
    ⟨Set.mem_Icc.mpr ⟨fun i => by simpa using clip_nonneg hδ.1 i, fun i => clip_le_one δ i⟩, (admissible_clip R r h0 h1 h0' h1' hδ).2⟩
  have hcost : budget n (clip δ) ≤ budget n δ := by
    unfold budget; exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_right (min_le_left _ _) (Real.exp_pos _).le)
  exact le_trans (isMinOn_iff.mp hmin _ hclip) hcost
-- (d) m = 0 in this construction: the box is the singleton, compact and non-empty; the cost is 0; reach forces equality
example (R : Set (Link N)) (r : Fin 0 → Set (Link N)) (a a' : Polymer N → ℝ) :
    IsCompact (Set.Icc (0 : Fin 0 → ℝ) 1 ∩ {δ | AdditiveCover R r a a' δ}) := Q2_isCompact R r a a'
example (R : Set (Link N)) (r : Fin 0 → Set (Link N)) (n : Fin 0 → ℕ) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a') :
    ∃ δs : Fin 0 → ℝ, Admissible R r a a' δs ∧ budget n δs = 0 := by
  obtain ⟨δs, hadm, _, _⟩ := Q2_exists R r n h0 h1 h0' h1' hreach
  exact ⟨δs, hadm, by unfold budget; simp⟩
-- (e) the unrestricted set of non-negative budgets is not compact and the cost is unbounded on it (m = 1, weight 1):
--     for every C there is a non-negative budget of cost > C — hence the minimum is sought on the box and promoted (own)
example : ∀ C : ℝ, ∃ δ : Fin 1 → ℝ, (∀ i, 0 ≤ δ i) ∧ C < budget (fun _ => 0) δ := by
  intro C
  refine ⟨fun _ => max C 0 + 1, fun _ => by positivity, ?_⟩
  unfold budget; simp [Fin.sum_univ_one]
  linarith [le_max_left C 0]
#print axioms Q2_isClosed
#print axioms Q2_isCompact
#print axioms Q2_continuous
#print axioms Q2_exists
end LatticeGauge
