import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q1 (QA1): FEASIBILITY AND TRUNCATION, re-derived from the real definitions (unfolding AdditiveCover/Admissible/Reaches/
-- clip/budget), not by applying the candidate's theorems.
-- (a) reach ↔ ∃ admissible budget (own)
theorem Q1_reach_iff {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) :
    Reaches R r a a' ↔ ∃ δ : Fin m → ℝ, Admissible R r a a' δ := by
  constructor
  · intro hreach
    refine ⟨fun _ => 1, fun _ => zero_le_one, fun η => ?_⟩
    -- the unit budget: every effective change is ≤ 1 and some touched term equals 1
    have hd : |touchFactor R a η - touchFactor R a' η| ≤ 1 := by
      have := touchFactor_nonneg R h0 η; have := touchFactor_le_one R h1 η
      have := touchFactor_nonneg R h0' η; have := touchFactor_le_one R h1' η
      rw [abs_le]; constructor <;> linarith
    have hnn : ∀ j ∈ (Finset.univ : Finset (Fin m)), (0:ℝ) ≤ if typedTouchesSupport (N := N) η (r j) then (fun _ : Fin m => (1:ℝ)) j else 0 :=
      fun j _ => by split_ifs <;> norm_num
    by_cases hne : touchFactor R a η = touchFactor R a' η
    · rw [hne, sub_self, abs_zero]; exact Finset.sum_nonneg hnn
    · obtain ⟨i, hi⟩ := hreach η hne
      calc |touchFactor R a η - touchFactor R a' η| ≤ 1 := hd
        _ = (if typedTouchesSupport (N := N) η (r i) then (fun _ : Fin m => (1:ℝ)) i else 0) := by simp [hi]
        _ ≤ _ := Finset.single_le_sum hnn (Finset.mem_univ i)
  · rintro ⟨δ, hδ0, hcov⟩ η hne
    by_contra hno; push_neg at hno
    have h := hcov η
    rw [Finset.sum_eq_zero (fun i _ => if_neg (hno i))] at h
    exact hne (sub_eq_zero.mp (abs_nonpos_iff.mp h))
-- (b) truncation keeps the cover (own, two cases per polymer); REQUIRES d ≤ 1 (profiles in [0,1])
theorem Q1_clip_cover {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    {δ : Fin m → ℝ} (hδ : Admissible R r a a' δ) : Admissible R r a a' (fun i => min (δ i) 1) := by
  refine ⟨fun i => le_min (hδ.1 i) zero_le_one, fun η => ?_⟩
  have hd : |touchFactor R a η - touchFactor R a' η| ≤ 1 := by
    have := touchFactor_nonneg R h0 η; have := touchFactor_le_one R h1 η
    have := touchFactor_nonneg R h0' η; have := touchFactor_le_one R h1' η
    rw [abs_le]; constructor <;> linarith
  by_cases hbig : ∃ i, typedTouchesSupport (N := N) η (r i) ∧ 1 ≤ δ i
  · -- some touched region pays at least 1: its truncated term is 1 and covers alone
    obtain ⟨i, hi, h1i⟩ := hbig
    have hnn : ∀ j ∈ (Finset.univ : Finset (Fin m)), (0:ℝ) ≤ if typedTouchesSupport (N := N) η (r j) then min (δ j) 1 else 0 :=
      fun j _ => by split_ifs; exact le_min (hδ.1 j) zero_le_one; exact le_rfl
    calc _ ≤ (1:ℝ) := hd
      _ = (if typedTouchesSupport (N := N) η (r i) then min (δ i) 1 else 0) := by simp [hi, min_eq_right h1i]
      _ ≤ _ := Finset.single_le_sum hnn (Finset.mem_univ i)
  · -- no touched region pays 1: every touched term is unchanged, so the sum is the original one
    push_neg at hbig
    have : (∑ j : Fin m, if typedTouchesSupport (N := N) η (r j) then min (δ j) 1 else 0)
        = ∑ j : Fin m, if typedTouchesSupport (N := N) η (r j) then δ j else 0 :=
      Finset.sum_congr rfl (fun j _ => by
        by_cases ht : typedTouchesSupport (N := N) η (r j)
        · simp [ht, min_eq_left (le_of_lt (hbig j ht))]
        · simp [ht])
    rw [this]; exact hδ.2 η
-- (c) truncation does not increase the cost (own, positivity of the weights)
theorem Q1_clip_cost {m : ℕ} (n : Fin m → ℕ) (δ : Fin m → ℝ) : budget n (fun i => min (δ i) 1) ≤ budget n δ := by
  unfold budget
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_right (min_le_left _ _) (Real.exp_pos _).le)
-- (d) numeric: budget 7 → 1, 0 → 0, boundary 1 → 1, partial 1/4 → 1/4 (scalar instances of clip)
example : clip (fun _ : Fin 1 => (7:ℝ)) 0 = 1 := by unfold clip; norm_num
example : clip (fun _ : Fin 1 => (0:ℝ)) 0 = 0 := by unfold clip; norm_num
example : clip (fun _ : Fin 1 => (1:ℝ)) 0 = 1 := by unfold clip; norm_num
example : clip (fun _ : Fin 1 => (1/4:ℝ)) 0 = 1/4 := by unfold clip; norm_num
-- (e) NECESSITY of d ≤ 1: with raw profiles OUTSIDE [0,1] (a η₀ = 0, a′ η₀ = 2, η₀ touching R and r 0) the single
--     budget δ = 2 covers the change 2 at η₀, but its truncation 1 does not. Stated at ONE polymer (scalar admissibility),
--     not as global admissibility; it shows why the interval enters admissible_clip.
example (R : Set (Link N)) (r : Fin 1 → Set (Link N)) (η₀ : Polymer N) (hR : typedTouchesSupport (N := N) η₀ R)
    (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (a a' : Polymer N → ℝ) (ha : a η₀ = 0) (ha' : a' η₀ = 2) :
    (|touchFactor R a η₀ - touchFactor R a' η₀| ≤ ∑ i : Fin 1, if typedTouchesSupport (N := N) η₀ (r i) then (fun _ => (2:ℝ)) i else 0)
    ∧ ¬ (|touchFactor R a η₀ - touchFactor R a' η₀| ≤ ∑ i : Fin 1, if typedTouchesSupport (N := N) η₀ (r i) then clip (fun _ => (2:ℝ)) i else 0) := by
  unfold touchFactor; rw [if_pos hR, if_pos hR, ha, ha']
  simp only [Fin.sum_univ_one, if_pos h0]; unfold clip; norm_num [abs_le]
-- (f) the candidate's statements, retyped (interface)
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) {δ : Fin m → ℝ}
    (h : Admissible R r a a' δ) : Admissible R r a a' (clip δ) := admissible_clip R r h0 h1 h0' h1' h
example {m : ℕ} (n : Fin m → ℕ) (δ : Fin m → ℝ) : budget n (clip δ) ≤ budget n δ := budget_clip_le n δ
-- (g) the candidate's clip is definitionally my pointwise min (so (b),(c) are statements about the same object)
example {m : ℕ} (δ : Fin m → ℝ) : clip δ = fun i => min (δ i) 1 := rfl
end LatticeGauge
