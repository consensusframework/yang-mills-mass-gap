import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q6 (QA1): INDEPENDENT CLOSURE AND RECOVERIES. (a) a minimizer from the existence theorem (reused: exists_optimal,
-- i.e. the published existence, which Q2 re-derived); the published Stone 58 estimates applied DIRECTLY to it; both
-- forms closed and compared with ANY admissible budget by minimality and signs. NOT used: the two new capstones,
-- the two comparison lemmas, the two _of_optimal wrappers, minCost/optimalBudget.
theorem Q6_closure {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a') :
    ∃ δs : Fin m → ℝ, Admissible R r a a' δs ∧
      (|profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
          ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
                  + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) * budget n δs)
      ∧ (|profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
          ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * budget n δs)
      ∧ (∀ δ, Admissible R r a a' δ →
          Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
                  + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) * budget n δs
            ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
                  + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) * budget n δ)
      ∧ (∀ δ, Admissible R r a a' δ →
          (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * budget n δs
            ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * budget n δ) := by
  obtain ⟨δs, hadm, _, hmin⟩ := exists_optimal R r n h0 h1 h0' h1' hreach
  have hCf0 : 0 ≤ Cf := le_trans (abs_nonneg _) (hCf (fun _ => 1))
  refine ⟨δs, hadm, ?_, ?_, fun δ hδ => ?_, fun δ hδ => ?_⟩
  · exact abs_profileExpectation_sub_profileExpectation_le_additive_cover_two_terms μm hβ mχ hχabs hsmall R mf hCf hadm.1 hsep
      h0 h1 h0' h1' hadm.2
  · exact abs_profileExpectation_sub_profileExpectation_le_additive_cover μm hβ mχ hχabs hsmall R mf hCf hadm.1 hsep
      h0 h1 h0' h1' hadm.2
  · exact mul_le_mul_of_nonneg_left (hmin δ hδ) (mul_nonneg hCf0 (add_pos (Real.exp_pos _) (Real.exp_pos _)).le)
  · exact mul_le_mul_of_nonneg_left (hmin δ hδ) (mul_nonneg (by linarith) (Real.exp_pos _).le)
#print axioms Q6_closure
-- (b) EXPLICIT applications of both recoveries with a budget larger than 1: δ ≡ 7 (no truncation on the Stone 58 route)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a') :
    (|profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113))
          * ∑ i : Fin m, (7 : ℝ) * Real.exp (-((n i : ℕ) : ℝ) / 2))
    ∧ (|profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, (7 : ℝ) * Real.exp (-((n i : ℕ) : ℝ) / 2)) := by
  -- δ ≡ 7 is admissible under reach (every change ≤ 1 ≤ 7 on a touched term)
  have hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then (fun _ : Fin m => (7:ℝ)) i else 0 := by
    intro η
    have hnn : ∀ j ∈ (Finset.univ : Finset (Fin m)), (0:ℝ) ≤ if typedTouchesSupport (N := N) η (r j) then (fun _ : Fin m => (7:ℝ)) j else 0 :=
      fun j _ => by split_ifs <;> norm_num
    by_cases hne : touchFactor R a η = touchFactor R a' η
    · rw [hne, sub_self, abs_zero]; exact Finset.sum_nonneg hnn
    · obtain ⟨i, hi⟩ := hreach η hne
      calc _ ≤ (1:ℝ) := abs_touchFactor_sub_le_one R h0 h1 h0' h1' η
        _ ≤ (if typedTouchesSupport (N := N) η (r i) then (fun _ : Fin m => (7:ℝ)) i else 0) := by simp [hi]
        _ ≤ _ := Finset.single_le_sum hnn (Finset.mem_univ i)
  exact ⟨abs_profileExpectation_sub_profileExpectation_le_additive_cover_two_terms_of_optimal μm hβ mχ hχabs hsmall R mf hCf
      (δ := fun _ => 7) (fun _ => by norm_num) hsep h0 h1 h0' h1' hadd,
    abs_profileExpectation_sub_profileExpectation_le_additive_cover_of_optimal μm hβ mχ hχabs hsmall R mf hCf
      (δ := fun _ => 7) (fun _ => by norm_num) hsep h0 h1 h0' h1' hadd⟩
-- (c) SIGNATURES side by side: the recovered statements have the TYPES of the Stone 58 theorems (both directions, defeq)
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_additive_cover_of_optimal N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_additive_cover N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113))
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_additive_cover_two_terms_of_optimal N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ} (hδ0 : ∀ i, 0 ≤ δ i)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hadd : ∀ η : Polymer N, |touchFactor R a η - touchFactor R a' η|
      ≤ ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ i else 0),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113))
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_additive_cover_two_terms N _ _ G _ _ _ _ μm _ _
end LatticeGauge
