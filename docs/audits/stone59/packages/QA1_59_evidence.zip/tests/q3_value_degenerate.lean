import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q3 (QA1): VALUE, CHOICE AND DEGENERATE CASES (and Q7 items: non-unit common factors, raw differences off R).
-- (a) any two minimizers have the same cost (own)
theorem Q3_eq_cost {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a a' : Polymer N → ℝ}
    {δ₁ δ₂ : Fin m → ℝ} (h₁ : Admissible R r a a' δ₁) (h₂ : Admissible R r a a' δ₂)
    (m₁ : ∀ δ, Admissible R r a a' δ → budget n δ₁ ≤ budget n δ) (m₂ : ∀ δ, Admissible R r a a' δ → budget n δ₂ ≤ budget n δ) :
    budget n δ₁ = budget n δ₂ := le_antisymm (m₁ δ₂ h₂) (m₂ δ₁ h₁)
-- (b) B* = 0 ↔ equal effective factors (own, via the published interface lemmas minCost_le_budget / optimalBudget_admissible
--     / minCost_nonneg only; strictly positive weights and a finite non-negative sum)
theorem Q3_zero_iff {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a') :
    minCost R r n h0 h1 h0' h1' hreach = 0 ↔ ∀ η, touchFactor R a η = touchFactor R a' η := by
  constructor
  · intro hz η
    have hadm := optimalBudget_admissible R r n h0 h1 h0' h1' hreach
    set δs := optimalBudget R r n h0 h1 h0' h1' hreach
    -- each term δs i · w i ≥ 0 with sum 0 ⇒ each term 0 ⇒ δs i = 0 (w i > 0)
    have hz0 : ∑ i : Fin m, δs i * Real.exp (-((n i : ℕ) : ℝ) / 2) = 0 := hz
    have hall := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => mul_nonneg (hadm.1 i) (Real.exp_pos (-((n i : ℕ) : ℝ) / 2)).le)).mp hz0
    have hz' : ∀ i, δs i = 0 := fun i => by
      rcases mul_eq_zero.mp (hall i (Finset.mem_univ i)) with h | h
      · exact h
      · exact absurd h (Real.exp_pos _).ne'
    have hc := hadm.2 η
    rw [Finset.sum_eq_zero (fun i _ => by rw [hz' i]; split_ifs <;> rfl)] at hc
    exact sub_eq_zero.mp (abs_nonpos_iff.mp hc)
  · intro hb
    have hadm0 : Admissible R r a a' (fun _ => 0) :=
      ⟨fun _ => le_rfl, fun η => by rw [hb η, sub_self, abs_zero]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> exact le_rfl)⟩
    have hle := minCost_le_budget R r n h0 h1 h0' h1' hreach hadm0
    have hb0 : budget n (fun _ => (0:ℝ)) = 0 := by unfold budget; simp
    rw [hb0] at hle
    exact le_antisymm hle (minCost_nonneg R r n h0 h1 h0' h1' hreach)
-- (c) m = 0: effective application — cost 0 and F_R equality; raw profiles DISTINCT off R (a′ = −7 there)
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (a : Polymer N → ℝ) :
    profileExpectation μm β χ f s R a
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then a η else -7) :=
  profileExpectation_eq_of_reaches_fin_zero μm β χ f s R (r := fun i : Fin 0 => i.elim0)
    (fun η hne => absurd (by unfold touchFactor; split_ifs with h <;> simp [h]) hne)
example (n : Fin 0 → ℕ) (δ : Fin 0 → ℝ) : budget n δ = 0 := by unfold budget; simp
-- (c′) m = 0 through minCost (domain: profiles in [0,1] and reach required by the definition of the chosen cost)
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (n : Fin 0 → ℕ) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hreach : Reaches R (fun i : Fin 0 => i.elim0) a a') :
    minCost R (fun i : Fin 0 => i.elim0) n h0 h1 h0' h1' hreach = 0
    ∧ profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have hz : minCost R (fun i : Fin 0 => i.elim0) n h0 h1 h0' h1' hreach = 0 := by
    unfold minCost budget; simp
  exact ⟨hz, profileExpectation_eq_of_minCost_eq_zero μm β χ f s R n h0 h1 h0' h1' hreach hz⟩
-- (d) R = ∅ with raw profiles DISTINCT (a = 1/3, a′ = 2/3 everywhere): reach holds, B* = 0, F equal (effective application)
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) :
    minCost (∅ : Set (Link N)) r n (a := fun _ => (1/3 : ℝ)) (a' := fun _ => (2/3 : ℝ))
        (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (reaches_empty_region r _ _) = 0
    ∧ profileExpectation μm β χ f s (∅ : Set (Link N)) (fun _ => (1/3 : ℝ)) = profileExpectation μm β χ f s ∅ (fun _ => (2/3 : ℝ)) := by
  have hz := (minCost_eq_zero_iff (∅ : Set (Link N)) r n (a := fun _ => (1/3 : ℝ)) (a' := fun _ => (2/3 : ℝ))
    (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (reaches_empty_region r _ _)).mpr
    (fun η => by
      have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
      unfold touchFactor; simp [h])
  exact ⟨hz, profileExpectation_eq_of_minCost_eq_zero μm β χ f s ∅ n _ _ _ _ _ hz⟩
-- (e) Q7: non-unit common factor (a = a′ = 1/2 on R-touching polymers) and raw differences ignored off R: equal effective
--     factors ⇒ the zero budget is admissible, B* = 0, and F_R equal — while raw a ≠ a′ off R
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) :
    let a : Polymer N → ℝ := fun _ => 1/2
    let a' : Polymer N → ℝ := fun η => if typedTouchesSupport (N := N) η R then 1/2 else 1
    ∀ (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1) (hreach : Reaches R r a a'),
      minCost R r n h0 h1 h0' h1' hreach = 0 ∧ profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  intro a a' h0 h1 h0' h1' hreach
  have heff : ∀ η, touchFactor R a η = touchFactor R a' η := fun η => by
    unfold touchFactor; split_ifs with h <;> simp [a, a', h]
  have hz := (minCost_eq_zero_iff R r n h0 h1 h0' h1' hreach).mpr heff
  exact ⟨hz, profileExpectation_eq_of_minCost_eq_zero μm β χ f s R n h0 h1 h0' h1' hreach hz⟩
-- (f) the algebraic identities admit arbitrary real profiles (no [0,1]): e.g. the Stone 58 identity used by the endpoints
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (a a' : Polymer N → ℝ)
    (hb : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := profileExpectation_eq_of_touchFactor_eq μm β χ f s R hb
-- (g) classification: an equality of two proof terms of one proposition closes by proof irrelevance (definitional), which is
--     not a syntactic identity of the proofs; the retyping below is such an equality (two names, one Prop)
example : @ActivityProfileOptimalCover.budget_eq_of_isMin = @Q3_eq_cost := rfl
#print axioms Q3_zero_iff
end LatticeGauge
