import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q4 (QA1): GLOBAL WITNESS AND STRICT IMPROVEMENT. Contacts of η₀ with R, r 0, r 1 are HYPOTHESES (no lattice is built).
section
variable (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (η₀ : Polymer N)
noncomputable def qa (_ : Polymer N) : ℝ := 1/4
noncomputable def qa' (η₀ : Polymer N) (η : Polymer N) : ℝ := if η = η₀ then 3/4 else 1/4
theorem Q4_mem : (∀ η, 0 ≤ qa (N := N) η) ∧ (∀ η, qa (N := N) η ≤ 1) ∧ (∀ η, 0 ≤ qa' η₀ η) ∧ (∀ η, qa' η₀ η ≤ 1) := by
  refine ⟨fun _ => by unfold qa; norm_num, fun _ => by unfold qa; norm_num, fun η => ?_, fun η => ?_⟩ <;>
    (unfold qa'; split_ifs <;> norm_num)
-- the effective change: 1/2 at η₀ (touching R), 0 elsewhere
theorem Q4_diff (hR : typedTouchesSupport (N := N) η₀ R) (η : Polymer N) :
    |touchFactor R qa η - touchFactor R (qa' η₀) η| = if η = η₀ then 1/2 else 0 := by
  unfold touchFactor qa qa'
  by_cases h : η = η₀
  · subst h; simp [hR]; norm_num [abs_le]
  · simp [h]
-- (a) ADMISSIBILITY FOR ALL POLYMERS of (1/4,1/4) and (0,1/2)
theorem Q4_adm_quarter (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) : Admissible R r qa (qa' η₀) ![(1/4 : ℝ), 1/4] := by
  refine ⟨fun i => by fin_cases i <;> norm_num, fun η => ?_⟩
  rw [Q4_diff R η₀ hR]
  by_cases h : η = η₀
  · subst h; simp only [if_true]; rw [Fin.sum_univ_two, if_pos h0, if_pos h1]; norm_num
  · simp only [h, if_false]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
theorem Q4_adm_half (hR : typedTouchesSupport (N := N) η₀ R) (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    Admissible R r qa (qa' η₀) ![(0 : ℝ), 1/2] := by
  refine ⟨fun i => by fin_cases i <;> norm_num, fun η => ?_⟩
  rw [Q4_diff R η₀ hR]
  by_cases h : η = η₀
  · subst h; simp only [if_true]; rw [Fin.sum_univ_two, if_pos h1]; split_ifs <;> norm_num
  · simp only [h, if_false]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
-- (b) every admissible budget satisfies δ 0 + δ 1 ≥ 1/2 (from the constraint at η₀ only, plus non-negativity)
theorem Q4_constraint (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) {δ : Fin 2 → ℝ} (hδ : Admissible R r qa (qa' η₀) δ) : 1/2 ≤ δ 0 + δ 1 := by
  have h := hδ.2 η₀
  rw [Q4_diff R η₀ hR, if_pos rfl, Fin.sum_univ_two, if_pos h0, if_pos h1] at h
  exact h
-- (c) lower bound of the cost with n = (0,4): δ 0 + δ 1·e^{−2} ≥ (δ 0 + δ 1)·e^{−2} ≥ (1/2)e^{−2}; exact value B* = (1/2)e^{−2}
theorem Q4_lower (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) {δ : Fin 2 → ℝ} (hδ : Admissible R r qa (qa' η₀) δ) :
    (1/2 : ℝ) * Real.exp (-2) ≤ budget ![0, 4] δ := by
  have hc := Q4_constraint R r η₀ hR h0 h1 hδ
  have he : Real.exp (-2) ≤ 1 := by
    have := Real.exp_le_exp.mpr (show (-2:ℝ) ≤ 0 by norm_num); simpa using this
  have hpos : 0 < Real.exp (-2) := Real.exp_pos _
  unfold budget; rw [Fin.sum_univ_two]; simp only [Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
  rw [show (-((0:ℕ):ℝ)/2) = 0 by norm_num, show (-((4:ℕ):ℝ)/2) = -2 by norm_num, Real.exp_zero]
  have h0' := hδ.1 0
  nlinarith [mul_le_mul_of_nonneg_left he h0', mul_nonneg h0' hpos.le]
theorem Q4_minCost (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    minCost R r ![0, 4] (Q4_mem (N := N) η₀).1 (Q4_mem η₀).2.1 (Q4_mem η₀).2.2.1 (Q4_mem η₀).2.2.2
        (reaches_of_admissible R r (Q4_adm_half R r η₀ hR h1)) = (1/2 : ℝ) * Real.exp (-2) := by
  rw [minCost_eq_budget_of_isMin R r ![0, 4] _ _ _ _ _ (Q4_adm_half R r η₀ hR h1) (fun δ hδ => ?_)]
  · unfold budget; rw [Fin.sum_univ_two]; simp only [Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    rw [show (-((4:ℕ):ℝ)/2) = -2 by norm_num]; ring
  · -- (0,1/2) is a minimizer: its cost is exactly the lower bound
    have : budget ![0, 4] ![(0:ℝ), 1/2] = (1/2 : ℝ) * Real.exp (-2) := by
      unfold budget; rw [Fin.sum_univ_two]; simp only [Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
      rw [show (-((4:ℕ):ℝ)/2) = -2 by norm_num]; ring
    rw [this]; exact Q4_lower R r η₀ hR h0 h1 hδ
-- (d) strict: B* = (1/2)e^{−2} < 1/4 + (1/4)e^{−2} = cost of (1/4,1/4)
theorem Q4_strict : (1/2 : ℝ) * Real.exp (-2) < 1/4 + (1/4) * Real.exp (-2) := by
  have : Real.exp (-2) < 1 := by
    have := Real.exp_lt_exp.mpr (show (-2:ℝ) < 0 by norm_num); simpa using this
  linarith
example : budget ![0, 4] ![(1/4 : ℝ), 1/4] = 1/4 + (1/4) * Real.exp (-2) := by
  unfold budget; rw [Fin.sum_univ_two]; simp only [Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
  rw [show (-((0:ℕ):ℝ)/2) = 0 by norm_num, show (-((4:ℕ):ℝ)/2) = -2 by norm_num, Real.exp_zero]; ring
-- (e) the COMPLETE compact right-hand sides: strict with Cf > 0; degenerate (both 0) with Cf = 0
example (Cf D : ℝ) (hCf : 0 < Cf) :
    (2 * Cf) * Real.exp (6 * D / 113) * ((1/2 : ℝ) * Real.exp (-2))
      < (2 * Cf) * Real.exp (6 * D / 113) * (1/4 + (1/4) * Real.exp (-2)) :=
  mul_lt_mul_of_pos_left Q4_strict (mul_pos (by linarith) (Real.exp_pos _))
example (D : ℝ) :
    (2 * (0:ℝ)) * Real.exp (6 * D / 113) * ((1/2 : ℝ) * Real.exp (-2))
      = (2 * (0:ℝ)) * Real.exp (6 * D / 113) * (1/4 + (1/4) * Real.exp (-2)) := by ring
-- (f) scope: the strict comparison is against this particular budget (1/4,1/4), not against every admissible budget
--     (indeed B* ≤ every admissible cost, with equality for (0,1/2)); and B* is a bound, not the deviation of F_R.
end
end LatticeGauge
