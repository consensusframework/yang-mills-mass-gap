import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q8x (QA1, EXPECTED TO FAIL): effective change 1/2 at η₀, which touches R but NO region of the family.
section
variable (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (η₀ : Polymer N)
  (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i))
-- (i) POSITIVE statements: no admissible budget exists, and Reaches is false
theorem Q8x_no_admissible (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ¬ ∃ δ : Fin m → ℝ, Admissible R r (fun _ => (1/4 : ℝ)) (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) δ := by
  rintro ⟨δ, _, hcov⟩
  have h := hcov η₀
  unfold touchFactor at h; rw [if_pos hR, if_pos hR] at h; simp only [eq_self_iff_true, if_true] at h
  rw [Finset.sum_eq_zero (fun i _ => if_neg (hno i))] at h
  norm_num [abs_le] at h
theorem Q8x_reach_false (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ¬ Reaches R r (fun _ => (1/4 : ℝ)) (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) := by
  intro hreach
  have hne : touchFactor R (fun _ => (1/4 : ℝ)) η₀ ≠ touchFactor R (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) η₀ := by
    unfold touchFactor; rw [if_pos hR, if_pos hR]; simp only [eq_self_iff_true, if_true]; norm_num
  obtain ⟨i, hi⟩ := hreach η₀ hne
  exact hno i hi
-- (ii) the application WITHOUT the necessary hypothesis (m = 1): building the reach obligation required by
--      `exists_optimal` for these profiles leaves exactly ONE goal, `typedTouchesSupport η₀ (r 0)`, which is the negation
--      of hno 0 — an impossible hypothesis, not a tactic weakness. (Expected: a single error at `assumption`.)
example (r₁ : Fin 1 → Set (Link N)) (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r₁ i))
    (n : Fin 1 → ℕ) :
    ∃ δs : Fin 1 → ℝ, Admissible R r₁ (fun _ => (1/4 : ℝ)) (fun η => if η = η₀ then (3/4 : ℝ) else 1/4) δs :=
  let h := exists_optimal R r₁ n (a := fun _ => (1/4 : ℝ)) (a' := fun η => if η = η₀ then (3/4 : ℝ) else 1/4)
    (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num) (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num)
    (fun η hne => by
      by_cases h : η = η₀
      · subst h
        exact ⟨0, by assumption⟩   -- IMPOSSIBLE goal: typedTouchesSupport η₀ (r₁ 0), contradicted by hno 0
      · exfalso; apply hne; unfold touchFactor; split_ifs <;> simp [h])
  ⟨_, h.choose_spec.1⟩
end
end LatticeGauge
