import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalCover
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q5 (QA1): NON-UNIQUE MINIMIZER with equal weights n = (0,0). Same witness profiles as Q4 (contacts by hypothesis).
section
variable (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (η₀ : Polymer N)
noncomputable def pa (_ : Polymer N) : ℝ := 1/4
noncomputable def pa' (η₀ : Polymer N) (η : Polymer N) : ℝ := if η = η₀ then 3/4 else 1/4
theorem Q5_mem : (∀ η, 0 ≤ pa (N := N) η) ∧ (∀ η, pa (N := N) η ≤ 1) ∧ (∀ η, 0 ≤ pa' η₀ η) ∧ (∀ η, pa' η₀ η ≤ 1) := by
  refine ⟨fun _ => by unfold pa; norm_num, fun _ => by unfold pa; norm_num, fun η => ?_, fun η => ?_⟩ <;>
    (unfold pa'; split_ifs <;> norm_num)
theorem Q5_diff (hR : typedTouchesSupport (N := N) η₀ R) (η : Polymer N) :
    |touchFactor R pa η - touchFactor R (pa' η₀) η| = if η = η₀ then 1/2 else 0 := by
  unfold touchFactor pa pa'
  by_cases h : η = η₀
  · subst h; simp [hR]; norm_num [abs_le]
  · simp [h]
-- (a) both (1/2,0) and (0,1/2) are admissible (for all polymers)
theorem Q5_adm (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    Admissible R r pa (pa' η₀) ![(1/2 : ℝ), 0] ∧ Admissible R r pa (pa' η₀) ![(0 : ℝ), 1/2] := by
  constructor <;> refine ⟨fun i => by fin_cases i <;> norm_num, fun η => ?_⟩ <;> rw [Q5_diff R η₀ hR] <;> by_cases h : η = η₀
  · subst h; simp only [if_true]; rw [Fin.sum_univ_two, if_pos h0, if_pos h1]; norm_num
  · simp only [h, if_false]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
  · subst h; simp only [if_true]; rw [Fin.sum_univ_two, if_pos h0, if_pos h1]; norm_num
  · simp only [h, if_false]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> first | (fin_cases i <;> norm_num) | exact le_rfl)
-- (b) they are distinct vectors
theorem Q5_distinct : (![(1/2 : ℝ), 0] : Fin 2 → ℝ) ≠ ![(0 : ℝ), 1/2] := by
  intro h; have := congrFun h 0; norm_num at this
-- (c) every admissible budget costs ≥ 1/2 (weights 1): both are GLOBAL minimizers with cost 1/2
theorem Q5_lower (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) {δ : Fin 2 → ℝ} (hδ : Admissible R r pa (pa' η₀) δ) :
    (1/2 : ℝ) ≤ budget ![0, 0] δ := by
  have h := hδ.2 η₀
  rw [Q5_diff R η₀ hR, if_pos rfl, Fin.sum_univ_two, if_pos h0, if_pos h1] at h
  unfold budget; rw [Fin.sum_univ_two]; simp; linarith
theorem Q5_both_min (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    (∀ δ, Admissible R r pa (pa' η₀) δ → budget ![0, 0] ![(1/2 : ℝ), 0] ≤ budget ![0, 0] δ)
    ∧ (∀ δ, Admissible R r pa (pa' η₀) δ → budget ![0, 0] ![(0 : ℝ), 1/2] ≤ budget ![0, 0] δ)
    ∧ budget ![0, 0] ![(1/2 : ℝ), 0] = 1/2 ∧ budget ![0, 0] ![(0 : ℝ), 1/2] = 1/2 := by
  have e1 : budget ![0, 0] ![(1/2 : ℝ), 0] = 1/2 := by unfold budget; rw [Fin.sum_univ_two]; simp
  have e2 : budget ![0, 0] ![(0 : ℝ), 1/2] = 1/2 := by unfold budget; rw [Fin.sum_univ_two]; simp
  exact ⟨fun δ hδ => by rw [e1]; exact Q5_lower R r η₀ hR h0 h1 hδ, fun δ hδ => by rw [e2]; exact Q5_lower R r η₀ hR h0 h1 hδ, e1, e2⟩
-- (d) linked to minCost through the real interface: B* = 1/2 (via either minimizer)
theorem Q5_minCost (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    minCost R r ![0, 0] (Q5_mem (N := N) η₀).1 (Q5_mem η₀).2.1 (Q5_mem η₀).2.2.1 (Q5_mem η₀).2.2.2
        (reaches_of_admissible R r (Q5_adm R r η₀ hR h0 h1).1) = 1/2 := by
  rw [minCost_eq_budget_of_isMin R r ![0, 0] _ _ _ _ _ (Q5_adm R r η₀ hR h0 h1).1 (Q5_both_min R r η₀ hR h0 h1).1]
  exact (Q5_both_min R r η₀ hR h0 h1).2.2.1
theorem Q5_minCost' (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (h1 : typedTouchesSupport (N := N) η₀ (r 1)) :
    minCost R r ![0, 0] (Q5_mem (N := N) η₀).1 (Q5_mem η₀).2.1 (Q5_mem η₀).2.2.1 (Q5_mem η₀).2.2.2
        (reaches_of_admissible R r (Q5_adm R r η₀ hR h0 h1).1) = 1/2 := by
  rw [minCost_eq_budget_of_isMin R r ![0, 0] _ _ _ _ _ (Q5_adm R r η₀ hR h0 h1).2 (Q5_both_min R r η₀ hR h0 h1).2.1]
  exact (Q5_both_min R r η₀ hR h0 h1).2.2.2
end
end LatticeGauge
