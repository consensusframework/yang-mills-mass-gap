import re,json,sys
raw=open(sys.argv[1],encoding='utf-8').read()
try:
    d=json.loads(raw); txt=d.get('logs_content') or d.get('content') or json.dumps(d)
except Exception: txt=raw
txt=txt.replace('\\n','\n') if txt.count('\n')<50 else txt
open(sys.argv[2],'w').write(txt); L=txt.split('\n'); print('lines',len(L),'chars',len(txt))
def show(pat,n=3):
    h=[l for l in L if re.search(pat,l)]; print(f'-- {pat}: {len(h)}'); [print('   ',l[:170]) for l in h[:n]]
show(r'HEAD is now at|refs/pull/\d+/merge|checkout --progress --force',3)
show(r'lake-manifest.json$|lake-manifest.json: OK',3); print('   revisions listed:',sum(1 for l in L if re.search(r' @ [0-9a-f]{40}$',l)))
show(r'checking out revision',1)
show(r'Build completed successfully')
print('   Built LatticeGauge',sum('Built LatticeGauge' in l for l in L),'Replayed LatticeGauge',sum('Replayed LatticeGauge' in l for l in L),'Built other',sum('Built ' in l and 'LatticeGauge' not in l for l in L),'Replayed other',sum('Replayed ' in l and 'LatticeGauge' not in l for l in L))
print('   Built other targets:',[re.sub(r'^.*Built ','',l).strip() for l in L if 'Built ' in l and 'LatticeGauge' not in l])
print('   errors (non-script):',sum(1 for l in L if 'error:' in l and '::error::' not in l))
w=[l for l in L if 'warning:' in l]; print('   warnings total',len(w),'LatticeGauge',sum('LatticeGauge/' in l for l in w),'new module',sum('ActivityProfileDampingOptimalCover' in l for l in w),'deps',sum('LatticeGauge/' not in l for l in w))
j=re.sub(r'\n\S*\s*',' ',txt)
from collections import Counter
C=Counter(re.findall(r"'(LatticeGauge\.[^' ]*'?)' depends on axioms: \[([^\]]*)\]",j))
print('   axiom lists',sum(C.values()),'unique names',len(set(n for n,_ in C)),'sets',Counter(re.sub(r'\s+','',a) for (_,a),k in C.items() for _ in range(k)))
print('   multiline lists',sum(1 for l in L if 'depends on axioms' in l and not re.search(r"depends on axioms: \[[^\]]*\]",l)))
M=set(l.split('\t')[0] for l in open('/tmp/claude-0/-home-user-yang-mills-mass-gap/46f99fd7-238f-5d5f-b183-a7759bfc1b9f/scratchpad/stone59/evidence/certs_module.tsv') if l.strip()); print('   new-module certs:',sum(k for (n,_),k in C.items() if n in M),'of',len(M),'names; missing:',sorted(M-set(n for n,_ in C)))
print("   apostrophe names:",[n for n,_ in C if "'" in n])
show(r'no sorryAx\.$',1); print('   sorryAx outside script:',sum(1 for l in L if 'sorryAx' in l and 'grep' not in l and 'echo' not in l and 'no sorryAx' not in l))
json.dump({k[0]+'|'+re.sub(r'\s+','',k[1]):v for k,v in C.items()},open(sys.argv[2]+'.certs.json','w'))
