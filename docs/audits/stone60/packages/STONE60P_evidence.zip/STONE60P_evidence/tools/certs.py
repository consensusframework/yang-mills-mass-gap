#!/usr/bin/env python3
"""Parse '#print axioms' outputs (multi-line lists joined) from a lean log. Prints name -> axiom list."""
import re,sys,collections
txt=open(sys.argv[1],encoding='utf-8',errors='replace').read()
j=re.sub(r'\n\s+',' ',txt)
C=collections.OrderedDict()
for n,a in re.findall(r"'([^']*'?)' depends on axioms: \[([^\]]*)\]",j):
    C[n]=re.sub(r'\s+','',a)
for n in re.findall(r"'([^']*'?)' does not depend on any axioms",j): C[n]='(none)'
for n,a in C.items(): print(f"{n}\t{a}")
ml=sum(1 for l in txt.split('\n') if 'depends on axioms' in l and not re.search(r"depends on axioms: \[[^\]]*\]",l))
print(f"# lists {len(C)} ; distinct sets {sorted(set(C.values()))} ; multiline {ml} ; sorryAx present: {'sorryAx' in txt}", file=sys.stderr)
