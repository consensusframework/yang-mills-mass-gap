import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q4 (QA1, tape §3.4): a NON-TRIVIAL exact distance, by lower bound at the witness polymer AND global cover; equality
-- and strict inequality in the triangle. The incidences `η₀ touches R` and `η₀ touches r 0` are HYPOTHESES: no lattice
-- geometry is constructed and no polymer is asserted to exist. m = 0 and R = ∅ are treated separately at the end.
section
variable (R : Set (Link N)) (r : Fin 1 → Set (Link N)) (n : Fin 1 → ℕ) (η₀ : Polymer N)
/-- the one-parameter family of profiles: value `c` at the witness, `1/4` elsewhere -/
noncomputable def qp (η₀ : Polymer N) (c : ℝ) (η : Polymer N) : ℝ := if η = η₀ then c else 1/4
theorem qp_mem {c : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) : (∀ η, 0 ≤ qp η₀ c η) ∧ (∀ η, qp η₀ c η ≤ 1) := by
  constructor <;> intro η <;> unfold qp <;> split_ifs <;> first | assumption | norm_num
theorem qp_diff (hR : typedTouchesSupport (N := N) η₀ R) (c c' : ℝ) (η : Polymer N) :
    |touchFactor R (qp η₀ c) η - touchFactor R (qp η₀ c') η| = if η = η₀ then |c - c'| else 0 := by
  unfold touchFactor qp
  by_cases h : η = η₀
  · subst h; simp [hR]
  · simp [h]
theorem qp_reach (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (c c' : ℝ) :
    Reaches R r (qp η₀ c) (qp η₀ c') := by
  intro η hne
  by_cases h : η = η₀
  · subst h; exact ⟨0, h0⟩
  · exfalso; apply hne; unfold touchFactor qp; simp [h]
-- GLOBAL cover: the budget |c − c′| on the single region is admissible for EVERY polymer
theorem qp_adm (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (c c' : ℝ) :
    Admissible R r (qp η₀ c) (qp η₀ c') (fun _ => |c - c'|) := by
  refine ⟨fun _ => abs_nonneg _, fun η => ?_⟩
  rw [qp_diff R η₀ hR]
  by_cases h : η = η₀
  · subst h; simp [Fin.sum_univ_one, h0]
  · simp only [h, if_false]; exact Finset.sum_nonneg (fun i _ => by split_ifs <;> first | exact abs_nonneg _ | exact le_rfl)
-- LOWER bound at the witness: every admissible budget pays at least |c − c′| on region 0
theorem qp_lower (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) (c c' : ℝ)
    {δ : Fin 1 → ℝ} (hδ : Admissible R r (qp η₀ c) (qp η₀ c') δ) : |c - c'| ≤ δ 0 := by
  have h := hδ.2 η₀
  rw [qp_diff R η₀ hR, if_pos rfl, Fin.sum_univ_one, if_pos h0] at h
  exact h
-- EXACT value: minCost = |c − c′| · exp(−n 0 / 2)
theorem qp_minCost (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    {c c' : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) (hc0' : 0 ≤ c') (hc1' : c' ≤ 1) :
    minCost R r n (qp_mem η₀ hc0 hc1).1 (qp_mem η₀ hc0 hc1).2 (qp_mem η₀ hc0' hc1').1 (qp_mem η₀ hc0' hc1').2
        (qp_reach R r η₀ hR h0 c c') = |c - c'| * Real.exp (-((n 0 : ℕ) : ℝ) / 2) := by
  have hb : ∀ δ : Fin 1 → ℝ, budget n δ = δ 0 * Real.exp (-((n 0 : ℕ) : ℝ) / 2) := fun δ => by
    unfold budget; rw [Fin.sum_univ_one]
  rw [minCost_eq_budget_of_isMin R r n _ _ _ _ _ (qp_adm R r η₀ hR h0 c c') (fun δ hδ => ?_), hb]
  rw [hb, hb]
  exact mul_le_mul_of_nonneg_right (qp_lower R r η₀ hR h0 c c' hδ) (Real.exp_pos _).le
-- members of the component of the reference qp 1/4
noncomputable def qm (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) : ProfileComponent R r n (qp η₀ (1/4)) :=
  ⟨qp η₀ c, (qp_mem η₀ hc0 hc1).1, (qp_mem η₀ hc0 hc1).2, qp_reach R r η₀ hR h0 _ _⟩
theorem qm_dist (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0))
    {c c' : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) (hc0' : 0 ≤ c') (hc1' : c' ≤ 1) :
    dist (qm R r n η₀ hR h0 c hc0 hc1) (qm R r n η₀ hR h0 c' hc0' hc1') = |c - c'| * Real.exp (-((n 0 : ℕ) : ℝ) / 2) :=
  qp_minCost R r n η₀ hR h0 hc0 hc1 hc0' hc1'
-- TRIANGLE WITH EQUALITY: 1/4 → 1/2 → 3/4 (collinear): d(1/4,3/4) = d(1/4,1/2) + d(1/2,3/4) = w/2
theorem Q4_triangle_eq (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) :
    dist (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (3/4) (by norm_num) (by norm_num))
      = dist (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (1/2) (by norm_num) (by norm_num))
        + dist (qm R r n η₀ hR h0 (1/2) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (3/4) (by norm_num) (by norm_num)) := by
  rw [qm_dist, qm_dist, qm_dist]
  rw [show |(1/4:ℝ) - 3/4| = 1/2 by rw [show (1/4:ℝ) - 3/4 = -(1/2) by norm_num, abs_neg, abs_of_pos (by norm_num)],
      show |(1/4:ℝ) - 1/2| = 1/4 by rw [show (1/4:ℝ) - 1/2 = -(1/4) by norm_num, abs_neg, abs_of_pos (by norm_num)],
      show |(1/2:ℝ) - 3/4| = 1/4 by rw [show (1/2:ℝ) - 3/4 = -(1/4) by norm_num, abs_neg, abs_of_pos (by norm_num)]]
  ring
-- TRIANGLE STRICT (return path): d(1/4,1/4) = 0 < d(1/4,1/2) + d(1/2,1/4) = w/2
theorem Q4_triangle_strict (hR : typedTouchesSupport (N := N) η₀ R) (h0 : typedTouchesSupport (N := N) η₀ (r 0)) :
    dist (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num))
      < dist (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (1/2) (by norm_num) (by norm_num))
        + dist (qm R r n η₀ hR h0 (1/2) (by norm_num) (by norm_num)) (qm R r n η₀ hR h0 (1/4) (by norm_num) (by norm_num)) := by
  rw [qm_dist, qm_dist, qm_dist]
  rw [show |(1/4:ℝ) - 1/4| = 0 by norm_num,
      show |(1/4:ℝ) - 1/2| = 1/4 by rw [show (1/4:ℝ) - 1/2 = -(1/4) by norm_num, abs_neg, abs_of_pos (by norm_num)],
      show |(1/2:ℝ) - 1/4| = 1/4 by rw [show (1/2:ℝ) - 1/4 = 1/4 by norm_num, abs_of_pos (by norm_num)]]
  have := Real.exp_pos (-((n 0 : ℕ) : ℝ) / 2)
  linarith
end
-- m = 0 (separately): reach forces equal factors, hence distance 0 between any two members — reason: no region
theorem Q4_fin_zero (R : Set (Link N)) (n : Fin 0 → ℕ) (aref : Polymer N → ℝ)
    (x y : ProfileComponent R (fun i : Fin 0 => i.elim0) n aref) : dist x y = 0 :=
  (optimalDist_eq_zero_iff x y).mpr (touchFactor_eq_of_reaches_fin_zero R (x.reaches y))
-- R = ∅ (separately): all effective factors are 1, hence distance 0 — a DIFFERENT reason (no damping region)
theorem Q4_empty_R {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) (aref : Polymer N → ℝ)
    (x y : ProfileComponent (∅ : Set (Link N)) r n aref) : dist x y = 0 :=
  (optimalDist_eq_zero_iff x y).mpr (fun η => by
    have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
    unfold touchFactor; simp [h])
#print axioms qp_minCost
#print axioms Q4_triangle_eq
#print axioms Q4_triangle_strict
#print axioms Q4_fin_zero
#print axioms Q4_empty_R
end LatticeGauge
