import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open MeasureTheory
open scoped Classical NNReal
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
variable {R : Set (Link N)} {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {aref : Polymer N → ℝ}
-- Q5 (QA1, tape §3.5): three- and four-point estimates and finite chains; the pseudometric actually used by Mathlib.
-- (a) the instance found by inference IS the candidate's, and its dist is optimalDist (hence minCost)
example : (inferInstance : PseudoMetricSpace (ProfileComponent R r n aref)) = instPseudoMetricSpace := rfl
example (x y : ProfileComponent R r n aref) : dist x y = optimalDist x y := rfl
-- (b) three points and four points, directly from Mathlib on the inferred instance (not via the candidate's wrappers)
example (x y z : ProfileComponent R r n aref) : |dist x z - dist y z| ≤ dist x y := abs_dist_sub_le x y z
example (x y x' y' : ProfileComponent R r n aref) : |dist x y - dist x' y'| ≤ dist x x' + dist y y' := by
  have h := dist_dist_dist_le x y x' y'; rwa [Real.dist_eq] at h
-- and own derivation of the three-point bound from the triangle inequality and symmetry only
theorem Q5_three (x y z : ProfileComponent R r n aref) : |optimalDist x z - optimalDist y z| ≤ optimalDist x y := by
  rw [abs_le]; constructor
  · have := optimalDist_triangle y x z; have := optimalDist_comm x y; linarith
  · have := optimalDist_triangle x y z; linarith
-- (c) chains: k = 0 (zero steps), k = 1 (one step), k = 2 (two steps), applying the candidate's polygonal inequality
example (x : Fin 1 → ProfileComponent R r n aref) : optimalDist (x 0) (x (Fin.last 0)) ≤ ∑ j : Fin 0, optimalDist (x j.castSucc) (x j.succ) :=
  optimalDist_chain_le x
example (x : Fin 1 → ProfileComponent R r n aref) : optimalDist (x 0) (x (Fin.last 0)) = 0 := optimalDist_self _
example (x : Fin 2 → ProfileComponent R r n aref) : optimalDist (x 0) (x 1) ≤ optimalDist (x 0) (x 1) := by
  have h := optimalDist_chain_le x
  simpa [Fin.sum_univ_one] using h
example (x : Fin 3 → ProfileComponent R r n aref) : optimalDist (x 0) (x 2) ≤ optimalDist (x 0) (x 1) + optimalDist (x 1) (x 2) := by
  have h := optimalDist_chain_le x
  simpa [Fin.sum_univ_two] using h
-- own proof of the two-step chain (triangle) and of the general polygonal inequality by induction (own statement over ℕ-indexed chains)
example (x₀ x₁ x₂ : ProfileComponent R r n aref) : dist x₀ x₂ ≤ dist x₀ x₁ + dist x₁ x₂ := dist_triangle x₀ x₁ x₂
theorem Q5_chain (x : ℕ → ProfileComponent R r n aref) : ∀ k, dist (x 0) (x k) ≤ ∑ j ∈ Finset.range k, dist (x j) (x (j + 1)) := by
  intro k; induction k with
  | zero => simp
  | succ k ih => rw [Finset.sum_range_succ]; exact le_trans (dist_triangle _ (x k) _) (by linarith)
-- (d) chain control of the functional with zero, one and two steps (candidate's theorems applied; Stone 59 regime assumed)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) (x : Fin 3 → ProfileComponent R r n aref) :
    |functional μm β χ f s (x 0) - functional μm β χ f s (x 2)|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * (dist (x 0) (x 1) + dist (x 1) (x 2)) := by
  have h := abs_functional_chain_le μm hβ mχ hχabs hsmall mf hCf hsep x
  simpa [Fin.sum_univ_two] using h
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) (x : Fin 1 → ProfileComponent R r n aref) :
    |functional μm β χ f s (x 0) - functional μm β χ f s (x (Fin.last 0))| ≤ 0 := by
  have h := abs_functional_chain_le_two_terms μm hβ mχ hχabs hsmall mf hCf hsep x
  simpa using h
-- (e) scope: only the pseudometric topology/uniformity induced by this dist is involved; nothing here states a product
--     topology or completeness (no CompleteSpace instance is used or needed by any statement above).
#print axioms Q5_three
#print axioms Q5_chain
end LatticeGauge
