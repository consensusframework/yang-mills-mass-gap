import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q7x (QA1, EXPECTED TO FAIL — exactly one error): constructing a member of the real `ProfileComponent R r n a` with profile b
-- when the effective factor changes at η₀, which touches R and no region. The fields `prof`, `nonneg`, `le_one` are
-- provided correctly; the field `reach` is the single impossible obligation. This is an application failure by a missing
-- (indeed false) hypothesis; it is not a statement about the inequality for F_R.
noncomputable def q7xa (_ : Polymer N) : ℝ := 1/4
noncomputable def q7xb (η₀ : Polymer N) (η : Polymer N) : ℝ := if η = η₀ then 3/4 else 1/4
noncomputable example (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) (η₀ : Polymer N)
    (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ProfileComponent R r n (q7xa (N := N)) where
  prof := q7xb η₀
  nonneg := fun η => by unfold q7xb; split_ifs <;> norm_num
  le_one := fun η => by unfold q7xb; split_ifs <;> norm_num
  reach := fun η hne => by
    by_cases h : η = η₀
    · subst h      -- the goal `∃ i, typedTouchesSupport η (r i)` is left open here: IMPOSSIBLE, since hno negates every index
    · exfalso; apply hne; unfold touchFactor q7xa q7xb; simp [h]
end LatticeGauge
