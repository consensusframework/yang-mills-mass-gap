import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q3 (QA1, tape §3.3): what indexes the component; dist IS minCost; changing the reference keeps the value; equal
-- effective factors with distinct raw profiles give d = 0 (and equal functional), not equal profiles.
-- (a) in the TYPE: R, r, n and the reference index the component; dist is definitionally the Stone 59 minCost
example {R : Set (Link N)} {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {aref : Polymer N → ℝ}
    (x y : ProfileComponent R r n aref) :
    dist x y = minCost R r n x.nonneg x.le_one y.nonneg y.le_one (x.reaches y) := rfl
-- (b) changing the reference preserves the value for the same profiles (own proof: both sides are minCost of the same
--     raw data, proof terms irrelevant) — and the candidate's lemma retyped
theorem Q3_ref {R : Set (Link N)} {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {aref aref' : Polymer N → ℝ}
    (x y : ProfileComponent R r n aref) (x' y' : ProfileComponent R r n aref')
    (hx : x.prof = x'.prof) (hy : y.prof = y'.prof) : dist x y = dist x' y' := by
  obtain ⟨xp, x0, x1, xr⟩ := x; obtain ⟨yp, y0, y1, yr⟩ := y
  obtain ⟨xp', x0', x1', xr'⟩ := x'; obtain ⟨yp', y0', y1', yr'⟩ := y'
  simp only at hx hy; subst hx; subst hy; rfl
example {R : Set (Link N)} {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {aref aref' : Polymer N → ℝ}
    (x y : ProfileComponent R r n aref) (x' y' : ProfileComponent R r n aref')
    (hx : x.prof = x'.prof) (hy : y.prof = y'.prof) : optimalDist x y = optimalDist x' y' := optimalDist_ref_indep x y x' y' hx hy
-- (c) EQUAL EFFECTIVE FACTORS, DISTINCT RAW PROFILES: x ≡ 1/2 and y = 1/2 on R-touching polymers, 1 elsewhere.
--     Both are members of the component of x; d(x,y) = 0; the functional agrees (algebraic route, no small β); and the raw
--     profiles differ at every polymer avoiding R (the existence of such a polymer is NOT asserted: it is a hypothesis).
section
variable (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ)
noncomputable def Q3x : ProfileComponent R r n (fun _ : Polymer N => (1/2 : ℝ)) :=
  ⟨fun _ => 1/2, fun _ => by norm_num, fun _ => by norm_num, reaches_refl R r _⟩
noncomputable def Q3y : ProfileComponent R r n (fun _ : Polymer N => (1/2 : ℝ)) :=
  ⟨fun η => if typedTouchesSupport (N := N) η R then 1/2 else 1,
    fun η => by beta_reduce; split_ifs <;> norm_num, fun η => by beta_reduce; split_ifs <;> norm_num,
    (reaches_iff_untouched_eq R r _ _).mpr (fun η _ => by unfold touchFactor; split_ifs with h <;> simp [h])⟩
theorem Q3_dist_zero : dist (Q3x R r n) (Q3y R r n) = 0 :=
  (optimalDist_eq_zero_iff (Q3x R r n) (Q3y R r n)).mpr
    (fun η => by show touchFactor R (fun _ => (1/2:ℝ)) η = touchFactor R (fun η => if typedTouchesSupport (N := N) η R then (1/2:ℝ) else 1) η
                 unfold touchFactor; split_ifs with h <;> simp [h])
theorem Q3_raw_ne (η : Polymer N) (hR : ¬ typedTouchesSupport (N := N) η R) : (Q3x R r n).prof η ≠ (Q3y R r n).prof η := by
  show (1/2 : ℝ) ≠ (if typedTouchesSupport (N := N) η R then (1/2 : ℝ) else 1)
  rw [if_neg hR]; norm_num
-- equality of the FUNCTIONAL (a result about F_R), distinct from equality of the profiles (false off R)
theorem Q3_functional_eq (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) :
    functional μm β χ f s (Q3x R r n) = functional μm β χ f s (Q3y R r n) :=
  functional_eq_of_dist_eq_zero μm β χ f s _ _ (Q3_dist_zero R r n)
-- own re-derivation of that algebraic route (no regime, no measure hypotheses used): zero distance ⇒ equal factors ⇒ 56 identity
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) {aref : Polymer N → ℝ}
    (x y : ProfileComponent R r n aref) (h : dist x y = 0) :
    profileExpectation μm β χ f s R x.prof = profileExpectation μm β χ f s R y.prof :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s R
    ((minCost_eq_zero_iff R r n x.nonneg x.le_one y.nonneg y.le_one (x.reaches y)).mp h)
end
#print axioms Q3_ref
#print axioms Q3_dist_zero
#print axioms Q3_functional_eq
end LatticeGauge
