import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q7 (QA1, tape §3.7), POSITIVE half, against the REAL imported structure `ProfileComponent`: an effective change at a
-- polymer WITHOUT contact with any region makes reach impossible. Incidences (η₀ touches R; η₀ touches no r i) are
-- hypotheses. The single expected failure is isolated in q7x_no_reach_EXPECT_FAIL.lean.
section
variable (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) (η₀ : Polymer N)
noncomputable def q7a (_ : Polymer N) : ℝ := 1/4
noncomputable def q7b (η₀ : Polymer N) (η : Polymer N) : ℝ := if η = η₀ then 3/4 else 1/4
theorem Q7_factor_ne (hR : typedTouchesSupport (N := N) η₀ R) : touchFactor R q7a η₀ ≠ touchFactor R (q7b η₀) η₀ := by
  unfold touchFactor q7a q7b; rw [if_pos hR, if_pos hR]; simp only [eq_self_iff_true, if_true]; norm_num
-- (i) reach is FALSE
theorem Q7_reach_false (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ¬ Reaches R r q7a (q7b η₀) := by
  intro h
  obtain ⟨i, hi⟩ := h η₀ (Q7_factor_ne R η₀ hR)
  exact hno i hi
-- (ii) no admissible budget exists (own; the cover sum at η₀ is 0 while the change is 1/2)
theorem Q7_no_admissible (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ¬ ∃ δ : Fin m → ℝ, Admissible R r q7a (q7b η₀) δ := by
  rintro ⟨δ, _, hcov⟩
  have h := hcov η₀
  rw [Finset.sum_eq_zero (fun i _ => if_neg (hno i))] at h
  exact Q7_factor_ne R η₀ hR (sub_eq_zero.mp (abs_nonpos_iff.mp h))
-- (iii) NO MEMBER of the component of q7a has profile q7b η₀ (stated on the real imported structure)
theorem Q7_no_member (hR : typedTouchesSupport (N := N) η₀ R) (hno : ∀ i, ¬ typedTouchesSupport (N := N) η₀ (r i)) :
    ¬ ∃ x : ProfileComponent R r n q7a, x.prof = q7b η₀ := by
  rintro ⟨x, hx⟩
  exact Q7_reach_false R r η₀ hR hno (hx ▸ x.reach)
-- (iv) yet q7b η₀ is a perfectly admissible profile in [0,1]: the obstruction is reach only
example : (∀ η, 0 ≤ q7b η₀ η) ∧ (∀ η, q7b η₀ η ≤ 1) := by
  constructor <;> intro η <;> unfold q7b <;> split_ifs <;> norm_num
end
#print axioms Q7_reach_false
#print axioms Q7_no_admissible
#print axioms Q7_no_member
end LatticeGauge
