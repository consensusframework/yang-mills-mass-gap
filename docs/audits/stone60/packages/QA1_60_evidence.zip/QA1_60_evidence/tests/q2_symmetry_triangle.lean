import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q2 (QA1, tape §3.2): SYMMETRY of the value and the TRIANGLE inequality re-derived from Stone 59 interfaces only
-- (optimalBudget_admissible, minCost_le_budget) — the new `minCost_comm`, `minCost_triangle`, `admissible_add`,
-- `admissible_symm`, `budget_add` are NOT used; minimizers are never identified.
-- own transport of admissibility (|x − y| = |y − x|)
theorem Q2_adm_symm {m : ℕ} {R : Set (Link N)} {r : Fin m → Set (Link N)} {a b : Polymer N → ℝ} {δ : Fin m → ℝ}
    (h : Admissible R r a b δ) : Admissible R r b a δ :=
  ⟨h.1, fun η => by rw [abs_sub_comm]; exact h.2 η⟩
-- own addition of admissible budgets along a path (no profile bound; coordinates may exceed 1)
theorem Q2_adm_add {m : ℕ} {R : Set (Link N)} {r : Fin m → Set (Link N)} {a b c : Polymer N → ℝ} {δ₁ δ₂ : Fin m → ℝ}
    (h₁ : Admissible R r a b δ₁) (h₂ : Admissible R r b c δ₂) : Admissible R r a c (fun i => δ₁ i + δ₂ i) := by
  refine ⟨fun i => add_nonneg (h₁.1 i) (h₂.1 i), fun η => ?_⟩
  have hsum : (∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ₁ i + δ₂ i else 0)
      = (∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ₁ i else 0)
        + ∑ i : Fin m, if typedTouchesSupport (N := N) η (r i) then δ₂ i else 0 := by
    rw [← Finset.sum_add_distrib]; exact Finset.sum_congr rfl (fun i _ => by split_ifs <;> simp)
  rw [hsum]
  have := abs_sub_le (touchFactor R a η) (touchFactor R b η) (touchFactor R c η)
  linarith [h₁.2 η, h₂.2 η]
-- own additivity of the cost
theorem Q2_budget_add {m : ℕ} (n : Fin m → ℕ) (δ₁ δ₂ : Fin m → ℝ) :
    budget n (fun i => δ₁ i + δ₂ i) = budget n δ₁ + budget n δ₂ := by
  unfold budget; rw [← Finset.sum_add_distrib]; exact Finset.sum_congr rfl (fun i _ => by ring)
-- (a) SYMMETRY of the value (own): two comparisons through transported minimizers
theorem Q2_symm {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a b : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ b η) (h1' : ∀ η, b η ≤ 1)
    (hab : Reaches R r a b) (hba : Reaches R r b a) :
    minCost R r n h0 h1 h0' h1' hab = minCost R r n h0' h1' h0 h1 hba :=
  le_antisymm
    (minCost_le_budget R r n h0 h1 h0' h1' hab (Q2_adm_symm (optimalBudget_admissible R r n h0' h1' h0 h1 hba)))
    (minCost_le_budget R r n h0' h1' h0 h1 hba (Q2_adm_symm (optimalBudget_admissible R r n h0 h1 h0' h1' hab)))
-- (b) TRIANGLE (own): the sum of the two chosen minimizers is admissible for the endpoints; compare by minCost_le_budget
theorem Q2_triangle {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a b c : Polymer N → ℝ}
    (ha0 : ∀ η, 0 ≤ a η) (ha1 : ∀ η, a η ≤ 1) (hb0 : ∀ η, 0 ≤ b η) (hb1 : ∀ η, b η ≤ 1)
    (hc0 : ∀ η, 0 ≤ c η) (hc1 : ∀ η, c η ≤ 1)
    (hab : Reaches R r a b) (hbc : Reaches R r b c) (hac : Reaches R r a c) :
    minCost R r n ha0 ha1 hc0 hc1 hac ≤ minCost R r n ha0 ha1 hb0 hb1 hab + minCost R r n hb0 hb1 hc0 hc1 hbc := by
  have hadm := Q2_adm_add (optimalBudget_admissible R r n ha0 ha1 hb0 hb1 hab) (optimalBudget_admissible R r n hb0 hb1 hc0 hc1 hbc)
  have h := minCost_le_budget R r n ha0 ha1 hc0 hc1 hac hadm
  rw [Q2_budget_add] at h
  exact h
-- (c) RETURN PATH: a → b → a with the unit budget on each leg. The summed budget has every coordinate equal to 2, is
--     admissible for the endpoints (a, a), and yet the optimal cost of the endpoints is 0 (the sum is not optimal).
theorem Q2_return {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a b : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ b η) (h1' : ∀ η, b η ≤ 1) (hab : Reaches R r a b) :
    Admissible R r a a (fun _ : Fin m => (1:ℝ) + 1)
    ∧ (∀ i : Fin m, (fun _ : Fin m => (1:ℝ) + 1) i = 2)
    ∧ minCost R r n h0 h1 h0 h1 (fun _ hne => absurd rfl hne) = 0 := by
  refine ⟨Q2_adm_add (admissible_one_of_reaches R r h0 h1 h0' h1' hab)
      (Q2_adm_symm (admissible_one_of_reaches R r h0 h1 h0' h1' hab)), fun _ => by norm_num, ?_⟩
  exact (minCost_eq_zero_iff R r n h0 h1 h0 h1 _).mpr (fun _ => rfl)
-- (d) the candidate's theorems, retyped (interface)
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (n : Fin m → ℕ) {a b c : Polymer N → ℝ}
    (ha0 : ∀ η, 0 ≤ a η) (ha1 : ∀ η, a η ≤ 1) (hb0 : ∀ η, 0 ≤ b η) (hb1 : ∀ η, b η ≤ 1)
    (hc0 : ∀ η, 0 ≤ c η) (hc1 : ∀ η, c η ≤ 1)
    (hab : Reaches R r a b) (hbc : Reaches R r b c) (hac : Reaches R r a c) :
    minCost R r n ha0 ha1 hc0 hc1 hac ≤ minCost R r n ha0 ha1 hb0 hb1 hab + minCost R r n hb0 hb1 hc0 hc1 hbc :=
  minCost_triangle R r n ha0 ha1 hb0 hb1 hc0 hc1 hab hbc hac
#print axioms Q2_symm
#print axioms Q2_triangle
#print axioms Q2_return
end LatticeGauge
