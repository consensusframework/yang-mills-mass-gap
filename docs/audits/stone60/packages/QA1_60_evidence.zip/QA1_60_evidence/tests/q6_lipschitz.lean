import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open MeasureTheory
open scoped Classical NNReal
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
variable {R : Set (Link N)} {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {aref : Polymer N → ℝ}
-- Q6 (QA1, tape §3.6): the two Lipschitz bounds re-obtained from the Stone 59 interfaces and the identification
-- dist = minCost — WITHOUT the Stone 60 capstones (abs_functional_sub_functional_le*, lipschitzWith_functional*,
-- twoTermConst/compactConst are not used in (a)–(c)).
-- own non-negative constants
noncomputable def qK₂ {f : Config N G → ℝ} {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (s : Set (Link N)) : ℝ≥0 :=
  ⟨Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)),
    mul_nonneg (le_trans (abs_nonneg _) (hCf (fun _ => 1))) (add_pos (Real.exp_pos _) (Real.exp_pos _)).le⟩
noncomputable def qK {f : Config N G → ℝ} {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (s : Set (Link N)) : ℝ≥0 :=
  ⟨(2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113),
    mul_nonneg (by linarith [le_trans (abs_nonneg _) (hCf (fun _ => 1))]) (Real.exp_pos _).le⟩
-- (a) two-term Lipschitz, own: Stone 59 two-term capstone + dist = minCost (rfl)
theorem Q6_lip₂ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    LipschitzWith (qK₂ hCf s) (fun x : ProfileComponent R r n aref => profileExpectation μm β χ f s R x.prof) := by
  refine LipschitzWith.of_dist_le_mul (fun x y => ?_)
  rw [Real.dist_eq]
  exact abs_profileExpectation_sub_profileExpectation_le_optimal_cover_two_terms μm hβ mχ hχabs hsmall R mf hCf hsep
    x.nonneg x.le_one y.nonneg y.le_one (x.reaches y)
-- (b) compact Lipschitz, own
theorem Q6_lip {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    LipschitzWith (qK hCf s) (fun x : ProfileComponent R r n aref => profileExpectation μm β χ f s R x.prof) := by
  refine LipschitzWith.of_dist_le_mul (fun x y => ?_)
  rw [Real.dist_eq]
  exact abs_profileExpectation_sub_profileExpectation_le_optimal_cover μm hβ mχ hχabs hsmall R mf hCf hsep
    x.nonneg x.le_one y.nonneg y.le_one (x.reaches y)
-- (c) uniform continuity and continuity for THIS pseudometric, from my own Lipschitz statement
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    UniformContinuous (fun x : ProfileComponent R r n aref => profileExpectation μm β χ f s R x.prof)
    ∧ Continuous (fun x : ProfileComponent R r n aref => profileExpectation μm β χ f s R x.prof) :=
  ⟨(Q6_lip μm hβ mχ hχabs hsmall mf hCf hsep).uniformContinuous, (Q6_lip μm hβ mχ hχabs hsmall mf hCf hsep).continuous⟩
-- (d) COERCIONS of the candidate's two constants are exactly K₂ and K (definitional), and equal to my constants
example {f : Config N G → ℝ} {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (s : Set (Link N)) :
    ((twoTermConst hCf s : ℝ≥0) : ℝ) = Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
      + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) := rfl
example {f : Config N G → ℝ} {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (s : Set (Link N)) :
    ((compactConst hCf s : ℝ≥0) : ℝ) = (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) := rfl
example {f : Config N G → ℝ} {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (s : Set (Link N)) :
    twoTermConst hCf s = qK₂ hCf s ∧ compactConst hCf s = qK hCf s := ⟨rfl, rfl⟩
-- the functional of the candidate is my map (definitional)
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) :
    (functional μm β χ f s : ProfileComponent R r n aref → ℝ) = fun x => profileExpectation μm β χ f s R x.prof := rfl
-- (e) Cf = 0: both constants are 0 and the functional is constant on the component (effective application)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) (hCf : ∀ U, |f U| ≤ 0)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) (x y : ProfileComponent R r n aref) :
    ((twoTermConst hCf s : ℝ≥0) : ℝ) = 0 ∧ ((compactConst hCf s : ℝ≥0) : ℝ) = 0
    ∧ functional μm β χ f s x = functional μm β χ f s y := by
  refine ⟨by rw [coe_twoTermConst]; ring, by rw [coe_compactConst]; ring, ?_⟩
  have h := abs_functional_sub_functional_le μm hβ mχ hχabs hsmall mf hCf hsep x y
  simp only [mul_zero, zero_mul] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (f) the candidate's Lipschitz theorems, applied (interface) — same statements as (a),(b) with its constants
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    LipschitzWith (twoTermConst hCf s) (functional μm β χ f s : ProfileComponent R r n aref → ℝ)
    ∧ LipschitzWith (compactConst hCf s) (functional μm β χ f s : ProfileComponent R r n aref → ℝ) :=
  ⟨lipschitzWith_functional_two_terms μm hβ mχ hχabs hsmall mf hCf hsep, lipschitzWith_functional μm hβ mχ hχabs hsmall mf hCf hsep⟩
-- (g) RECOVERY signatures: the two recovered statements have the TYPES of the published Stone 59 capstones (both
--     directions, definitional). This compares types; it does not show the derivations are the same.
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hreach : Reaches R r a a'),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * minCost R r n h0 h1 h0' h1' hreach) :=
  @recover_optimal_cover N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hreach : Reaches R r a a'),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * minCost R r n h0 h1 h0' h1' hreach) :=
  @abs_profileExpectation_sub_profileExpectation_le_optimal_cover N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hreach : Reaches R r a a'),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) * minCost R r n h0 h1 h0' h1' hreach) :=
  @recover_optimal_cover_two_terms N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hreach : Reaches R r a a'),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ Cf * (Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
              + Real.exp (4 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)) * minCost R r n h0 h1 h0' h1' hreach) :=
  @abs_profileExpectation_sub_profileExpectation_le_optimal_cover_two_terms N _ _ G _ _ _ _ μm _ _
-- (h) the ALGEBRAIC route d = 0 ⇒ equal functional carries NO small-β and no measure-theoretic hypothesis (own re-derivation;
--     arbitrary β, χ, f)
theorem Q6_zero (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) (x y : ProfileComponent R r n aref)
    (h : dist x y = 0) : profileExpectation μm β χ f s R x.prof = profileExpectation μm β χ f s R y.prof :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s R
    ((minCost_eq_zero_iff R r n x.nonneg x.le_one y.nonneg y.le_one (x.reaches y)).mp h)
#print axioms Q6_lip₂
#print axioms Q6_lip
#print axioms Q6_zero
end LatticeGauge
