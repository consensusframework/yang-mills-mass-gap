import Mathlib
import LatticeGauge.ActivityProfileDampingOptimalGeometry
open scoped Classical
namespace LatticeGauge
open ActivityProfileOptimalCover ActivityProfileOptimalGeometry
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q1 (QA1, tape §3.1): REACH characterized by equality of the factors on the UNREACHED polymers; equivalence without any
-- global cover; components with an unbounded reference. Own proofs from the definition of `Reaches`.
-- (a) the characterization (own)
theorem Q1_char {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (a b : Polymer N → ℝ) :
    Reaches R r a b ↔ ∀ η : Polymer N, (∀ i, ¬ typedTouchesSupport (N := N) η (r i)) → touchFactor R a η = touchFactor R b η := by
  unfold Reaches
  constructor
  · intro h η hno
    by_contra hne
    obtain ⟨i, hi⟩ := h η hne
    exact hno i hi
  · intro h η hne
    by_contra hno
    exact hne (h η (not_exists.mp hno))
-- (b) equivalence relation, own, through (a): no cover of all polymers is used anywhere
theorem Q1_equiv {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) : Equivalence (Reaches (N := N) R r) := by
  refine ⟨fun a => (Q1_char R r a a).mpr (fun _ _ => rfl), fun {a b} h => ?_, fun {a b c} h₁ h₂ => ?_⟩
  · exact (Q1_char R r b a).mpr (fun η hno => ((Q1_char R r a b).mp h η hno).symm)
  · exact (Q1_char R r a c).mpr (fun η hno => ((Q1_char R r a b).mp h₁ η hno).trans ((Q1_char R r b c).mp h₂ η hno))
-- (b′) reach is NOT a global cover: a polymer touching no region may exist and both profiles may be untouched there
--      (statement of the content: reach between a and a holds whatever the family, even the empty one)
example (R : Set (Link N)) (a : Polymer N → ℝ) : Reaches R (fun i : Fin 0 => i.elim0) a a := (Q1_equiv R _).refl a
-- (c) UNBOUNDED REFERENCE, R = ∅: the reference constant 2 (outside [0,1], not a member) has the constants 0 and 1 as
--     valid members of its component (all effective factors are 1)
noncomputable def Q1_member (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) :
    ProfileComponent (∅ : Set (Link N)) r n (fun _ => (2 : ℝ)) :=
  ⟨fun _ => c, fun _ => hc0, fun _ => hc1, reaches_empty_region r _ _⟩
example {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) :
    (Q1_member (N := N) 0 le_rfl zero_le_one r n).prof = (fun _ => 0) ∧ (Q1_member (N := N) 1 zero_le_one le_rfl r n).prof = (fun _ => 1) :=
  ⟨rfl, rfl⟩
-- the reference itself is not a member-profile: no member has profile `fun _ => 2` (needs a polymer to evaluate at)
example {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) (η : Polymer N)
    (x : ProfileComponent (∅ : Set (Link N)) r n (fun _ => (2 : ℝ))) : x.prof ≠ fun _ => 2 := by
  intro h; have := x.le_one η; rw [h] at this; norm_num at this
-- (d) a member is NOT presupposed for every reference: with m = 0 and a polymer η₀ touching R where the reference equals
--     2, the component is EMPTY (any member would have effective factor 2 at η₀, but members are ≤ 1). Incidence assumed.
theorem Q1_empty (R : Set (Link N)) (n : Fin 0 → ℕ) (η₀ : Polymer N) (hR : typedTouchesSupport (N := N) η₀ R)
    (aref : Polymer N → ℝ) (href : aref η₀ = 2) :
    IsEmpty (ProfileComponent R (fun i : Fin 0 => i.elim0) n aref) := by
  refine ⟨fun x => ?_⟩
  have h := touchFactor_eq_of_reaches_fin_zero R x.reach η₀
  unfold touchFactor at h; rw [if_pos hR, if_pos hR, href] at h
  have := x.le_one η₀; linarith
-- (e) bounded members with an unbounded reference, R ≠ ∅: the reference may be arbitrary OFF the reached polymers' factors;
--     e.g. aref = 2 off R and 1/2 on R reaches the constant 1/2 (equal effective factors), so the constant 1/2 is a member
noncomputable example (R : Set (Link N)) {m : ℕ} (r : Fin m → Set (Link N)) (n : Fin m → ℕ) :
    ProfileComponent R r n (fun η => if typedTouchesSupport (N := N) η R then (1/2 : ℝ) else 2) :=
  ⟨fun _ => 1/2, fun _ => by norm_num, fun _ => by norm_num,
    (Q1_char R r _ _).mpr (fun η _ => by unfold touchFactor; split_ifs with h <;> simp [h])⟩
-- (f) the candidate's statements, retyped
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) (a b : Polymer N → ℝ) :
    Reaches R r a b ↔ ∀ η : Polymer N, (∀ i, ¬ typedTouchesSupport (N := N) η (r i)) → touchFactor R a η = touchFactor R b η :=
  reaches_iff_untouched_eq R r a b
example {m : ℕ} (R : Set (Link N)) (r : Fin m → Set (Link N)) : Equivalence (Reaches (N := N) R r) := reaches_equivalence R r
#print axioms Q1_char
#print axioms Q1_equiv
#print axioms Q1_empty
end LatticeGauge
