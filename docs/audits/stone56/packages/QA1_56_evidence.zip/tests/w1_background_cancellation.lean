import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- W1: BACKGROUND AND CANCELLATION (auditor's own tests, Stone 56).
-- (a) Cancellation OUTSIDE r is by EQUALITY of effective factors, not by weight 1: concrete non-unit background 1/2 on R,
--     the second profile changes only on r (to 1/3). A family avoiding r has EQUAL weights; a polymer touching R but not r
--     has effective factor 1/2 ≠ 1 under BOTH profiles.
example (R r : Set (Link N)) (Γ : Finset (Polymer N)) (h : touchCount r Γ = 0) :
    profileWeight R (fun _ => (1/2 : ℝ)) Γ
      = profileWeight R (fun η => if typedTouchesSupport (N := N) η r then (1/3 : ℝ) else 1/2) Γ :=
  profileWeight_eq_of_touchCount_zero_of_same R r
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη]) h
example (R r : Set (Link N)) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R)
    (hr : ¬ typedTouchesSupport (N := N) η r) :
    touchFactor R (fun _ => (1/2 : ℝ)) η = 1/2
    ∧ touchFactor R (fun η => if typedTouchesSupport (N := N) η r then (1/3 : ℝ) else 1/2) η = 1/2
    ∧ touchFactor R (fun _ => (1/2 : ℝ)) η ≠ 1 := by
  refine ⟨?_, ?_, ?_⟩
  · unfold touchFactor; rw [if_pos hR]
  · unfold touchFactor; simp [hR, hr]
  · unfold touchFactor; rw [if_pos hR]; norm_num
-- (a') the same cancellation, own proof from the definitions (not via the candidate lemma), for ARBITRARY real profiles
example (R r : Set (Link N)) {a a' : Polymer N → ℝ}
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (Γ : Finset (Polymer N)) (h : ∀ η ∈ Γ, ¬ typedTouchesSupport (N := N) η r) :
    profileWeight R a Γ = profileWeight R a' Γ := by
  unfold profileWeight
  exact Finset.prod_congr rfl (fun η hη => hsame η (h η hη))
-- (b) ORIENTATION A′ − A of the coefficient identity, RE-DERIVED by the auditor from the expansion (own proof, own tactic route):
--     [c_k(restr z_a) − c_k(z_a)] − [c_k(restr z_a′) − c_k(z_a′)] = Σ_{δ hits both} (A′_δ − A_δ)·u_δ·Π z / k!.
example (k : ℕ) (z : Polymer N → ℝ) (P : Polymer N → Prop) (r R : Set (Link N)) {a a' : Polymer N → ℝ}
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η) :
    (kpSignedUnrootedCoeff (N := N) k (restrictedActivity (profileDampedActivity z R a) P)
        - kpSignedUnrootedCoeff (N := N) k (profileDampedActivity z R a))
      - (kpSignedUnrootedCoeff (N := N) k (restrictedActivity (profileDampedActivity z R a') P)
        - kpSignedUnrootedCoeff (N := N) k (profileDampedActivity z R a'))
      = (∑ δ : Fin k → Polymer N,
          if TupleHitsBothForbidden P (regionAllowed (N := N) r) δ then
            (tupleProfileWeight R a' δ - tupleProfileWeight R a δ)
              * (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin k, z (δ i))
          else 0) / ((Nat.factorial k : ℕ) : ℝ) := by
  unfold kpSignedUnrootedCoeff
  have key : ∀ δ : Fin k → Polymer N,
      ((((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ)
          * ∏ i : Fin k, restrictedActivity (profileDampedActivity z R a) P (δ i))
        - (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ)
          * ∏ i : Fin k, profileDampedActivity z R a (δ i)))
      - ((((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ)
          * ∏ i : Fin k, restrictedActivity (profileDampedActivity z R a') P (δ i))
        - (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ)
          * ∏ i : Fin k, profileDampedActivity z R a' (δ i)))
      = if TupleHitsBothForbidden P (regionAllowed (N := N) r) δ then
            (tupleProfileWeight R a' δ - tupleProfileWeight R a δ)
              * (((ursellCoeff (N := N) (fun i => (δ i).val) : ℤ) : ℝ) * ∏ i : Fin k, z (δ i))
          else 0 := by
    intro δ
    rw [prod_restrictedActivity_eq, prod_restrictedActivity_eq, prod_profileDampedActivity_tuple,
      prod_profileDampedActivity_tuple]
    unfold TupleHitsBothForbidden
    by_cases hP : TupleAllowed P δ
    · simp only [hP, if_true, not_true, false_and, if_false]; ring
    · by_cases hQ : TupleAllowed (regionAllowed (N := N) r) δ
      · have hc := (tupleAllowed_regionAllowed_iff_tupleTouchCount_eq_zero r δ).mp hQ
        have hw := tupleProfileWeight_eq_of_tupleTouchCount_zero_of_same R r hsame hc
        simp only [hP, if_false, hQ, not_true, and_false]; rw [hw]; ring
      · simp only [hP, hQ, if_false, not_false_eq_true, and_self, if_true]; ring
  rw [div_sub_div_same, div_sub_div_same, div_sub_div_same, ← Finset.sum_sub_distrib,
    ← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib]
  congr 1
  exact Finset.sum_congr rfl (fun δ _ => key δ)
-- (b') the candidate's identity, retyped (interface), and its orientation checked on the swapped profiles: D(a,a′) = −D(a′,a)
example (k : ℕ) (z : Polymer N → ℝ) (P : Polymer N → Prop) (r R : Set (Link N)) {a a' : Polymer N → ℝ}
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η) :
    kpLocalizedDiffCoeff k z P r R a a' = - kpLocalizedDiffCoeff k z P r R a' a := by
  rw [← kpLocalizedDiff_inclusion_exclusion k z P r R hsame,
    ← kpLocalizedDiff_inclusion_exclusion k z P r R (fun η h => (hsame η h).symm)]
  ring
-- (c) EMPTY PRODUCT: the empty tuple has weight 1 under any profile; order 0 coefficient vanishes (own proof)
example (R : Set (Link N)) (a : Polymer N → ℝ) : tupleProfileWeight R a (default : Fin 0 → Polymer N) = 1 := by
  unfold tupleProfileWeight; simp
example (z : Polymer N → ℝ) (P : Polymer N → Prop) (r R : Set (Link N)) (a a' : Polymer N → ℝ) :
    kpLocalizedDiffCoeff (N := N) 0 z P r R a a' = 0 := by
  unfold kpLocalizedDiffCoeff
  have hP : ∀ δ : Fin 0 → Polymer N, TupleAllowed P δ := fun δ i => Fin.elim0 i
  simp [TupleHitsBothForbidden, hP]
-- (d) ZERO FACTOR: a polymer touching R with a η = 0 has weight 0 in {η}; the localized bound with the effective δ = 1
example (R r : Set (Link N)) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R)
    (a : Polymer N → ℝ) (ha : a η = 0) : profileWeight R a {η} = 0 := by
  unfold profileWeight touchFactor; rw [Finset.prod_singleton, if_pos hR, ha]
example (R r : Set (Link N)) (Γ : Finset (Polymer N)) :
    |profileWeight R (fun _ => (0:ℝ)) Γ - profileWeight R (fun _ => (1:ℝ)) Γ| ≤ (touchCount r Γ : ℝ) * 1 ∨
    ¬ (∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R (fun _ => (0:ℝ)) η = touchFactor R (fun _ => (1:ℝ)) η) := by
  by_cases hs : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R (fun _ => (0:ℝ)) η = touchFactor R (fun _ => (1:ℝ)) η
  · left
    exact abs_profileWeight_sub_le_localized R r (fun _ => le_rfl) (fun _ => zero_le_one) (fun _ => zero_le_one)
      (fun _ => le_rfl) hs (fun η _ => by unfold touchFactor; split_ifs <;> norm_num) Γ
  · right; exact hs
-- (d') the zero/one pair with r = R (where hsame is automatic): |A_Γ(0) − A_Γ(1)| ≤ touchCount R Γ
example (R : Set (Link N)) (Γ : Finset (Polymer N)) :
    |profileWeight R (fun _ => (0:ℝ)) Γ - profileWeight R (fun _ => (1:ℝ)) Γ| ≤ (touchCount R Γ : ℝ) * 1 :=
  abs_profileWeight_sub_le_localized R R (fun _ => le_rfl) (fun _ => zero_le_one) (fun _ => zero_le_one) (fun _ => le_rfl)
    (localized_hypotheses_of_profile_hypotheses R (δ := 1) (a := fun _ => 0) (a' := fun _ => 1) (fun _ _ => by norm_num)).1
    (localized_hypotheses_of_profile_hypotheses R (δ := 1) (a := fun _ => 0) (a' := fun _ => 1) (fun _ _ => by norm_num)).2 Γ
-- (e) REPETITION: the tuple ![η, η] counts the position twice; its weight is the square of the effective factor
example (R r : Set (Link N)) (η : Polymer N) (h : typedTouchesSupport (N := N) η r) :
    tupleTouchCount r ![η, η] = 2 := by
  unfold tupleTouchCount
  have : (Finset.univ.filter (fun i : Fin 2 => typedTouchesSupport (N := N) (![η, η] i) r)) = Finset.univ := by
    ext i; fin_cases i <;> simp [h]
  rw [this]; simp
example (R : Set (Link N)) (a : Polymer N → ℝ) (η : Polymer N) :
    tupleProfileWeight R a ![η, η] = touchFactor R a η ^ 2 := by
  unfold tupleProfileWeight; simp [Fin.prod_univ_two, sq]
-- (e') the localized tuple bound with repetition: |A_δ − A′_δ| ≤ 2·δ for δ = ![η,η], η touching r (positions counted)
example (R r : Set (Link N)) {a a' : Polymer N → ℝ} {δ : ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ)
    (η : Polymer N) (h : typedTouchesSupport (N := N) η r) :
    |tupleProfileWeight R a ![η, η] - tupleProfileWeight R a' ![η, η]| ≤ 2 * δ := by
  have := abs_tupleProfileWeight_sub_le_localized R r h0 h1 h0' h1' hsame hδ ![η, η]
  have hc : tupleTouchCount r ![η, η] = 2 := by
    unfold tupleTouchCount
    have : (Finset.univ.filter (fun i : Fin 2 => typedTouchesSupport (N := N) (![η, η] i) r)) = Finset.univ := by
      ext i; fin_cases i <;> simp [h]
    rw [this]; simp
  rw [hc] at this; simpa using this
end LatticeGauge
