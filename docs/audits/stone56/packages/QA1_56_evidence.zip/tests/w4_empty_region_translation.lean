import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W4: r = ∅ under hsame vs R = ∅; algebraic equality for real profiles outside [0,1]; r = R translation and recovery of 55.
-- (a) r = ∅ with R ≠ ∅ in general: hsame becomes "equal effective factors everywhere". Profiles OUTSIDE [0,1], non-constant,
--     equal on the R-touching polymers and different (card+3 vs −5) elsewhere: F_R(a) = F_R(a′) exactly, no KP, no separation.
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) :
    profileExpectation μm β χ f s R (fun η => (η.val.card : ℝ) + 3)
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then (η.val.card : ℝ) + 3 else -5) :=
  profileExpectation_eq_of_same_empty_region μm β χ f s R
    (fun η _ => by unfold touchFactor; split_ifs with h <;> simp [h])
-- (a') r = ∅ does NOT make hsame vacuous: for R ≠ ∅ it demands equality on every polymer (own statement of the content)
example (R : Set (Link N)) {a a' : Polymer N → ℝ}
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) → touchFactor R a η = touchFactor R a' η) :
    ∀ η, touchFactor R a η = touchFactor R a' η :=
  fun η => hsame η (not_blockTouchesSupport_empty η.val)
-- (b) R = ∅ (55-A): ALL effective factors are 1, so the functionals coincide for ARBITRARY profiles with NO hypothesis at all
--     (distinct from (a): here a and a′ are unrelated). Own derivation via the 56 interface, and the published 55 identity.
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) (a a' : Polymer N → ℝ) :
    profileExpectation μm β χ f s (∅ : Set (Link N)) a = profileExpectation μm β χ f s (∅ : Set (Link N)) a' :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s ∅
    (fun η => by
      have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
      unfold touchFactor; simp [h])
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s : Set (Link N)) (a a' : Polymer N → ℝ) :
    profileExpectation μm β χ f s (∅ : Set (Link N)) a = profileExpectation μm β χ f s (∅ : Set (Link N)) a' :=
  sub_eq_zero.mp (profileExpectation_sub_profileExpectation_empty_region μm β χ f s a a')
-- (c) algebraic equality for real profiles outside [0,1] (own re-derivation, without the candidate's interface):
--     equal effective factors ⇒ equal damped activities ⇒ equal gases and numerators
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) {a a' : Polymer N → ℝ}
    (hb : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have hact : profileDampedActivity (fun η => polymerWeight (N := N) μm β χ η.val) R a
      = profileDampedActivity (fun η => polymerWeight (N := N) μm β χ η.val) R a' := by
    funext η
    have h := hb η
    unfold touchFactor at h
    unfold profileDampedActivity
    by_cases ht : typedTouchesSupport (N := N) η R
    · rw [if_pos ht, if_pos ht]; rw [if_pos ht, if_pos ht] at h; rw [h]
    · rw [if_neg ht, if_neg ht]
  have hw : ∀ Γ : Finset (Polymer N), profileWeight R a Γ = profileWeight R a' Γ := by
    intro Γ; unfold profileWeight; exact Finset.prod_congr rfl (fun η _ => hb η)
  unfold profileExpectation profileMarkedGas profilePolymerGas
  rw [hact]
  congr 1
  exact Finset.sum_congr rfl (fun Γ _ => by rw [hw Γ])
-- (c') concrete: a = 3·card, a′ = 3·card + 10 off R (both outside [0,1]); exact equality by (c)
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) :
    profileExpectation μm β χ f s R (fun η => 3 * (η.val.card : ℝ))
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then 3 * (η.val.card : ℝ) else 3 * (η.val.card : ℝ) + 10) :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s R (fun η => by unfold touchFactor; split_ifs with h <;> simp [h])
-- (d) r = R TRANSLATION (own proof): the raw 55 hypothesis gives hsame (both factors 1 off R) and the effective majorant on R
example (R : Set (Link N)) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ : ∀ η, typedTouchesSupport (N := N) η R → |a η - a' η| ≤ δ) :
    (∀ η, ¬ typedTouchesSupport (N := N) η R → touchFactor R a η = touchFactor R a' η)
    ∧ (∀ η, typedTouchesSupport (N := N) η R → |touchFactor R a η - touchFactor R a' η| ≤ δ) := by
  refine ⟨fun η h => ?_, fun η h => ?_⟩
  · unfold touchFactor; simp [h]
  · unfold touchFactor; simp only [h, if_true]; exact hδ η h
-- (e) RECOVERY of the Stone 55 statement from the 56 capstone with R := r (own; the published 55 capstone NOT used)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |a η - a' η| ≤ δ) :
    |profileExpectation μm β χ f s r a - profileExpectation μm β χ f s r a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall r mf hCf hsep hδ0 h0 h1 h0' h1'
    (fun η h => by unfold touchFactor; simp [h])
    (fun η h => by unfold touchFactor; simp only [h, if_true]; exact hδ η h)
-- (f) SIGNATURE COMPARISON: the 56 recovery theorem and the published 55 capstone have DEFINITIONALLY EQUAL types (both directions)
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |a η - a' η| ≤ δ),
    |profileExpectation μm β χ f s r a - profileExpectation μm β χ f s r a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_of_localized N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |a η - a' η| ≤ δ),
    |profileExpectation μm β χ f s r a - profileExpectation μm β χ f s r a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay N _ _ G _ _ _ _ μm _ _
-- (g) scalar recovery of the Stone 54 statement through 56 (R := r, constant profiles), own specialization
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ}
    (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {θ θ' : ℝ} (h0 : 0 ≤ θ) (h1 : θ ≤ 1) (h0' : 0 ≤ θ') (h1' : θ' ≤ 1) :
    |activityDampedExpectation μm β χ f s r θ - activityDampedExpectation μm β χ f s r θ'|
      ≤ |θ - θ'| * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) := by
  have h := abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall r mf hCf hsep
    (a := fun _ => θ) (a' := fun _ => θ') (δ := |θ - θ'|) (abs_nonneg _) (fun _ => h0) (fun _ => h1) (fun _ => h0') (fun _ => h1')
    (fun η hη => by unfold touchFactor; simp [hη])
    (fun η hη => by unfold touchFactor; simp only [hη, if_true]; exact le_rfl)
  rwa [profileExpectation_const, profileExpectation_const] at h
end LatticeGauge
