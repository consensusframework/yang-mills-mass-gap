import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W7: LOCALIZATION EXAMPLES.
-- (a) a large damping region R (e.g. R ⊇ r or any R) with background b ∈ [0,1] and a local change c ∈ [0,1] on r:
--     the response is controlled by |b − c| and the separation of s from r ONLY; R never needs to be separated from s.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {b c : ℝ} (hb0 : 0 ≤ b) (hb1 : b ≤ 1) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    |profileExpectation μm β χ f s R (fun _ => b)
        - profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η r then c else b)|
      ≤ |b - c| * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := |b - c|) (abs_nonneg _) (fun _ => hb0) (fun _ => hb1)
    (fun η => by beta_reduce; split_ifs <;> assumption) (fun η => by beta_reduce; split_ifs <;> assumption)
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη])
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη])
-- (b) when NO polymer touches both R and r, a change supported on r is invisible to F_R: exact equality (own, via the
--     effective interface) — the localization is through the effective factors, not through the raw profiles
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s r R : Set (Link N))
    (hdis : ∀ η : Polymer N, typedTouchesSupport (N := N) η r → ¬ typedTouchesSupport (N := N) η R)
    (a : Polymer N → ℝ) (c : ℝ) :
    profileExpectation μm β χ f s R a
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η r then c else a η) := by
  refine profileExpectation_eq_of_touchFactor_eq μm β χ f s R (fun η => ?_)
  unfold touchFactor
  by_cases hR : typedTouchesSupport (N := N) η R
  · have hr : ¬ typedTouchesSupport (N := N) η r := fun h => hdis η h hR
    simp [hR, hr]
  · simp [hR]
-- (c) the same, through the capstone with effective δ = 0 (profiles in [0,1]): the bound is 0
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    (hdis : ∀ η : Polymer N, typedTouchesSupport (N := N) η r → ¬ typedTouchesSupport (N := N) η R)
    {a : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) {c : ℝ} (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    |profileExpectation μm β χ f s R a
        - profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η r then c else a η)|
      ≤ 0 * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 0) le_rfl h0 h1 (fun η => by beta_reduce; split_ifs; exact hc0; exact h0 η)
    (fun η => by beta_reduce; split_ifs; exact hc1; exact h1 η)
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη])
    (fun η hη => by
      have hR : ¬ typedTouchesSupport (N := N) η R := hdis η hη
      unfold touchFactor; simp [hR])
-- (d) s arbitrary relative to R: the separation hypothesis mentions only s and r; instantiate r := ∅ (separation trivial)
--     with R arbitrary: the bound holds for every n, and indeed the difference is 0 by hsame (equal factors everywhere)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) (n : ℕ)
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ 0 * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) := by
  have hsep : WalkBarrierSeparated (N := N) s (∅ : Set (Link N)) n := by
    intro p q _ hq w; exfalso; unfold plaquetteTouchesRegion at hq; simp at hq
  exact abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 0) le_rfl h0 h1 h0' h1' (fun η _ => heff η) (fun η h => absurd h (not_blockTouchesSupport_empty η.val))
end LatticeGauge
