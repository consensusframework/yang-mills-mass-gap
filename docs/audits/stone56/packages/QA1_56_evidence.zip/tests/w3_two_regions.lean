import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W3: TWO DISTINCT REGIONS R ≠ r, with NO premise of separation of s from R, NO r ⊆ R, NO unit background outside r.
-- (a) R := Set.univ (damping everywhere), r arbitrary, background 1/2 everywhere, change to 1/4 on r-touching polymers:
--     only WalkBarrierSeparated s r n is used; the bound holds with δ = 1/4.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) :
    |profileExpectation μm β χ f s Set.univ (fun _ => (1/2 : ℝ))
        - profileExpectation μm β χ f s Set.univ (fun η => if typedTouchesSupport (N := N) η r then (1/4 : ℝ) else 1/2)|
      ≤ (1/4) * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall Set.univ mf hCf hsep
    (δ := 1/4) (by norm_num) (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η => by beta_reduce; split_ifs <;> norm_num) (fun η => by beta_reduce; split_ifs <;> norm_num)
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη])
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη] <;> (rw [abs_le]; constructor <;> norm_num))
-- (b) R arbitrary and UNRELATED to r and s (no inclusion, no separation of s from R); same profiles as in (a)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) :
    |profileExpectation μm β χ f s R (fun _ => (1/2 : ℝ))
        - profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η r then (1/4 : ℝ) else 1/2)|
      ≤ (1/4) * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 1/4) (by norm_num) (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η => by beta_reduce; split_ifs <;> norm_num) (fun η => by beta_reduce; split_ifs <;> norm_num)
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη])
    (fun η hη => by unfold touchFactor; split_ifs <;> simp [hη] <;> (rw [abs_le]; constructor <;> norm_num))
-- (c) the profiles of (b) are NOT unit outside r when they touch R: the background is 1/2 there (non-unit background)
example (R r : Set (Link N)) (η : Polymer N) (hR : typedTouchesSupport (N := N) η R) (hr : ¬ typedTouchesSupport (N := N) η r) :
    touchFactor R (fun η => if typedTouchesSupport (N := N) η r then (1/4 : ℝ) else 1/2) η = 1/2 := by
  unfold touchFactor; simp [hR, hr]
-- (d) the series identity and the ledger need neither separation nor hδ: R, r, s all arbitrary (retyped interfaces)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) (T : Finset (Polymer N)) (s r R : Set (Link N))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η) :
    profileCoreExponent μm β χ T s R a - profileCoreExponent μm β χ T s R a' = localizedConnectorDiff μm β χ T s r R a a' :=
  profileCoreExponent_sub_eq_localizedConnectorDiff μm hβ mχ hχabs hsmall T s r R h0 h1 h0' h1' hsame
-- (e) the erosion uses the separation of s from r only (R free): retyped with R := Set.univ and R := ∅ in the same statement
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {T : Finset (Polymer N)} {s r : Set (Link N)} {n : ℕ}
    (hT : T ∈ typedTouchingFamilies (N := N) s) (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsameU : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor Set.univ a η = touchFactor Set.univ a' η)
    (hδU : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor Set.univ a η - touchFactor Set.univ a' η| ≤ δ) :
    |localizedConnectorDiff μm β χ T s r Set.univ a a'|
      ≤ δ * Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) * (((barrierLinkFinset T s).card : ℝ) * (2 / 113))
    ∧ |localizedConnectorDiff μm β χ T s r ∅ a a'|
      ≤ δ * Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) * (((barrierLinkFinset T s).card : ℝ) * (2 / 113)) :=
  ⟨abs_localizedConnectorDiff_le_eroded μm hβ mχ hχabs hsmall Set.univ hT hsep hδ0 h0 h1 h0' h1' hsameU hδU,
   abs_localizedConnectorDiff_le_eroded μm hβ mχ hχabs hsmall ∅ hT hsep hδ0 h0 h1 h0' h1'
     (fun η _ => by
       have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
       unfold touchFactor; simp [h])
     (fun η _ => by
       have h : ¬ typedTouchesSupport (N := N) η (∅ : Set (Link N)) := not_blockTouchesSupport_empty η.val
       unfold touchFactor; simp [h, hδ0])⟩
end LatticeGauge
