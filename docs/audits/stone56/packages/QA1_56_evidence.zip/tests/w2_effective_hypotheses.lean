import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W2: EFFECTIVE HYPOTHESES. The capstone reads the profiles only through the effective factors touchFactor R a.
-- (a) raw profiles DIFFERING outside R (a′ = 0 off R, a arbitrary in [0,1]) with EQUAL effective factors:
--     hsame and hδ hold with δ = 0 for ANY r; the capstone gives |F_R(a) − F_R(a′)| ≤ 0, hence equality.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) :
    profileExpectation μm β χ f s R a
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then a η else 0) := by
  have heff : ∀ η, touchFactor R a η
      = touchFactor R (fun η => if typedTouchesSupport (N := N) η R then a η else 0) η := by
    intro η; unfold touchFactor; split_ifs with h <;> simp [h]
  have h := abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (a := a) (a' := fun η => if typedTouchesSupport (N := N) η R then a η else 0) (δ := 0) le_rfl h0 h1
    (fun η => by dsimp only; split_ifs; exact h0 η; exact le_rfl)
    (fun η => by dsimp only; split_ifs; exact h1 η; exact zero_le_one)
    (fun η _ => heff η) (fun η _ => by rw [heff η]; simp)
  have hz : (0:ℝ) * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) = 0 := by
    ring
  rw [hz] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (a') the same equality WITHOUT the KP regime, for ARBITRARY real profiles (outside [0,1]), by the exact interface
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (a : Polymer N → ℝ) :
    profileExpectation μm β χ f s R a
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then a η else -17) :=
  profileExpectation_eq_of_touchFactor_eq μm β χ f s R
    (fun η => by unfold touchFactor; split_ifs with h <;> simp [h])
-- (b) effective δ = 0: profiles with equal effective factors on r-touching polymers (raw values may differ off R): equality
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have h := abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 0) le_rfl h0 h1 h0' h1' (fun η _ => heff η) (fun η _ => by rw [heff η]; simp)
  have hz : (0:ℝ) * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) = 0 := by
    ring
  rw [hz] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (c) δ = 7 admitted (no δ ≤ 1): any two profiles in [0,1] with equal effective factors off r
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ 7 * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 7) (by norm_num) h0 h1 h0' h1' hsame
    (fun η _ => by
      have := touchFactor_nonneg R h0 η; have := touchFactor_le_one R h1 η
      have := touchFactor_nonneg R h0' η; have := touchFactor_le_one R h1' η
      rw [abs_le]; constructor <;> linarith)
-- (d) the effective majorant is weaker than the raw one: raw |a − a′| ≤ δ on r ⇒ effective |τ_R a − τ_R a′| ≤ δ on r (own),
--     but hsame is NOT implied by the raw hypothesis when r ≠ R (this is why the candidate keeps hsame; see W7x)
example (R r : Set (Link N)) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (hraw : ∀ η, typedTouchesSupport (N := N) η r → |a η - a' η| ≤ δ) :
    ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ := by
  intro η h
  unfold touchFactor
  split_ifs
  · exact hraw η h
  · simpa using hδ0
end LatticeGauge
