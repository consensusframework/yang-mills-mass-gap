import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W5: EXPONENTS, EROSION, BILATERAL CONTROL AND BUDGETS.
-- (a) erosion m_T > n: the truncated subtraction gives n − m_T = 0 and the eroded bound degenerates to δ·1·q_T (no negative exponent)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {T : Finset (Polymer N)} {s r : Set (Link N)} (R : Set (Link N)) {n : ℕ}
    (hT : T ∈ typedTouchingFamilies (N := N) s) (hsep : WalkBarrierSeparated (N := N) s r n)
    (hbig : n < familyTotalCard T)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |localizedConnectorDiff μm β χ T s r R a a'| ≤ δ * (((barrierLinkFinset T s).card : ℝ) * (2 / 113)) := by
  have h := abs_localizedConnectorDiff_le_eroded μm hβ mχ hχabs hsmall R hT hsep hδ0 h0 h1 h0' h1' hsame hδ
  have hz : n - familyTotalCard T = 0 := Nat.sub_eq_zero_of_le hbig.le
  rw [hz] at h
  simpa using h
-- (b) the κ = 2 bilateral control RE-DERIVED by the auditor from the 54 scalar lemma, the R-barrier of 55-A, the eroded bound
--     and the repurchase of the erosion (without the candidate's control theorem)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {T : Finset (Polymer N)} {s r : Set (Link N)} (R : Set (Link N)) {n : ℕ}
    (hT : T ∈ typedTouchingFamilies (N := N) s) (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')|
      ≤ δ * Real.exp (-(n : ℝ) / 2)
        * Real.exp ((familyTotalCard T : ℝ) / 2 + 2 * ((barrierLinkFinset T s).card : ℝ) * (2 / 113)) := by
  set q : ℝ := ((barrierLinkFinset T s).card : ℝ) * (2 / 113) with hq
  have hx : profileCoreExponent μm β χ T s R a ≤ q :=
    le_trans (le_abs_self _) (abs_profileCoreExponent_le_barrier μm hβ mχ hχabs hsmall T s R h0 h1)
  have hy : profileCoreExponent μm β χ T s R a' ≤ q :=
    le_trans (le_abs_self _) (abs_profileCoreExponent_le_barrier μm hβ mχ hχabs hsmall T s R h0' h1')
  have hΔ : |profileCoreExponent μm β χ T s R a - profileCoreExponent μm β χ T s R a'|
      ≤ δ * Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) * q := by
    rw [profileCoreExponent_sub_eq_localizedConnectorDiff μm hβ mχ hχabs hsmall T s r R h0 h1 h0' h1' hsame]
    exact abs_localizedConnectorDiff_le_eroded μm hβ mχ hχabs hsmall R hT hsep hδ0 h0 h1 h0' h1' hsame hδ
  have hE := abs_exp_sub_exp_le_exp_mul_abs_sub hx hy
  have hqe : q ≤ Real.exp q := le_exp_self q
  have her := exp_neg_nat_sub_half_le n (familyTotalCard T)
  have hpos : 0 < Real.exp q := Real.exp_pos _
  have hpos2 : 0 ≤ Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) := (Real.exp_pos _).le
  have hfinal : Real.exp ((familyTotalCard T : ℝ) / 2 + 2 * ((barrierLinkFinset T s).card : ℝ) * (2 / 113))
      = Real.exp ((familyTotalCard T : ℝ) / 2) * (Real.exp q * Real.exp q) := by
    rw [← Real.exp_add, ← Real.exp_add, hq]; congr 1; ring
  rw [hfinal]
  calc |Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')|
      ≤ Real.exp q * |profileCoreExponent μm β χ T s R a - profileCoreExponent μm β χ T s R a'| := hE
    _ ≤ Real.exp q * (δ * Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) * q) :=
        mul_le_mul_of_nonneg_left hΔ hpos.le
    _ ≤ Real.exp q * (δ * Real.exp (-(((n - familyTotalCard T : ℕ)) : ℝ) / 2) * Real.exp q) :=
        mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hqe (mul_nonneg hδ0 hpos2)) hpos.le
    _ ≤ Real.exp q * (δ * (Real.exp (-(n : ℝ) / 2) * Real.exp ((familyTotalCard T : ℝ) / 2)) * Real.exp q) := by
        apply mul_le_mul_of_nonneg_left _ hpos.le
        apply mul_le_mul_of_nonneg_right _ hpos.le
        exact mul_le_mul_of_nonneg_left her hδ0
    _ = δ * Real.exp (-(n : ℝ) / 2) * (Real.exp ((familyTotalCard T : ℝ) / 2) * (Real.exp q * Real.exp q)) := by ring
-- (c) the two-region first moment: bridge geometry with r, exponent with R (R := ∅ and R := Set.univ both accepted)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf0 : 0 ≤ Cf) (hCf : ∀ U, |f U| ≤ Cf)
    {T : Finset (Polymer N)} {s r : Set (Link N)} {n : ℕ}
    (hT : T ∈ activityBridgeCores (N := N) s r) (hsep : WalkBarrierSeparated (N := N) s r n)
    {a : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) :
    (T.card : ℝ) * |typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s Set.univ a)|
      ≤ Real.exp (-(n : ℝ) / 2) * Cf
          * (Real.exp (1 * ((barrierLinkFinset T s).card : ℝ) * (2/113)) * ∏ η ∈ T, massTiltActivity (7/8) (mayerCoreMajorant β) η)
    ∧ (T.card : ℝ) * |typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s ∅ a)|
      ≤ Real.exp (-(n : ℝ) / 2) * Cf
          * (Real.exp (1 * ((barrierLinkFinset T s).card : ℝ) * (2/113)) * ∏ η ∈ T, massTiltActivity (7/8) (mayerCoreMajorant β) η) :=
  ⟨nat_card_mul_abs_profileNormalizedTerm_le_bridge_two_regions μm hβ mχ hχabs hsmall mf hCf0 hCf Set.univ hT hsep h0 h1,
   nat_card_mul_abs_profileNormalizedTerm_le_bridge_two_regions μm hβ mχ hχabs hsmall mf hCf0 hCf ∅ hT hsep h0 h1⟩
-- (c') the published 55-B interface is the two-region one at R := r (own check of the specialization)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf0 : 0 ≤ Cf) (hCf : ∀ U, |f U| ≤ Cf)
    {T : Finset (Polymer N)} {s r : Set (Link N)} {n : ℕ}
    (hT : T ∈ activityBridgeCores (N := N) s r) (hsep : WalkBarrierSeparated (N := N) s r n)
    {a : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) :
    (T.card : ℝ) * |typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s r a)|
      ≤ Real.exp (-(n : ℝ) / 2) * Cf
          * (Real.exp (1 * ((barrierLinkFinset T s).card : ℝ) * (2/113)) * ∏ η ∈ T, massTiltActivity (7/8) (mayerCoreMajorant β) η) :=
  nat_card_mul_abs_profileNormalizedTerm_le_bridge_two_regions μm hβ mχ hχabs hsmall mf hCf0 hCf r hT hsep h0 h1
-- (d) BUDGETS: (1/2, 2) = e^{3·D·2/113} and (7/8, 1) = e^{2·D·2/113}, retyped; the connector constant 3·D·(2/113) = 6D/113
example {β : ℝ} (hβ : 0 ≤ β) (hsmall : β ≤ (1 : ℝ) / 40000) (s : Set (Link N)) :
    (∑ T ∈ typedTouchingFamilies (N := N) s, halfTiltCoreBudgetTerm β 2 s T)
      ≤ Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113)) :=
  sum_halfTilt_two_le hβ hsmall s
example {β : ℝ} (hβ : 0 ≤ β) (hsmall : β ≤ (1 : ℝ) / 40000) (s : Set (Link N)) :
    (∑ T ∈ typedTouchingFamilies (N := N) s,
        Real.exp (1 * ((barrierLinkFinset T s).card : ℝ) * (2/113)) * ∏ η ∈ T, massTiltActivity (7/8) (mayerCoreMajorant β) η)
      ≤ Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113)) :=
  sum_sevenEighthsTilt_one_le hβ hsmall s
example (D : ℝ) : Real.exp (3 * D * (2/113)) = Real.exp (6 * D / 113) := by congr 1; ring
-- (e) the two-term form: constants e^{6D/113} + e^{4D/113} kept separate, and e^{4D/113} ≤ e^{6D/113} (D ≥ 0) — own
example (D : ℝ) (hD : 0 ≤ D) : Real.exp (2 * D * (2/113)) ≤ Real.exp (3 * D * (2/113)) :=
  Real.exp_le_exp.mpr (by nlinarith)
end LatticeGauge
