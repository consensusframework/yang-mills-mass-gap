import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W7x (EXPECTED TO FAIL): applying the localized capstone with the RAW Stone 55 hypothesis only (|a − a′| ≤ δ on r) and R ≠ r,
-- WITHOUT hsame. The profiles differ on R-touching polymers off r (a = 1/2, a′ = 1/3 there), so hsame is false and the
-- proof obligation `touchFactor R a η = touchFactor R a' η` cannot be discharged. An APPLICATION FAILURE outside the
-- hypotheses — not evidence of falsity nor of indispensability of hsame.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) :
    |profileExpectation μm β χ f s R (fun _ => (1/2 : ℝ)) - profileExpectation μm β χ f s R (fun _ => (1/3 : ℝ))|
      ≤ (1/6) * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized μm hβ mχ hχabs hsmall R mf hCf hsep
    (δ := 1/6) (by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η hη => by unfold touchFactor; split_ifs <;> norm_num)   -- hsame: cannot be proved for η touching R but not r
    (fun η hη => by unfold touchFactor; split_ifs <;> (rw [abs_le]; constructor <;> norm_num))
end LatticeGauge
