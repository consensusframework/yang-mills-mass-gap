import Mathlib
import LatticeGauge.ActivityProfileDampingLocality
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- W6: OWN CLOSURE. (a) the localized ledger RE-DERIVED from the exponential representation of both sides (55-A), the
--     allowed/bridge split of the touching cores (52), and cancellation on the r-allowed cores BY EQUALITY of the weights
--     (hsame) — not by weight 1; the candidate's ledger lemma is NOT used.
theorem W6_ledger {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) (f : Config N G → ℝ) (s r R : Set (Link N))
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'
      = (∑ T ∈ typedTouchingFamilies (N := N) s, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
            * (Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')))
        + ∑ T ∈ activityBridgeCores (N := N) s r, (profileWeight R a T - profileWeight R a' T)
            * typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s R a) := by
  rw [profileExpectation_eq_sum_core_mul_exp μm hβ mχ hχabs hsmall f s R h0 h1,
    profileExpectation_eq_sum_core_mul_exp μm hβ mχ hχabs hsmall f s R h0' h1']
  rw [sum_touchingFamilies_eq_activityAllowed_add_bridge s r, sum_touchingFamilies_eq_activityAllowed_add_bridge s r
    (fun T => profileWeight R a' T * typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s R a')),
    sum_touchingFamilies_eq_activityAllowed_add_bridge s r
    (fun T => profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
      * (Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')))]
  -- on the r-allowed cores the two weights are EQUAL (own: touchCount r T = 0 from membership, then the product congruence)
  have hEq : ∀ T ∈ activityAllowedCores (N := N) s r, profileWeight R a T = profileWeight R a' T := by
    intro T hT
    have hall : ∀ η ∈ T, ¬ typedTouchesSupport (N := N) η r := (mem_activityAllowedCores.mp hT).2
    unfold profileWeight
    exact Finset.prod_congr rfl (fun η hη => hsame η (hall η hη))
  rw [Finset.sum_congr rfl (fun T hT => by rw [hEq T hT] :
        ∀ T ∈ activityAllowedCores (N := N) s r, profileWeight R a T * typedMarkedCoreWeight μm β χ f T
          * Real.exp (profileCoreExponent μm β χ T s R a)
          = profileWeight R a' T * typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s R a))]
  have eA : (∑ T ∈ activityAllowedCores (N := N) s r, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
        * (Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')))
      = (∑ T ∈ activityAllowedCores (N := N) s r, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
            * Real.exp (profileCoreExponent μm β χ T s R a))
        - ∑ T ∈ activityAllowedCores (N := N) s r, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
            * Real.exp (profileCoreExponent μm β χ T s R a') := by
    rw [← Finset.sum_sub_distrib]; exact Finset.sum_congr rfl (fun T _ => by ring)
  have eB : (∑ T ∈ activityBridgeCores (N := N) s r, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
        * (Real.exp (profileCoreExponent μm β χ T s R a) - Real.exp (profileCoreExponent μm β χ T s R a')))
      + (∑ T ∈ activityBridgeCores (N := N) s r, (profileWeight R a T - profileWeight R a' T)
          * typedMarkedCoreWeight μm β χ f T * Real.exp (profileCoreExponent μm β χ T s R a))
      = (∑ T ∈ activityBridgeCores (N := N) s r, profileWeight R a T * typedMarkedCoreWeight μm β χ f T
            * Real.exp (profileCoreExponent μm β χ T s R a))
        - ∑ T ∈ activityBridgeCores (N := N) s r, profileWeight R a' T * typedMarkedCoreWeight μm β χ f T
            * Real.exp (profileCoreExponent μm β χ T s R a') := by
    rw [← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]; exact Finset.sum_congr rfl (fun T _ => by ring)
  rw [eA]; linarith [eB]
-- (b) CLOSURE from the two columns to the two-term form and the capstone, WITHOUT the candidate's two final theorems
theorem W6_closure {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) := by
  have hCf0 : 0 ≤ Cf := le_trans (abs_nonneg _) (hCf (fun _ => 1))
  have hA := abs_sum_localizedConnectorColumn_le μm hβ mχ hχabs hsmall mf hCf0 hCf R hsep hδ0 h0 h1 h0' h1' hsame hδ
  have hB := abs_sum_localizedBridgeColumn_le μm hβ mχ hχabs hsmall mf hCf0 hCf R hsep hδ0 h0 h1 h0' h1' hsame hδ
  rw [W6_ledger μm hβ mχ hχabs hsmall f s r R h0 h1 h0' h1' hsame]
  set D : ℝ := ((supportLinkFinset (N := N) s).card : ℝ) with hD
  have hD0 : 0 ≤ D := Nat.cast_nonneg _
  have hmono : Real.exp (2 * D * (2/113)) ≤ Real.exp (3 * D * (2/113)) := Real.exp_le_exp.mpr (by nlinarith)
  have e6 : Real.exp (6 * D / 113) = Real.exp (3 * D * (2/113)) := by congr 1; ring
  have hK : 0 ≤ δ * Cf * Real.exp (-(n : ℝ) / 2) := mul_nonneg (mul_nonneg hδ0 hCf0) (Real.exp_pos _).le
  calc _ ≤ _ := abs_add _ _
    _ ≤ δ * Cf * Real.exp (-(n : ℝ) / 2) * Real.exp (3 * D * (2/113))
          + δ * Cf * Real.exp (-(n : ℝ) / 2) * Real.exp (2 * D * (2/113)) := add_le_add hA hB
    _ ≤ δ * Cf * Real.exp (-(n : ℝ) / 2) * Real.exp (3 * D * (2/113))
          + δ * Cf * Real.exp (-(n : ℝ) / 2) * Real.exp (3 * D * (2/113)) :=
        add_le_add_left (mul_le_mul_of_nonneg_left hmono hK) _
    _ = δ * (2 * Cf) * Real.exp (6 * D / 113) * Real.exp (-(n : ℝ) / 2) := by rw [e6]; ring
#print axioms W6_ledger
#print axioms W6_closure
end LatticeGauge
