#!/usr/bin/env python3
"""56-QA1: full multiline warning-block comparison between the candidate clean-build log and the validated 55 baseline.
Block = a line 'warning: <path>:l:c: msg' plus all following continuation lines up to the next line that begins a new
build event (✔/⚠/✖/info:/warning:/error:/Build/trace:/[N/M]). Normalization: ONLY the path prefix './' repeats before
'LatticeGauge/' is removed. Project (LatticeGauge/) and dependency (.lake/packages/) diagnostics are separated."""
import re, sys, collections
def blocks(path):
    lines=open(path,encoding='utf-8',errors='replace').read().split('\n')
    start=re.compile(r'^(✔|⚠|✖|ℹ|info:|warning:|error:|Build |trace:|\S? ?\[\d+/\d+\])')
    out=[];cur=None
    for l in lines:
        if l.startswith('warning:'):
            if cur: out.append(cur)
            cur=[l]
        elif start.match(l) or l.strip()=='' and cur is None:
            if cur: out.append(cur); cur=None
        elif cur is not None:
            cur.append(l)
    if cur: out.append(cur)
    norm=[]
    for b in out:
        h=re.sub(r'^warning: (\./)+','warning: ',b[0])
        norm.append('\n'.join([h]+b[1:]).rstrip())
    return norm
def split(bl):
    proj=[b for b in bl if b.startswith('warning: LatticeGauge/')]
    dep=[b for b in bl if not b.startswith('warning: LatticeGauge/')]
    return proj,dep
base=sys.argv[1]; cand=sys.argv[2]
bp,bd=split(blocks(base)); cp,cd=split(blocks(cand))
print(f"baseline: total blocks {len(bp)+len(bd)}  project {len(bp)}  dependency {len(bd)}")
print(f"candidate: total blocks {len(cp)+len(cd)}  project {len(cp)}  dependency {len(cd)}")
B=collections.Counter(bp); C=collections.Counter(cp)
print("project blocks: multiset equal (order ignored):", B==C)
if B!=C:
    for k in (B-C): print("ONLY IN BASELINE:\n"+k+"\n")
    for k in (C-B): print("ONLY IN CANDIDATE:\n"+k+"\n")
hb=collections.Counter(b.split('\n')[0] for b in bp); hc=collections.Counter(b.split('\n')[0] for b in cp)
print("project headers: multiset equal:", hb==hc, "| distinct file:line pairs:", len({re.match(r'warning: ([^:]+:\d+)',h).group(1) for h in hb}), len({re.match(r'warning: ([^:]+:\d+)',h).group(1) for h in hc}))
print("candidate project warnings in new module (ActivityProfileDampingLocality):", sum(1 for b in cp if 'ActivityProfileDampingLocality' in b.split('\n')[0]))
print("baseline dependency blocks == candidate dependency blocks (multiset):", collections.Counter(bd)==collections.Counter(cd))
files=collections.Counter(re.match(r'warning: ([^:]+)',b).group(1) for b in cp)
print("candidate project warnings per file:", dict(files))
