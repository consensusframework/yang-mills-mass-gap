import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q1: ONE REGION. (a) effective application of the recovery interface from Stone 56 hypotheses hsame/hδ: the conclusion IS
--     the Stone 56 capstone statement (left-hand side included), closed by `exact`
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_of_multiregion μm hβ mχ hχabs hsmall R mf hCf hsep hδ0
    h0 h1 h0' h1' hsame hδ
-- (b) OWN derivation of the same from the capstone with m = 1: build the cover from hsame/hδ, reduce the Fin 1 sum on the RHS
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2) := by
  have hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin 1, typedTouchesSupport (N := N) η ((fun _ : Fin 1 => r) i)
        ∧ |touchFactor R a η - touchFactor R a' η| ≤ (fun _ : Fin 1 => δ) i := by
    intro η hne
    have ht : typedTouchesSupport (N := N) η r := not_not.mp (fun hnt => hne (hsame η hnt))   -- contraposition of hsame
    exact ⟨0, ht, hδ η ht⟩
  have h := abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf
    (m := 1) (r := fun _ => r) (n := fun _ => n) (δ := fun _ => δ) (fun _ => hδ0) (fun _ => hsep) h0 h1 h0' h1' hcover
  -- the sum over Fin 1 is reduced on the RIGHT-hand side; the left-hand side is untouched
  simp only [Fin.sum_univ_one] at h
  calc _ ≤ _ := h
    _ = _ := by ring
-- (c) SIGNATURE comparison: the recovery interface and the Stone 56 capstone have definitionally equal types (both directions)
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_of_multiregion N _ _ G _ _ _ _ μm _ _
example : (∀ {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1) (hsmall : β ≤ (1 : ℝ) / 40000)
    {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f) {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ),
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ * (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * Real.exp (-(n : ℝ) / 2)) :=
  @abs_profileExpectation_sub_profileExpectation_le_local_exp_decay_localized N _ _ G _ _ _ _ μm _ _
end LatticeGauge
