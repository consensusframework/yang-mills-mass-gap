import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileMultiRegion
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q8x (EXPECTED TO FAIL): the owner composition with `owner ≡ none` for profiles whose effective factors DO change
-- (a = 1/2, a′ = 1/3 on R-touching polymers). The obligation `howner_none` (endpoint identity) is `1/2 = 1/3` for η touching
-- R and cannot be discharged. This exhibits the missing cover obligation on this route; it is NOT a negative theorem about
-- every estimate without a cover.
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ} {δ : Fin m → ℝ}
    (hδ0 : ∀ i, 0 ≤ δ i) (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) :
    |profileExpectation μm β χ f s R (fun _ => (1/2 : ℝ)) - profileExpectation μm β χ f s R (fun _ => (1/3 : ℝ))|
      ≤ Cf * (Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
              + Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113)))
          * ∑ i : Fin m, δ i * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_le_of_owner μm hβ mχ hχabs hsmall R mf hCf hδ0 hsep
    (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num) (fun _ => by norm_num)
    (fun _ => none)
    (fun η _ => by unfold touchFactor; split_ifs <;> norm_num)   -- howner_none: `1/2 = 1/3` when η touches R — FAILS
    (fun η i h => Option.noConfusion h)
    (fun η i h => Option.noConfusion h)
end LatticeGauge
