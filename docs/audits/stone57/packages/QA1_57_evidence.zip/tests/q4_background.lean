import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileMultiRegion
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q4: BACKGROUND, IGNORED VALUES AND ZERO FACTOR.
-- (a) common non-unit background 1/2 preserved in every intermediate profile on coordinates without owner
example {m : ℕ} (owner : Polymer N → Option (Fin m)) (a' : Polymer N → ℝ) (k : ℕ) (η : Polymer N)
    (h : owner η = none) : stepProfile owner (fun _ => (1/2 : ℝ)) a' k η = 1/2 := by
  unfold stepProfile; rw [if_neg]; rintro ⟨i, hi, _⟩; rw [h] at hi; exact Option.noConfusion hi
-- (a′) and on a coordinate owned by i, p_k keeps the background 1/2 for k ≤ i and takes a′ for k > i
example {m : ℕ} (owner : Polymer N → Option (Fin m)) (a' : Polymer N → ℝ) (η : Polymer N) (i : Fin m)
    (h : owner η = some i) :
    (∀ k, k ≤ i.val → stepProfile owner (fun _ => (1/2 : ℝ)) a' k η = 1/2)
    ∧ (∀ k, i.val < k → stepProfile owner (fun _ => (1/2 : ℝ)) a' k η = a' η) := by
  constructor
  · intro k hk; unfold stepProfile; rw [if_neg]; rintro ⟨j, hj, hlt⟩; rw [h] at hj
    have := Option.some.inj hj; subst this; omega
  · intro k hk; unfold stepProfile; rw [if_pos ⟨i, h, hk⟩]
-- (b) raw values DIFFERENT on a polymer avoiding R (a η = 3/10, a′ η = 7/10) but equal effective factors (both 1):
--     owner `none` is admissible there; the last profile p_m has the raw value of a (≠ a′ η) yet the same effective factor.
--     The endpoint identity is by EFFECTIVE factors, not by raw equality.
example {m : ℕ} (R : Set (Link N)) (owner : Polymer N → Option (Fin m)) (η : Polymer N)
    (hR : ¬ typedTouchesSupport (N := N) η R) (a a' : Polymer N → ℝ) (ha : a η = 3/10) (ha' : a' η = 7/10)
    (h : owner η = none) :
    touchFactor R a η = touchFactor R a' η
    ∧ stepProfile owner a a' m η ≠ a' η
    ∧ touchFactor R (stepProfile owner a a' m) η = touchFactor R a' η := by
  refine ⟨?_, ?_, ?_⟩
  · unfold touchFactor; simp [hR]
  · unfold stepProfile; rw [if_neg]; · rw [ha, ha']; norm_num
    rintro ⟨i, hi, _⟩; rw [h] at hi; exact Option.noConfusion hi
  · unfold touchFactor; simp [hR]
-- (b′) `owner ≡ none` everywhere is admissible exactly when ALL effective factors agree — a condition on factors, not on
--     geometry: it neither says nor implies that any polymer avoids the regions r i (own formulation)
example {m : ℕ} (R : Set (Link N)) (a a' : Polymer N → ℝ) :
    (∀ η, (fun _ : Polymer N => (none : Option (Fin m))) η = none → touchFactor R a η = touchFactor R a' η)
      ↔ ∀ η, touchFactor R a η = touchFactor R a' η :=
  ⟨fun h η => h η rfl, fun h η _ => h η⟩
-- (c) the whole last-profile identity, own re-derivation (not via the candidate's lemma): F_R(p_m) = F_R(a′)
example {m : ℕ} (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (owner : Polymer N → Option (Fin m))
    (a a' : Polymer N → ℝ) (hnone : ∀ η, owner η = none → touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R (stepProfile owner a a' m) = profileExpectation μm β χ f s R a' := by
  apply profileExpectation_eq_of_touchFactor_eq μm β χ f s R
  intro η
  rw [touchFactor_stepProfile]
  by_cases hm : moved owner m η
  · rw [if_pos hm]
  · rw [if_neg hm]
    cases ho : owner η with
    | none => exact hnone η ho
    | some i => exact absurd ⟨i, ho, i.isLt⟩ hm
-- (d) ZERO FACTOR: a change starting from factor 0 (a η = 0 on an R-touching polymer, a′ η = 1/2): the cover pays 1/2,
--     no division anywhere; the capstone applies with m = 1, δ = 1/2 (geometry assumed by hypotheses)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n) (η₀ : Polymer N)
    (ht : typedTouchesSupport (N := N) η₀ r) :
    |profileExpectation μm β χ f s R (fun η => if η = η₀ then (0:ℝ) else 1/2)
        - profileExpectation μm β χ f s R (fun _ => (1/2 : ℝ))|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin 1, (fun _ => (1/2 : ℝ)) i * Real.exp (-(((fun _ => n) i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf
    (m := 1) (r := fun _ => r) (n := fun _ => n) (δ := fun _ => 1/2) (fun _ => by norm_num) (fun _ => hsep)
    (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num) (fun η => by by_cases h : η = η₀ <;> simp [h] <;> norm_num)
    (fun _ => by norm_num) (fun _ => by norm_num)
    (fun η hne => by
      refine ⟨0, ?_, ?_⟩
      · -- the factors differ only at η₀ (and only if η₀ touches R); hence η = η₀, which touches r
        by_contra hnt
        apply hne
        unfold touchFactor
        split_ifs with hR
        · by_cases h : η = η₀
          · subst h; exact absurd ht hnt
          · simp [h]
        · rfl
      · unfold touchFactor
        by_cases h : η = η₀
        · subst h
          by_cases hR : typedTouchesSupport (N := N) η R <;> simp [hR] <;> norm_num [abs_le]
        · by_cases hR : typedTouchesSupport (N := N) η R <;> simp [hR, h])
end LatticeGauge
