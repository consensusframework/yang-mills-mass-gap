import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q6: INTENSITY AND COST COMPARISON. (a) δ i = 7 for every region, Cf general: no `δ i ≤ 1` hypothesis
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcov : ∀ η, touchFactor R a η ≠ touchFactor R a' η → ∃ i : Fin m, typedTouchesSupport (N := N) η (r i)) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113)
          * ∑ i : Fin m, (7 : ℝ) * Real.exp (-((n i : ℕ) : ℝ) / 2) :=
  abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf (δ := fun _ => 7)
    (fun _ => by norm_num) hsep h0 h1 h0' h1'
    (fun η hne => by
      obtain ⟨i, hi⟩ := hcov η hne
      refine ⟨i, hi, ?_⟩
      have := touchFactor_nonneg R h0 η; have := touchFactor_le_one R h1 η
      have := touchFactor_nonneg R h0' η; have := touchFactor_le_one R h1' η
      show |touchFactor R a η - touchFactor R a' η| ≤ 7
      rw [abs_le]; constructor <;> linarith)
-- (b) Cf = 0 separately: the right-hand side is 0 whatever δ, hence equality (effective application, δ = 7 kept)
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    (hCf : ∀ U, |f U| ≤ 0) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcov : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ (fun _ => (7:ℝ)) i) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have h := abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf (δ := fun _ => 7)
    (fun _ => by norm_num) hsep h0 h1 h0' h1' hcov
  simp only [mul_zero, zero_mul] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (c) EXACT COST COMPARISON (scalar, no geometry claimed): two regions with amplitudes 1/2, 1/2 and separations 0, 4
--     against a single region with amplitude 1 and separation 0: B₂ = 1/2 + (1/2)e^{−2} < 1 = B₁.
example : (∑ i : Fin 2, ![(1/2 : ℝ), 1/2] i * Real.exp (-((![0, 4] i : ℕ) : ℝ) / 2))
    < ∑ i : Fin 1, (1 : ℝ) * Real.exp (-(((fun _ => 0) i : ℕ) : ℝ) / 2) := by
  simp only [Fin.sum_univ_two, Fin.sum_univ_one]
  simp
  have : Real.exp (-2) < 1 := by have := Real.exp_lt_exp.mpr (show (-2:ℝ) < 0 by norm_num); simpa using this
  linarith
-- (c′) STRICT improvement of the COMPLETE bound requires Cf > 0 (the other factors are positive): own statement
example (Cf D : ℝ) (hCf : 0 < Cf) :
    (2 * Cf) * Real.exp (6 * D / 113) * (∑ i : Fin 2, ![(1/2 : ℝ), 1/2] i * Real.exp (-((![0, 4] i : ℕ) : ℝ) / 2))
    < (2 * Cf) * Real.exp (6 * D / 113) * ∑ i : Fin 1, (1 : ℝ) * Real.exp (-(((fun _ => 0) i : ℕ) : ℝ) / 2) := by
  apply mul_lt_mul_of_pos_left _ (mul_pos (by linarith) (Real.exp_pos _))
  simp only [Fin.sum_univ_two, Fin.sum_univ_one]
  simp
  have : Real.exp (-2) < 1 := by have := Real.exp_lt_exp.mpr (show (-2:ℝ) < 0 by norm_num); simpa using this
  linarith
-- (c″) and with Cf = 0 both complete bounds are 0: no strict improvement (the comparison is of costs B, not of bounds)
example (D : ℝ) :
    (2 * (0:ℝ)) * Real.exp (6 * D / 113) * (∑ i : Fin 2, ![(1/2 : ℝ), 1/2] i * Real.exp (-((![0, 4] i : ℕ) : ℝ) / 2))
    = (2 * (0:ℝ)) * Real.exp (6 * D / 113) * ∑ i : Fin 1, (1 : ℝ) * Real.exp (-(((fun _ => 0) i : ℕ) : ℝ) / 2) := by ring
end LatticeGauge
