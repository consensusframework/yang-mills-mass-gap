import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
open ActivityProfileMultiRegion
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
-- Q3: OVERLAP AND DISTINCT AMPLITUDES. Two regions r 0, r 1 (Fin 2). η₁ touches BOTH regions but is owned by index 0;
-- η₂ is owned by index 1 (nothing is assumed about η₂ and r 0). Geometry assumed by hypotheses (no concrete lattice).
section
variable (η₁ η₂ : Polymer N) (hne : η₁ ≠ η₂)
noncomputable def ownerQ3 : Polymer N → Option (Fin 2) :=
  fun η => if η = η₁ then some 0 else if η = η₂ then some 1 else none
-- (a) the profile of η₁ at each stage: p_0 = a, p_1 = a′, p_2 = a′ (it switches exactly at the step of its owner, 0)
example (a a' : Polymer N → ℝ) :
    stepProfile (ownerQ3 η₁ η₂) a a' 0 η₁ = a η₁
    ∧ stepProfile (ownerQ3 η₁ η₂) a a' 1 η₁ = a' η₁
    ∧ stepProfile (ownerQ3 η₁ η₂) a a' 2 η₁ = a' η₁ := by
  refine ⟨?_, ?_, ?_⟩
  · unfold stepProfile; rw [if_neg (not_moved_zero _ _)]
  · unfold stepProfile; rw [if_pos ⟨0, by simp [ownerQ3], by decide⟩]
  · unfold stepProfile; rw [if_pos ⟨0, by simp [ownerQ3], by decide⟩]
-- (b) the profile of η₂: p_0 = a, p_1 = a (NOT yet switched, although it may or may not touch r 0), p_2 = a′
example (a a' : Polymer N → ℝ) :
    stepProfile (ownerQ3 η₁ η₂) a a' 0 η₂ = a η₂
    ∧ stepProfile (ownerQ3 η₁ η₂) a a' 1 η₂ = a η₂
    ∧ stepProfile (ownerQ3 η₁ η₂) a a' 2 η₂ = a' η₂ := by
  have ho : ownerQ3 η₁ η₂ η₂ = some 1 := by simp [ownerQ3, hne.symm]
  refine ⟨?_, ?_, ?_⟩
  · unfold stepProfile; rw [if_neg (not_moved_zero _ _)]
  · unfold stepProfile
    rw [if_neg]
    rintro ⟨i, hi, hlt⟩
    rw [ho] at hi
    have : i = 1 := (Option.some.inj hi).symm
    subst this; exact absurd hlt (by decide)
  · unfold stepProfile; rw [if_pos ⟨1, ho, by decide⟩]
-- (c) DISTINCT AMPLITUDES: δ 0 = 1/2, δ 1 = 1/10. η₁ touches r 1 as well, and |b η₁ − b′ η₁| = 1/2 > δ 1; yet the
--     step-1 obligation on r 1 holds for η₁ because its coordinate does not move at step 1 (difference 0 ≤ 1/10).
--     Shown directly from the definitions (own), then via the candidate's `step_bound`.
example (R : Set (Link N)) (a a' : Polymer N → ℝ) :
    |touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' 1) η₁ - touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' 2) η₁| ≤ 1/10 := by
  have h1 : stepProfile (ownerQ3 η₁ η₂) a a' 1 η₁ = a' η₁ := by
    unfold stepProfile; rw [if_pos ⟨0, by simp [ownerQ3], by decide⟩]
  have h2 : stepProfile (ownerQ3 η₁ η₂) a a' 2 η₁ = a' η₁ := by
    unfold stepProfile; rw [if_pos ⟨0, by simp [ownerQ3], by decide⟩]
  unfold touchFactor; rw [h1, h2, sub_self, abs_zero]; norm_num
example (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (a a' : Polymer N → ℝ)
    (ht1 : typedTouchesSupport (N := N) η₁ (r 1))
    (hb : ∀ η i, ownerQ3 η₁ η₂ η = some i → |touchFactor R a η - touchFactor R a' η| ≤ ![(1/2 : ℝ), 1/10] i) :
    |touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' (1 : Fin 2).val) η₁
      - touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' ((1 : Fin 2).val + 1)) η₁| ≤ ![(1/2 : ℝ), 1/10] 1 :=
  step_bound R r (ownerQ3 η₁ η₂) a a' ![(1/2 : ℝ), 1/10] (fun i => by fin_cases i <;> norm_num) hb 1 η₁ ht1
-- (d) the step-0 obligation for η₁ uses the owner bound δ 0 = 1/2 (the coordinate moves at step 0): own check
example (R : Set (Link N)) (a a' : Polymer N → ℝ) (hb : |touchFactor R a η₁ - touchFactor R a' η₁| ≤ 1/2) :
    |touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' 0) η₁ - touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' 1) η₁| ≤ 1/2 := by
  have h0 : stepProfile (ownerQ3 η₁ η₂) a a' 0 η₁ = a η₁ := by unfold stepProfile; rw [if_neg (not_moved_zero _ _)]
  have h1 : stepProfile (ownerQ3 η₁ η₂) a a' 1 η₁ = a' η₁ := by
    unfold stepProfile; rw [if_pos ⟨0, by simp [ownerQ3], by decide⟩]
  unfold touchFactor at *; rw [h0, h1]; exact hb
-- (e) step_same at step 1: a polymer avoiding r 1 keeps its factor between p_1 and p_2, whatever its owner (η₁ included
--     if it avoided r 1; here a generic η with owner 0 owned coordinate already moved) — candidate lemma, retyped
example (R : Set (Link N)) (r : Fin 2 → Set (Link N)) (a a' : Polymer N → ℝ)
    (htouch : ∀ η i, ownerQ3 η₁ η₂ η = some i → typedTouchesSupport (N := N) η (r i)) (η : Polymer N)
    (h : ¬ typedTouchesSupport (N := N) η (r 1)) :
    touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' (1 : Fin 2).val) η
      = touchFactor R (stepProfile (ownerQ3 η₁ η₂) a a' ((1 : Fin 2).val + 1)) η :=
  step_same R r (ownerQ3 η₁ η₂) a a' htouch 1 η h
end
end LatticeGauge
