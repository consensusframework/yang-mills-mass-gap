import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q2: EMPTY FAMILY AND ZERO AMPLITUDES.
-- (a) m = 0 under the cover, NO analytic hypothesis: raw profiles DIFFERENT off R (a′ = −3 there), effective factors equal,
--     so the cover (with no index) holds vacuously ⇒ exact equality. The empty cover forces equal EFFECTIVE factors only.
example (β : ℝ) (χ : G → ℝ) (f : Config N G → ℝ) (s R : Set (Link N)) (a : Polymer N → ℝ) :
    profileExpectation μm β χ f s R a
      = profileExpectation μm β χ f s R (fun η => if typedTouchesSupport (N := N) η R then a η else -3) :=
  profileExpectation_eq_of_cover_empty_family μm β χ f s R (r := fun i : Fin 0 => i.elim0) (δ := fun i : Fin 0 => i.elim0)
    (fun η hne => absurd (by unfold touchFactor; split_ifs with h <;> simp [h]) hne)
-- (a′) the raw profiles of (a) do differ off R (content of "effective, not raw"): for η avoiding R with a η ≠ −3
example (R : Set (Link N)) (a : Polymer N → ℝ) (η : Polymer N) (hR : ¬ typedTouchesSupport (N := N) η R) (ha : a η ≠ -3) :
    a η ≠ (fun η => if typedTouchesSupport (N := N) η R then a η else -3) η := by
  simp [hR]; exact ha
-- (b) the ANALYTIC capstone with m = 0: the cost B is the empty sum, the bound is 0, hence equality by effective application
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (heff : ∀ η, touchFactor R a η = touchFactor R a' η) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have h := abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall (s := s) R mf hCf
    (m := 0) (r := fun i => i.elim0) (n := fun i => i.elim0) (δ := fun i => i.elim0) (fun i => Fin.elim0 i) (fun i => Fin.elim0 i)
    h0 h1 h0' h1' (fun η hne => absurd (heff η) hne)
  simp only [Finset.univ_eq_empty, Finset.sum_empty, mul_zero] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (c) δ ≡ 0 with m regions, by EFFECTIVE application: the cover with zero amplitudes gives bound 0 ⇒ equality
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {m : ℕ} {r : Fin m → Set (Link N)} {n : Fin m → ℕ}
    (hsep : ∀ i, WalkBarrierSeparated (N := N) s (r i) (n i)) {a a' : Polymer N → ℝ}
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ (fun _ => (0:ℝ)) i) :
    profileExpectation μm β χ f s R a = profileExpectation μm β χ f s R a' := by
  have h := abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf
    (δ := fun _ => 0) (fun _ => le_rfl) hsep h0 h1 h0' h1' hcover
  simp only [zero_mul, Finset.sum_const_zero, mul_zero] at h
  exact sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm h (abs_nonneg _)))
-- (c′) and, independently of the capstone: a zero-amplitude cover already forces equal effective factors (own)
example (R : Set (Link N)) {m : ℕ} {r : Fin m → Set (Link N)} {a a' : Polymer N → ℝ}
    (hcover : ∀ η, touchFactor R a η ≠ touchFactor R a' η →
      ∃ i : Fin m, typedTouchesSupport (N := N) η (r i) ∧ |touchFactor R a η - touchFactor R a' η| ≤ (fun _ => (0:ℝ)) i) :
    ∀ η, touchFactor R a η = touchFactor R a' η := by
  intro η; by_contra hne
  obtain ⟨_, _, hb⟩ := hcover η hne
  exact hne (sub_eq_zero.mp (abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))))
end LatticeGauge
