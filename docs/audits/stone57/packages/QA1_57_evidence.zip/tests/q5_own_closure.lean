import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q5: OWN CLOSURE. Two regions r 0, r 1 with an explicit owner; the intermediate profile p₁ is DEFINED HERE (not the
-- candidate's `stepProfile`), the Stone 56 hypotheses at both steps are proved HERE, the Stone 56 two-term estimate is
-- applied at each step, the endpoint identity is by effective factors, and the triangle inequality closes. The candidate's
-- capstones, `abs_profileExpectation_sub_le_of_owner`, `step_same`, `step_bound`, `stepProfile` are NOT used.
theorem Q5_two_steps {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf)
    (r₀ r₁ : Set (Link N)) (n₀ n₁ : ℕ) (δ₀ δ₁ : ℝ) (hδ₀ : 0 ≤ δ₀) (hδ₁ : 0 ≤ δ₁)
    (hsep₀ : WalkBarrierSeparated (N := N) s r₀ n₀) (hsep₁ : WalkBarrierSeparated (N := N) s r₁ n₁)
    {a a' : Polymer N → ℝ} (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (owner : Polymer N → Option (Fin 2))
    (hnone : ∀ η, owner η = none → touchFactor R a η = touchFactor R a' η)
    (htouch₀ : ∀ η, owner η = some 0 → typedTouchesSupport (N := N) η r₀)
    (htouch₁ : ∀ η, owner η = some 1 → typedTouchesSupport (N := N) η r₁)
    (hb₀ : ∀ η, owner η = some 0 → |touchFactor R a η - touchFactor R a' η| ≤ δ₀)
    (hb₁ : ∀ η, owner η = some 1 → |touchFactor R a η - touchFactor R a' η| ≤ δ₁) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ δ₀ * Cf * Real.exp (-(n₀ : ℝ) / 2)
          * (Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
              + Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113)))
        + δ₁ * Cf * Real.exp (-(n₁ : ℝ) / 2)
          * (Real.exp (3 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))
              + Real.exp (2 * ((supportLinkFinset (N := N) s).card : ℝ) * (2/113))) := by
  -- the intermediate profile: a′ on the coordinates owned by 0, a elsewhere; the final profile: a′ where owned, a elsewhere
  set p₁ : Polymer N → ℝ := fun η => if owner η = some 0 then a' η else a η with hp₁
  set p₂ : Polymer N → ℝ := fun η => if owner η = none then a η else a' η with hp₂
  have hp₁0 : ∀ η, 0 ≤ p₁ η := fun η => by simp only [hp₁]; split_ifs; exact h0' η; exact h0 η
  have hp₁1 : ∀ η, p₁ η ≤ 1 := fun η => by simp only [hp₁]; split_ifs; exact h1' η; exact h1 η
  have hp₂0 : ∀ η, 0 ≤ p₂ η := fun η => by simp only [hp₂]; split_ifs; exact h0 η; exact h0' η
  have hp₂1 : ∀ η, p₂ η ≤ 1 := fun η => by simp only [hp₂]; split_ifs; exact h1 η; exact h1' η
  have tf₁ : ∀ η, touchFactor R p₁ η = if owner η = some 0 then touchFactor R a' η else touchFactor R a η := by
    intro η; unfold touchFactor; simp only [hp₁]; split_ifs <;> rfl
  have tf₂ : ∀ η, touchFactor R p₂ η = if owner η = none then touchFactor R a η else touchFactor R a' η := by
    intro η; unfold touchFactor; simp only [hp₂]; split_ifs <;> rfl
  -- step 0 : a → p₁ with region r₀
  have same₀ : ∀ η, ¬ typedTouchesSupport (N := N) η r₀ → touchFactor R a η = touchFactor R p₁ η := by
    intro η hη; rw [tf₁]; split_ifs with h
    · exact absurd (htouch₀ η h) hη
    · rfl
  have bound₀ : ∀ η, typedTouchesSupport (N := N) η r₀ → |touchFactor R a η - touchFactor R p₁ η| ≤ δ₀ := by
    intro η _; rw [tf₁]; split_ifs with h
    · exact hb₀ η h
    · rw [sub_self, abs_zero]; exact hδ₀
  -- step 1 : p₁ → p₂ with region r₁ (a coordinate owned by 0 does not move, even if it touches r₁)
  have same₁ : ∀ η, ¬ typedTouchesSupport (N := N) η r₁ → touchFactor R p₁ η = touchFactor R p₂ η := by
    intro η hη; rw [tf₁, tf₂]
    rcases ho : owner η with _ | i
    · simp
    · fin_cases i
      · simp
      · exact absurd (htouch₁ η ho) hη
  have bound₁ : ∀ η, typedTouchesSupport (N := N) η r₁ → |touchFactor R p₁ η - touchFactor R p₂ η| ≤ δ₁ := by
    intro η _; rw [tf₁, tf₂]
    rcases ho : owner η with _ | i
    · simp [hδ₁]
    · fin_cases i
      · simp [hδ₁]
      · simpa using hb₁ η ho
  -- endpoint: p₂ has the effective factors of a′
  have hend : profileExpectation μm β χ f s R p₂ = profileExpectation μm β χ f s R a' := by
    apply profileExpectation_eq_of_touchFactor_eq μm β χ f s R
    intro η; rw [tf₂]; split_ifs with h
    · exact hnone η h
    · rfl
  -- the two Stone 56 two-term estimates
  have e₀ := abs_profileExpectation_sub_profileExpectation_le_two_terms_localized μm hβ mχ hχabs hsmall R mf hCf hsep₀ hδ₀
    h0 h1 hp₁0 hp₁1 same₀ bound₀
  have e₁ := abs_profileExpectation_sub_profileExpectation_le_two_terms_localized μm hβ mχ hχabs hsmall R mf hCf hsep₁ hδ₁
    hp₁0 hp₁1 hp₂0 hp₂1 same₁ bound₁
  -- triangle inequality
  rw [← hend]
  calc |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R p₂|
      ≤ |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R p₁|
        + |profileExpectation μm β χ f s R p₁ - profileExpectation μm β χ f s R p₂| := abs_sub_le _ _ _
    _ ≤ _ := add_le_add e₀ e₁
#print axioms Q5_two_steps
-- (b) the candidate's two-term multiregion statement for m = 2 is EXACTLY the sum above (reorganization check, own):
--     Cf·(E₆+E₄)·(δ₀e^{−n₀/2} + δ₁e^{−n₁/2}) = the right-hand side of Q5_two_steps
example (Cf E₆ E₄ δ₀ δ₁ x₀ x₁ : ℝ) :
    Cf * (E₆ + E₄) * (δ₀ * x₀ + δ₁ * x₁) = δ₀ * Cf * x₀ * (E₆ + E₄) + δ₁ * Cf * x₁ * (E₆ + E₄) := by ring
-- (c) general telescoping, own proof by induction (checks the candidate's `abs_telescope` statement independently)
theorem Q5_telescope (g : ℕ → ℝ) : ∀ k, |g 0 - g k| ≤ ∑ j ∈ Finset.range k, |g j - g (j + 1)| := by
  intro k; induction k with
  | zero => simp
  | succ k ih =>
    rw [Finset.sum_range_succ]
    have := abs_sub_le (g 0) (g k) (g (k + 1))
    linarith
#print axioms Q5_telescope
-- (d) the sum over `Finset.range m` of a function of ℕ equals the sum over `Fin m` (the index change used in the composition)
example (m : ℕ) (h : ℕ → ℝ) : ∑ j ∈ Finset.range m, h j = ∑ i : Fin m, h i.val := Finset.sum_range (fun j => h j)
end LatticeGauge
