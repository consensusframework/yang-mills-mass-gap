import Mathlib
import LatticeGauge.ActivityProfileDampingMultiRegion
open MeasureTheory
open scoped Classical
namespace LatticeGauge
variable {N : ℕ} [NeZero N] [Fintype (Site N)]
variable {G : Type*} [Group G] [MeasurableSpace G] [MeasurableMul₂ G] [MeasurableInv G]
variable (μm : Measure G) [SigmaFinite μm] [IsProbabilityMeasure μm]
-- Q7: LIMITS OF THE IMPROVEMENT. (a) a family with the same region repeated twice (same n, same δ) costs exactly twice the
--     single-region cost: the bound is NOT invariant under duplicating the family (scalar identity)
example (δ : ℝ) (n : ℕ) :
    (∑ i : Fin 2, (fun _ => δ) i * Real.exp (-(((fun _ => n) i : ℕ) : ℝ) / 2)) = 2 * (δ * Real.exp (-(n : ℝ) / 2)) := by
  simp only [Fin.sum_univ_two]; ring
-- (b) both bounds are valid for the duplicated family (the capstone accepts it; the cover is satisfied through index 0):
--     B_dup = 2·δ·e^{−n/2}, i.e. the multiregion bound is twice the Stone 56 bound here — no universal improvement
example {β : ℝ} (hβ : 0 ≤ β) {χ : G → ℝ} (mχ : Measurable χ) (hχabs : ∀ g : G, |χ g| ≤ 1)
    (hsmall : β ≤ (1 : ℝ) / 40000) {s r : Set (Link N)} (R : Set (Link N)) {f : Config N G → ℝ} (mf : Measurable f)
    {Cf : ℝ} (hCf : ∀ U, |f U| ≤ Cf) {n : ℕ} (hsep : WalkBarrierSeparated (N := N) s r n)
    {a a' : Polymer N → ℝ} {δ : ℝ} (hδ0 : 0 ≤ δ)
    (h0 : ∀ η, 0 ≤ a η) (h1 : ∀ η, a η ≤ 1) (h0' : ∀ η, 0 ≤ a' η) (h1' : ∀ η, a' η ≤ 1)
    (hsame : ∀ η, ¬ typedTouchesSupport (N := N) η r → touchFactor R a η = touchFactor R a' η)
    (hδ : ∀ η, typedTouchesSupport (N := N) η r → |touchFactor R a η - touchFactor R a' η| ≤ δ) :
    |profileExpectation μm β χ f s R a - profileExpectation μm β χ f s R a'|
      ≤ (2 * Cf) * Real.exp (6 * ((supportLinkFinset (N := N) s).card : ℝ) / 113) * (2 * (δ * Real.exp (-(n : ℝ) / 2))) := by
  have h := abs_profileExpectation_sub_profileExpectation_le_multiregion μm hβ mχ hχabs hsmall R mf hCf
    (m := 2) (r := fun _ => r) (n := fun _ => n) (δ := fun _ => δ) (fun _ => hδ0) (fun _ => hsep) h0 h1 h0' h1'
    (fun η hne => ⟨0, not_not.mp (fun hnt => hne (hsame η hnt)), hδ η (not_not.mp (fun hnt => hne (hsame η hnt)))⟩)
  simp only [Fin.sum_univ_two] at h
  calc _ ≤ _ := h
    _ = _ := by ring
-- (c) assigning each coordinate once (the owner) is not minimizing the global budget: with two overlapping regions of
--     amplitudes δ₀ ≤ δ₁ and the same separation, the budget charged is δ₀+δ₁ times e^{−n/2} whatever the owner — the
--     owner choice changes which obligation pays, not the sum B (scalar statement of the content)
example (δ₀ δ₁ : ℝ) (n : ℕ) :
    (∑ i : Fin 2, ![δ₀, δ₁] i * Real.exp (-(((fun _ => n) i : ℕ) : ℝ) / 2)) = (δ₀ + δ₁) * Real.exp (-(n : ℝ) / 2) := by
  simp only [Fin.sum_univ_two]; simp; ring
end LatticeGauge
