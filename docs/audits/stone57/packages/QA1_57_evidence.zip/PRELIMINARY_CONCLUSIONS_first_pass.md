# 57 QA1 — Conclusões preliminares (primeira passagem, ANTES de abrir testes, matrizes e logs do construtor)

Registrado em 2026-10-09 (UTC). Bancada nova (o container anterior foi perdido): elan 4.2.4 + toolchain v4.15.0 instalados, clone próprio (push desabilitado), dependências pelo cache comunitário do Mathlib (`lake exe cache get`, 9/9 revisões = manifesto), nenhum artefato de build do projeto antes do `lake build` integral.

**Exposição prévia:** auditei 52-A0…52-E, 53, 54, 55 e 56 (com errata C1); arquitetura (Can/Astra) na fita; `RELATORIO_57-L.md` lido antes para identificar o alvo. Não é auditoria cega. Do ZIP do construtor usei até aqui: bundle, manifesto interno, fonte avulsa, diff (custódia). `T57L_*`, `W8x_*`, `buildL.log`, `clean_build*.log`, `warnings_comparison.txt`, `compare_warnings.py` e as duas matrizes: NÃO lidos.

## Custódia
- ZIP `934a898d…` ✅ (359.578 B); 20 entradas, 0 diretórios, caminhos seguros, sem duplicatas, CRC OK; manifesto 19/19 sem auto-inclusão. Avulsos (módulo 9a66665a…, bundle 2d02b78a…, diff 5ed714dd…, matrizes 8c28f460…/78c65139…) com bytes e hashes = fita.
- `origin/main` = `zenodo-v56` = base `95091fdd…` (fetch de hoje); root `8b723878…`, Phase3 `f387f26d…` ✅. Candidato `c936d461…`, parent único = base, root `47e84319…`, Phase3 `cc1bfb26…`, blob módulo `818048c4…` (527 linhas, modo 100644), lakefile `11de6e17…` (antes `ae8438d4…`), diff A+M +528/−1 (só o glob novo), `git diff` = arquivo diff do construtor (SHA igual); 117 módulos anteriores, manifesto (c376bbe9…), pins, workflows, docs, auditorias, licenças idênticos à base; bundle verify OK.
- Proveniência: `Claude <noreply@anthropic.com>`, `gpgsig` presente (não verificável aqui), trailers `Co-Authored-By: Claude Fable 5.1` / `Claude-Session` — precedente 53–56; não é autenticação independente.

## Reconstrução
- `lake build` integral, único, desacoplado (`setsid nohup`), sem `.lake/build` prévio: início 12:55:31Z, fim 13:08:45Z, exit 0 (794 s), **118 Built / 0 Replayed** no projeto; dependências 0 Built / 0 Replayed (oleans do cache já presentes; nenhum diagnóstico de dependências emitido); 0 erros; 114 warnings todos de `LatticeGauge/`, **0 no módulo novo**; 0 sorryAx; **291 certidões (269 + 22), 291/291 exatamente `[propext, Classical.choice, Quot.sound]`, 74 multilinha, nome com apóstrofo aceito**; 118 `.olean`, 0 anteriores ao início; manifesto pré = pós; árvore limpa. Log SHA `5bd23aab…`.
- Baseline: `docs/audits/stone56/packages/QA1_56_evidence.zip` da base (SHA `53399f1a…` ✅; manifesto 45/45 sem auto-inclusão) → `build_full_clean.log` (SHA `38ca3d81…` ✅, meu log da 56-QA1). Blocos integrais multilinha (normalização só do prefixo `./`): **114 = 114, multiconjuntos iguais**, cabeçalhos iguais, 113 pares arquivo:linha; 0 dependências em ambos.
- Q0: 22/22 certidões próprias (19 teoremas + 3 defs) exatas; `#check` das quatro interfaces, do lema com `owner`, dos lemas de passo e das três interfaces da 56 consumidas.
- Higiene (código): 0 sorry/admit/axiom/native_decide/unsafe/opaque/set_option/maxHeartbeats/partial/decide/Disjoint/DependsOnlyOn; "admitted" só na docstring l. 370 (inglês); `card R` só no cabeçalho (negado). Imports: `Mathlib`, `LatticeGauge.ActivityProfileDampingLocality`. Consumidos da 56: `…_le_two_terms_localized` (1 uso, l. 285 — dependência intencional), `profileExpectation_eq_of_touchFactor_eq` (2), `nonneg_of_abs_le_of_config` (1); capstone 56 (`…_le_local_exp_decay_localized`) não usada. `Classical.choose` ×3 (coverOwner e specs).
- Contagens (método publicado, nove alternativas, sobre objetos Git): módulos 117→118; linhas 37.994→38.521; declaração 1.780→1.802 (+22 = 19 theorem + 1 def + 2 noncomputable def); `#print axioms` 269→291.

## Matemática (rederivação própria, §4 da fita)
1. Substituição de coordenadas: `p_k η = a′ η` sse `∃ i, owner η = some i ∧ i < k`; `p_0 = a` (sem i < 0); `[0,1]` por seleção; `touchFactor R p_k = if moved then b′ else b` por `split_ifs <;> rfl` — conferido à mão e em Q3/Q4.
2. Passo i: fora de `r i`, moved_i ⇒ moved_{i+1}; não-moved_i ∧ moved_{i+1} ⇒ owner = some i (ω por `Fin.ext` + omega) ⇒ toca `r i` (contradição via `howner_touch`); senão ambos `b`. Em `r i`: três casos, diferença 0 (≤ δ i por `hδ0`) ou `howner_bound`. Um polímero que toca várias regiões muda só no passo do dono — Q3 com δ 1 = 1/10 < 1/2 = |Δ| em η₁ (toca r 0 e r 1, dono 0).
3. Extremo: moved_m ⟺ owner = some i (i.isLt); `none` ⇒ `howner_none`. Igualdade de fatores efetivos ⇒ `F_R(p_m) = F_R(a′)` pela 56; Q4b mostra `p_m η ≠ a′ η` com fatores iguais (η evita R).
4. Composição: Q5 fecha dois passos com perfil intermediário PRÓPRIO, hipóteses `hsame`/`hδ` próprias por passo, dois usos da estimativa de dois termos da 56, igualdade do extremo e `abs_sub_le`; telescopagem geral reprovada por indução (Q5_telescope) e `Finset.sum_range` conferido; reorganização `Cf(E6+E4)·Σ` = soma dos custos (ring).
5. Dono por `hcover`: `if h : b ≠ b′ then some (choose (hcover η h)) else none`; `none` ⇒ ¬¬ igualdade; `some i` ⇒ `choose_spec`. Sem fortalecer a cobertura; capstones públicas sem `owner`.
6. Constante: `0 ≤ Cf` derivado (l. 429), `B ≥ 0`, `e^{4D/113} ≤ e^{6D/113}` por `nlinarith` com `D ≥ 0` (inclui D = 0: igualdade; Cf = 0: cota 0, Q6b/c″). Sinais: `mul_le_mul_of_nonneg_right _ hB`, `…_left _ hCf0`.
- Ausências conferidas nos tipos elaborados (Q0 `#check`): sem `owner`, `m > 0`, disjunção, `r i ⊆ R`, separação s/R, fundo unitário, `δ i ≤ 1`, `DependsOnlyOn`, sinal; nada dividido; m só por `B`.

## Testes próprios
Q0–Q7 exit 0; Q8x exit 1 exatamente na obrigação `howner_none` (goal `False`) com `owner ≡ none` e fatores que mudam — falha de aplicação/obrigação. Q1: aplicação efetiva da interface de uma região (LHS incluído, `exact`), derivação própria com m = 1 reduzindo `Fin 1` no RHS, tipos defeq nas duas direções com a capstone 56. Q2: m = 0 exato com perfis brutos diferentes fora de R; capstone analítica com m = 0 (B = 0) e δ ≡ 0 por aplicação efetiva; cobertura nula ⇒ fatores iguais (própria). Q6: δ = 7 com Cf geral; Cf = 0 separado; comparação escalar exata B₂ = 1/2 + e^{−2}/2 < 1 = B₁, melhora estrita da cota completa só com Cf > 0; sem geometria. Q7: família duplicada custa 2×; dono não minimiza B. Deslizes meus (attempt logs preservados): contraposição sem `not_not`, `s` implícito com m = 0, `Real.exp_lt_one` inexistente, `if` sob lambda não dividido por `split_ifs`.
Warnings nos meus testes: 34 (Q1 28 — binders não usados nos dois `example` de comparação de tipos; Q4 4; Q6 2) — separados dos 114 do projeto e dos 0 do módulo novo.

## Reservas preliminares
Nenhum defeito matemático, de execução ou de custódia. Documental: nada encontrado até aqui (docstrings coerentes com as hipóteses efetivas; "lado direito" correto na interface de uma região).

Veredito preliminar: 57 QA1 PASS NO ESCOPO.
