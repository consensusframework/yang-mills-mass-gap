#!/usr/bin/env python3
"""57-QA1: full multiline warning-block comparison (candidate clean build vs validated baseline).
Block = 'warning: <path>:l:c: msg' header + continuation lines until the next build event line
(✔ ⚠ ✖ ℹ info: warning: error: Build trace: [N/M]). Normalization: only the './' prefix repeats before the path.
Project (LatticeGauge/) vs dependency blocks are separated; multisets compared (order ignored)."""
import re, sys, collections
START=re.compile(r'^(✔|⚠|✖|ℹ|info:|warning:|error:|Build |trace:|\S? ?\[\d+/\d+\])')
def blocks(path):
    lines=open(path,encoding='utf-8',errors='replace').read().split('\n')
    out=[];cur=None
    for l in lines:
        if l.startswith('warning:'):
            if cur: out.append(cur)
            cur=[l]
        elif START.match(l) or (l.strip()=='' and cur is None):
            if cur: out.append(cur); cur=None
        elif cur is not None: cur.append(l)
    if cur: out.append(cur)
    res=[]
    for b in out:
        h=re.sub(r'^warning: (\./)+','warning: ',b[0]); res.append('\n'.join([h]+b[1:]).rstrip())
    return res
def split(bl):
    return [b for b in bl if b.startswith('warning: LatticeGauge/')],[b for b in bl if not b.startswith('warning: LatticeGauge/')]
base,cand=sys.argv[1],sys.argv[2]
bp,bd=split(blocks(base)); cp,cd=split(blocks(cand))
print(f"baseline : project {len(bp)}  dependency {len(bd)}")
print(f"candidate: project {len(cp)}  dependency {len(cd)}")
B,C=collections.Counter(bp),collections.Counter(cp)
print("project full blocks, multiset equal:",B==C)
for k in (B-C): print("ONLY IN BASELINE:\n"+k+"\n")
for k in (C-B): print("ONLY IN CANDIDATE:\n"+k+"\n")
hb=collections.Counter(b.split('\n')[0] for b in bp); hc=collections.Counter(b.split('\n')[0] for b in cp)
pairs=lambda h:{re.match(r'warning: ([^:]+:\d+)',x).group(1) for x in h}
print("project headers multiset equal:",hb==hc,"| distinct file:line pairs:",len(pairs(hb)),len(pairs(hc)))
print("candidate warnings in ActivityProfileDampingMultiRegion:",sum('ActivityProfileDampingMultiRegion' in b.split('\n')[0] for b in cp))
print("dependency blocks multiset equal:",collections.Counter(bd)==collections.Counter(cd))
