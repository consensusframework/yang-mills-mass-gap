# Índice — evidências de execução Manus 57

Este ZIP contém somente insumos, fontes, testes, controlador e logs da execução Lean complementar da Pedra 57. O relatório técnico `RELATORIO_57-MANUS-EXEC.md` é entregue separadamente e deliberadamente não está neste ZIP.

## Estrutura

| Caminho | Conteúdo |
|---|---|
| `inputs/` | fita recebida, parecer Kimi preservado e ZIP QA1 recebido |
| `source/Phase3/` | módulo compilado, manifesto, lakefile e toolchain efetivamente usados |
| `tests/` | cinco fontes QA1 reexecutadas (`q0`, `q3`, `q4`, `q5`, `q8x`) |
| `runtime_checks/` | arquivo Manus de `#check` das duas interfaces capstone |
| `controller/` | script local que registrou a execução; não modifica fontes rastreadas |
| `raw_logs/` | logs integrais de instalação, custódia, pins, cache, compilação, testes, integridade e métricas |
| `SHA256SUMS_57-MANUS-EXEC.txt` | hashes de todos os arquivos deste pacote, excluindo o próprio manifesto |

## Verificação

Após extrair, execute:

```bash
sha256sum -c SHA256SUMS_57-MANUS-EXEC.txt
```

A fonte de verdade para o veredito e os limites é o relatório entregue fora do ZIP.
