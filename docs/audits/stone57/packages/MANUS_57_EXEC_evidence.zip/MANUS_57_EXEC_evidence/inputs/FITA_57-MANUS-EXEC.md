# FITA 57-MANUS-EXEC — execução Lean complementar

Destinatário: Manus, em uma bancada com terminal. Coordenação: Jucelha Carvalho.

## Objetivo e atribuição

Execute Lean de verdade sobre a Pedra 57 integrada e registre evidências verificáveis. A QA1 já reproduziu os 118 módulos e os CIs 505/506 passaram. Esta fita acrescenta uma execução em outra bancada; não substitui a QA1, não exige outra auditoria global e não transforma o parecer de leitura do Kimi em execução feita por ele.

Ju informa que o Kimi concluiu sua revisão sem executar Lean. O parecer ainda não foi recebido pela instância que redige esta fita: não se presume seu veredito nem a existência de achados específicos. Leia o parecer que Ju anexar e associe a ele eventuais testes adicionais. Se não vier, execute o núcleo abaixo e registre a ausência.

**Primeiro confirme a capacidade do ambiente.** É necessário terminal capaz de executar Lean 4.15.0 e acesso às dependências fixadas. Se isso não estiver disponível, entregue BLOQUEADO POR AMBIENTE com o comando, erro e impedimento concreto. Não substitua execução por leitura de logs de terceiros nem anuncie PASS.

## 1. Alvo imutável

| Item | Valor |
| --- | --- |
| Repositório | https://github.com/consensusframework/yang-mills-mass-gap |
| Merge a executar | `b66c255c83bba02dc8d53158279296bbf7ea005c` |
| Candidato científico, mesma árvore | `c936d4617f3e6f35ea1431c2fa9496b235940f5a` |
| Base v56 | `95091fdd07398a7b42901829ad61e4e2c26d5aaa` |
| Root tree do alvo | `47e843190b38159fcc408340313bda77de0f46e7` |
| Phase3 tree do alvo | `cc1bfb261610266372745473fb54ad86f1077fae` |
| Módulo | `Phase3/LatticeGauge/ActivityProfileDampingMultiRegion.lean` |
| SHA-256 do módulo, 28102 bytes | `9a66665a37135ebf55bf74f0c7abdf803fd2c7790c2a78e6d2178b209f53cbec` |
| SHA-256 de Phase3/lake-manifest.json | `c376bbe93b56fd85fde0a790889f721c578e2a710c300de77b9de8a0c8dc1227` |
| Toolchain | `leanprover/lean4:v4.15.0` |
| Mathlib | `9837ca9d65d9de6fad1ef4381750ca688774e608` |

[PR #39](https://github.com/consensusframework/yang-mills-mass-gap/pull/39) · [Fonte fixado](https://github.com/consensusframework/yang-mills-mass-gap/blob/b66c255c83bba02dc8d53158279296bbf7ea005c/Phase3/LatticeGauge/ActivityProfileDampingMultiRegion.lean) · [Workflow fixado](https://github.com/consensusframework/yang-mills-mass-gap/blob/b66c255c83bba02dc8d53158279296bbf7ea005c/.github/workflows/lean-ci.yml).

Trabalhe em clone descartável, com checkout detached no SHA completo. Confira HEAD e as duas árvores. Se main tiver avançado, continue no SHA desta fita. Leia as instruções locais aplicáveis; esta fita não autoriza push nem publicação.

## 2. Materiais

Ju deve enviar esta fita, o parecer Kimi e `QA1_57_evidence.zip`.

O pacote QA1 tem **60267 bytes**, SHA-256
`e495b4760e9e174a1da37c5583c0cd12fc1f0c8431548826f073a209b0b790ea`.
Confira o arquivo e o manifesto interno `SHA256SUMS_57-QA1.txt`: 45/45 entradas, sem auto-inclusão; ZIP com 48 entradas, sendo 46 arquivos e 2 diretórios. Extraia em pasta separada do checkout, verificando os caminhos.

O parecer Kimi não tem hash fixado nesta fita. Registre o nome e o SHA-256 efetivamente recebidos, sem inventar um valor anterior. Não precisa do bundle do construtor se obtiver o clone público no SHA correto. Não precisa de token de escrita.

## 3. Preparação e compilação

Registre comandos e saídas, inclusive erros e exit codes. Registre sistema/arquitetura, versões de Lean e Lake, horário de início e término, além do modelo executor quando identificável; “Manus” identifica a plataforma, não necessariamente o modelo.

Dentro de `Phase3/`:

1. Confira o toolchain e o hash do manifesto antes de resolver dependências.
2. Materialize as nove dependências pelo manifesto versionado com `lake env true`, seguindo o workflow fixado. **Não use lake update** e não troque pins para fazer compilar.
3. Confira o HEAD de cada pacote contra o respectivo `rev` do manifesto.
4. Obtenha o cache compatível da Mathlib com `lake exe cache get`. Registre o uso desse cache. Não importe oleans do projeto LatticeGauge provenientes da bancada do construtor ou da QA1.
5. Em checkout sem artefatos prévios do projeto, execute:

```bash
lake build LatticeGauge.ActivityProfileDampingMultiRegion
```

Esse alvo existe no lakefile conferido. Instale o toolchain oficial se necessário e permitido no ambiente; o workflow do próprio SHA é a referência. Se download, instalação ou cache forem bloqueados, registre a limitação sem contornar controles de acesso. Não consuma a sessão recompilando toda a Mathlib como alternativa automática.

Capture o exit code real de Lean/Lake, não apenas o do tee. Use pipefail quando fizer pipelines. Preserve logs de tentativas. Se o processo for interrompido, registre que não terminou; uma retomada incremental não deve ser chamada de rebuild integral único.

**Esta é compilação dirigida**, com suas dependências de importação. Conte os módulos Built/Replayed que realmente aparecerem, separando projeto e dependências. Não exija nem anuncie os números globais 118/291/294 para esse comando: eles pertencem a escopos diferentes.

O módulo tem 527 linhas, 19 teoremas, 3 definições e 22 comandos de certificado. Esperado: exit 0, zero avisos no módulo novo e todos os seus 22 certificados exatamente com os axiomas padrão. Avisos herdados de dependências/imports devem ser registrados separadamente.

## 4. Certificados e testes focados

Reexecute os arquivos abaixo, preservando os originais byte a byte, por comandos da forma `lake env lean /caminho/absoluto/do/teste.lean`, a partir de `Phase3/`. As provas são da QA1; esta etapa é **reexecução pelo Manus**, não autoria ou rederivação matemática própria.

| Fonte no ZIP QA1 | Finalidade | Resultado registrado na QA1 |
| --- | --- | --- |
| tests/q0_certificates.lean | 22 certificados do módulo e interfaces | exit 0; 22 certificados padrão; zero avisos |
| tests/q3_overlap.lean | seleção de proprietário e sobreposição | exit 0; zero avisos |
| tests/q4_background.lean | fundo comum, valores ignorados e fator zero | exit 0; 4 avisos |
| tests/q5_own_closure.lean | fechamento em dois passos, originalmente derivado pela QA1 usando a 56 | exit 0; 2 certificados próprios de teste; zero avisos |
| tests/q8x_missing_cover_EXPECT_FAIL.lean | aplicação sem atribuição/cobertura suficiente | exit 1; obrigação False aberta em howner_none |

Esses resultados são referências, não respostas a copiar. Informe o que sua bancada produziu. A falha do negativo precisa ser a obrigação esperada; erro de import, timeout ou incompatibilidade de versão não conta como sucesso do teste negativo. Essa falha de aplicação também não prova falsidade do capstone.

Confirme as assinaturas reais dos dois resultados:

- `LatticeGauge.abs_profileExpectation_sub_profileExpectation_le_multiregion_two_terms`;
- `LatticeGauge.abs_profileExpectation_sub_profileExpectation_le_multiregion`.

Use #check e nomes existentes no fonte; não invente APIs. Confira hcover na assinatura e ausência de owner como argumento público. Não substitua aplicação de teorema por uma conta apenas do lado direito.

Axiomas esperados: `[propext, Classical.choice, Quot.sound]`, sem sorryAx. Leia listas que atravessam linhas e nomes com apóstrofos. Não conte comandos ecoados como resultados; se reimprimir certificados, diferencie saídas repetidas de nomes distintos.

Se o parecer Kimi indicar uma questão específica que possa ser testada, escreva um teste mínimo separado e identifique qual achado ele examina. Preserve tentativas e explique o resultado. Não faça uma nova campanha geral de testes: encerre quando a compilação, os certificados e os casos acima estiverem comprovados.

## 5. Interpretação que deve permanecer correta

O resultado compõe a estimativa publicada da 56. Para fatores efetivos
b(η) = touchFactor R a η e b′(η) = touchFactor R a′ η, a hipótese exige:

```text
∀ η, b(η) ≠ b′(η) →
  ∃ i : Fin m, typedTouchesSupport η (r i)
    ∧ |b(η) − b′(η)| ≤ δ i.
```

O mesmo índice deve localizar e pagar a alteração. Um owner interno escolhe esse índice; cada coordenada muda apenas no passo de seu proprietário, mesmo tocando outras regiões. R permanece no funcional e nos fatores.

A cota final é:

```text
|F_R(a) − F_R(a′)|
≤ Cf · [exp(6D_s/113) + exp(4D_s/113)]
     · ∑ i, δ i · exp(−n i/2)
≤ (2Cf) · exp(6D_s/113)
     · ∑ i, δ i · exp(−n i/2).
```

Preserve as hipóteses de perfis em [0,1], δ i ≥ 0, separação s/(r i), regime pequeno de β e as demais condições da assinatura. Não acrescente disjunção, r i ⊆ R, separação s/R, fundo unitário ou δ i ≤ 1. O capstone da 56 é utilizado deliberadamente; a recuperação com uma região é compatibilidade, não prova independente da 56.

Precisões documentais já registradas no PR:

- **D1/Q3c:** o teste demonstra genericamente diferença zero no segundo passo; 1/2 é majorante, não uma diferença global comprovada igual a 1/2.
- **D2:** o owner constante none é admissível em howner_none exatamente quando todos os fatores efetivos coincidem; isso não força todo owner admissível a ser none.
- **D3:** p_k seleciona a′ se moved, a caso contrário. Igualdade de valores não implica moved quando a = a′.
- **Q4d:** mudar um valor bruto de zero para 1/2 só muda o fator efetivo se o polímero toca R; o teste genérico não assume esse toque em R.

As precisões são da coordenação, não uma errata emitida pela QA1. Não edite seus originais. Nos CIs globais 505/506 houve 294 saídas de certificados e 292 nomes distintos; a execução dirigida desta fita deve ter contagem própria.

## 6. Entrega e término

Ao terminar, reconfira manifesto e nove revisões e mostre que os arquivos rastreados do checkout não foram alterados. Testes novos, logs e relatórios ficam fora da árvore.

Entregue:

1. `RELATORIO_57-MANUS-EXEC.md`: SHA alvo, ambiente, comandos, exit codes, módulos construídos/reaproveitados, uso do cache, certificados, avisos por origem, testes positivos/negativo, eventual exame de achados Kimi, limitações e veredito.
2. `MANUS_57_EXEC_evidence.zip`: fontes efetivamente executadas, logs integrais, informações de ambiente/custódia e manifesto SHA-256 sem auto-inclusão. O relatório fica fora do ZIP; informe hashes e bytes das entregas na mensagem, sem circularidade.

Distinga três desfechos: **EXECUÇÃO CONCLUÍDA NO ESCOPO**, **BLOQUEADO POR AMBIENTE** ou **DIVERGÊNCIA A INVESTIGAR**. Um obstáculo de instalação não é refutação matemática; uma simples leitura não é execução concluída.

Não altere o parecer Kimi para lhe atribuir esses comandos. Não faça commit, push, PR, merge, tag, Release ou Zenodo. Não avance para a Pedra 58. Não declare a publicação liberada: o parecer e esta evidência voltarão à coordenação.

**HARD STOP após a entrega.**
