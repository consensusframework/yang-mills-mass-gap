#!/usr/bin/env bash
# Controlador local da fita 57-MANUS-EXEC. Não modifica arquivos rastreados.
set -u -o pipefail

AUDIT=/home/ubuntu/task57_manus_exec
REPO="$AUDIT/checkout"
PHASE3="$REPO/Phase3"
LOG="$AUDIT/raw_logs"
TESTDIR="$AUDIT/evidence_extracted/tests"
RUNTIME="$AUDIT/runtime_checks"
ELAN="$HOME/.elan/bin/elan"
LAKE="$HOME/.elan/bin/lake"
LEAN="$HOME/.elan/bin/lean"
TARGET='LatticeGauge.ActivityProfileDampingMultiRegion'
STATUS="$LOG/04_execution_status.tsv"

mkdir -p "$LOG" "$RUNTIME"
printf 'step\texit_code\tstarted_utc\tfinished_utc\tduration_seconds\tcommand\n' > "$STATUS"

record_step() {
  local label="$1"
  shift
  local out="$LOG/$label.log"
  local started finished elapsed rc
  started="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  local start_epoch
  start_epoch="$(date +%s)"
  {
    echo "started_utc=$started"
    printf 'command='
    printf '%q ' "$@"
    printf '\n'
    "$@"
  } > "$out" 2>&1
  rc=$?
  finished="$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  elapsed=$(( $(date +%s) - start_epoch ))
  {
    echo "exit_code=$rc"
    echo "finished_utc=$finished"
    echo "duration_seconds=$elapsed"
  } >> "$out"
  printf '%s\t%s\t%s\t%s\t%s\t' "$label" "$rc" "$started" "$finished" "$elapsed" >> "$STATUS"
  printf '%q ' "$@" >> "$STATUS"
  printf '\n' >> "$STATUS"
  return "$rc"
}

# Preserva os documentos efetivamente recebidos, fora da árvore Git.
mkdir -p "$AUDIT/inputs"
cp --preserve=timestamps /home/ubuntu/upload/FITA_57-MANUS-EXEC.md "$AUDIT/inputs/FITA_57-MANUS-EXEC.md"
cp --preserve=timestamps /home/ubuntu/upload/RELATORIO_57-K-ADV.md "$AUDIT/inputs/RELATORIO_57-K-ADV.md"

# Descoberta de instruções locais, sem executar conteúdo não autorizado.
{
  echo "started_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  find "$REPO" -path "$REPO/.git" -prune -o \( -iname AGENTS.md -o -iname INSTRUCTIONS.md -o -iname CONTRIBUTING.md \) -print
  echo "finished_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
} > "$LOG/04_local_instruction_inventory.log" 2>&1

# Pré-voo de identidade e ambiente; nenhuma resolução ocorre antes destes hashes.
{
  echo "started_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  echo 'executor_platform=Manus Sandbox'
  echo 'executor_model_identifier=not exposed by runtime'
  echo '--- system ---'
  uname -a
  uname -m
  echo '--- toolchain files ---'
  cat "$REPO/lean-toolchain"
  echo '--- elan / lean / lake ---'
  "$ELAN" --version
  (cd "$PHASE3" && "$LAKE" --version)
  (cd "$PHASE3" && "$LEAN" --version)
  echo '--- git identities ---'
  git -C "$REPO" rev-parse HEAD
  git -C "$REPO" rev-parse HEAD^{tree}
  git -C "$REPO" rev-parse HEAD:Phase3
  git -C "$REPO" show -s --format='parents=%P%nsubject=%s%ncommit_time=%cI' HEAD
  git -C "$REPO" rev-parse c936d4617f3e6f35ea1431c2fa9496b235940f5a^{tree}
  git -C "$REPO" rev-parse 95091fdd07398a7b42901829ad61e4e2c26d5aaa^{tree}
  echo '--- candidate diff against base ---'
  git -C "$REPO" diff --stat 95091fdd07398a7b42901829ad61e4e2c26d5aaa c936d4617f3e6f35ea1431c2fa9496b235940f5a
  git -C "$REPO" diff --name-status 95091fdd07398a7b42901829ad61e4e2c26d5aaa c936d4617f3e6f35ea1431c2fa9496b235940f5a
  echo '--- target source / manifest ---'
  cd "$PHASE3"
  sha256sum LatticeGauge/ActivityProfileDampingMultiRegion.lean lake-manifest.json
  wc -l -c LatticeGauge/ActivityProfileDampingMultiRegion.lean
  echo '--- checkout remote write disabled ---'
  git -C "$REPO" remote -v
  git -C "$REPO" config --get-regexp '^remote\.' || true
  echo '--- initial worktree status ---'
  git -C "$REPO" status --short --untracked-files=all
  echo "finished_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
} > "$LOG/05_preflight.log" 2>&1
preflight_rc=$?
printf '05_preflight\t%s\t-\t-\t-\tinternal shell block\n' "$preflight_rc" >> "$STATUS"
if [ "$preflight_rc" -ne 0 ]; then
  exit "$preflight_rc"
fi

# Materializa dependências estritamente pelo manifesto versionado. Sem lake update.
if ! record_step 06_lake_env_true bash -lc "cd '$PHASE3' && export GIT_TERMINAL_PROMPT=0 && '$LAKE' env true"; then
  exit 10
fi

# Inventário de pins efetivos, antes do cache e build.
{
  echo "started_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  cd "$PHASE3"
  echo '--- manifest sha256 ---'
  sha256sum lake-manifest.json
  echo '--- manifest package rev entries ---'
  python3 - <<'PY'
import json
with open('lake-manifest.json', encoding='utf-8') as f:
    data=json.load(f)
pkgs=data.get('packages', [])
if isinstance(pkgs, dict):
    iterable=[]
    for key,value in pkgs.items():
        entry=dict(value) if isinstance(value,dict) else {'value': value}
        entry.setdefault('name', key)
        iterable.append(entry)
else:
    iterable=pkgs
for p in iterable:
    if not isinstance(p, dict):
        print(f'UNPARSEABLE\t{p!r}')
        continue
    name=p.get('name','')
    rev=p.get('rev','')
    url=p.get('url','')
    path=p.get('path','')
    print(f'{name}\t{rev}\t{url}\t{path}')
PY
  echo '--- actual package heads ---'
  for p in .lake/packages/*; do
    [ -d "$p" ] || continue
    if [ -d "$p/.git" ] || git -C "$p" rev-parse --git-dir >/dev/null 2>&1; then
      printf '%s\t' "$(basename "$p")"
      git -C "$p" rev-parse HEAD
    else
      printf '%s\tNOT_A_GIT_PACKAGE\n' "$(basename "$p")"
    fi
  done | LC_ALL=C sort
  echo "finished_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
} > "$LOG/07_dependencies_and_pins.log" 2>&1
pins_rc=$?
printf '07_dependencies_and_pins\t%s\t-\t-\t-\tinternal shell block\n' "$pins_rc" >> "$STATUS"
if [ "$pins_rc" -ne 0 ]; then
  exit "$pins_rc"
fi

# Cache compatível da Mathlib; nenhum oleans da árvore LatticeGauge é importado.
if ! record_step 08_mathlib_cache_get bash -lc "cd '$PHASE3' && '$LAKE' exe cache get"; then
  exit 11
fi

{
  echo "started_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  cd "$PHASE3"
  echo '--- LatticeGauge artifacts before directed build ---'
  if [ -d .lake/build/lib/lean/LatticeGauge ]; then
    find .lake/build/lib/lean/LatticeGauge -type f -printf '%P\n' | LC_ALL=C sort
  else
    echo 'ABSENT'
  fi
  echo '--- all project build artifacts before directed build ---'
  if [ -d .lake/build/lib/lean ]; then
    find .lake/build/lib/lean -type f -printf '%P\n' | LC_ALL=C sort
  else
    echo 'ABSENT'
  fi
  echo "finished_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
} > "$LOG/09_prebuild_project_artifacts.log" 2>&1

# Compilação dirigida do módulo novo e das dependências importadas.
if ! record_step 10_directed_build bash -lc "cd '$PHASE3' && '$LAKE' build '$TARGET'"; then
  exit 12
fi

# Arquivo de #check independente, fora da árvore do repositório.
cat > "$RUNTIME/check_capstone_signatures.lean" <<'EOF'
import LatticeGauge.ActivityProfileDampingMultiRegion

#check LatticeGauge.abs_profileExpectation_sub_profileExpectation_le_multiregion_two_terms
#check LatticeGauge.abs_profileExpectation_sub_profileExpectation_le_multiregion
EOF

# Reexecução dos cinco testes fornecidos pela QA1, sem alterar seus bytes.
record_step 11_q0_certificates bash -lc "cd '$PHASE3' && '$LAKE' env lean '$TESTDIR/q0_certificates.lean'"
q0_rc=$?
record_step 12_q3_overlap bash -lc "cd '$PHASE3' && '$LAKE' env lean '$TESTDIR/q3_overlap.lean'"
q3_rc=$?
record_step 13_q4_background bash -lc "cd '$PHASE3' && '$LAKE' env lean '$TESTDIR/q4_background.lean'"
q4_rc=$?
record_step 14_q5_own_closure bash -lc "cd '$PHASE3' && '$LAKE' env lean '$TESTDIR/q5_own_closure.lean'"
q5_rc=$?
record_step 15_q8x_missing_cover_expected_fail bash -lc "cd '$PHASE3' && '$LAKE' env lean '$TESTDIR/q8x_missing_cover_EXPECT_FAIL.lean'"
q8_rc=$?
record_step 16_capstone_signature_checks bash -lc "cd '$PHASE3' && '$LAKE' env lean '$RUNTIME/check_capstone_signatures.lean'"
sig_rc=$?

# Estado final, hashes repetidos e inexistência de mudanças rastreadas.
{
  echo "started_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
  echo '--- result codes ---'
  echo "q0_certificates_exit=$q0_rc"
  echo "q3_overlap_exit=$q3_rc"
  echo "q4_background_exit=$q4_rc"
  echo "q5_own_closure_exit=$q5_rc"
  echo "q8x_missing_cover_EXPECT_FAIL_exit=$q8_rc"
  echo "capstone_signature_checks_exit=$sig_rc"
  echo '--- repeated source / manifest hashes ---'
  cd "$PHASE3"
  sha256sum LatticeGauge/ActivityProfileDampingMultiRegion.lean lake-manifest.json
  echo '--- repeated package heads ---'
  for p in .lake/packages/*; do
    [ -d "$p" ] || continue
    if [ -d "$p/.git" ] || git -C "$p" rev-parse --git-dir >/dev/null 2>&1; then
      printf '%s\t' "$(basename "$p")"
      git -C "$p" rev-parse HEAD
    fi
  done | LC_ALL=C sort
  echo '--- tracked diff ---'
  git -C "$REPO" diff --exit-code
  echo "tracked_diff_exit=$?"
  echo '--- final worktree status ---'
  git -C "$REPO" status --short --untracked-files=all
  echo '--- remote configuration repeated ---'
  git -C "$REPO" remote -v
  echo "finished_utc=$(date -u +'%Y-%m-%dT%H:%M:%SZ')"
} > "$LOG/17_final_integrity.log" 2>&1
final_rc=$?
printf '17_final_integrity\t%s\t-\t-\t-\tinternal shell block\n' "$final_rc" >> "$STATUS"

# Resultado do controlador: 0 apenas se os quatro positivos, o #check e a integridade forem verdes,
# e se o teste negativo de cobertura falhar como esperado.
if [ "$q0_rc" -eq 0 ] && [ "$q3_rc" -eq 0 ] && [ "$q4_rc" -eq 0 ] && [ "$q5_rc" -eq 0 ] && [ "$sig_rc" -eq 0 ] && [ "$q8_rc" -ne 0 ] && [ "$final_rc" -eq 0 ]; then
  exit 0
fi
exit 20
